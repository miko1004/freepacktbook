static void thr_skillinfo(type_session * c){

	char msg[128];
	short Len=2;
	int i,cnt=0;
	unsigned short	nEnd = PEND;

	if(c==NULL) return;

	msg[Len]=PK_SKILL_INFO;
	Len+=2;

	for(i=0;i<4;i++){
		if(c->skill[i]>0){
			msg[Len]=i;
			Len+=1;
			memcpy(&msg[Len],&c->skill[i],2);
			Len+=2;
			msg[Len]=c->skill_lv[i];
			Len+=1;
			cnt+=1;
		}
	}
	msg[3]=cnt;
	memcpy(&msg[Len],&nEnd,2);
	Len+=2;
	memcpy(&msg[0],&Len,2);
	map_pData_snd(c,msg,Len);

}
