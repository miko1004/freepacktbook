static void thr_inveninfo(type_session * c){

	char msg[128];
	short Len=2;
	int i,cnt=0;
	unsigned short	nEnd = PEND;

	if(c==NULL) return;

	msg[Len]=PK_INVEN_INFO;
	Len+=2;

	for(i=0;i<4;i++){
		if(c->inven[i]>0){
			msg[Len]=i;
			Len+=1;
			memcpy(&msg[Len],&c->inven[i],2);
			Len+=2;
			msg[Len]=c->inven_cnt[i];
			Len+=1;
			cnt+=1;
		}
	}
	msg[3]=cnt;
	memcpy(&msg[Len],&nEnd,2);
	Len+=2;
	memcpy(&msg[0],&Len,2);
	map_pData_snd(c,msg,Len);

}
