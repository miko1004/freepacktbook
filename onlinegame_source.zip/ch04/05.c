extern int db_user_auth(char * userid, char *passwd, int passlen, void * conn,type_session * c)
{
	int	state,len;
	MYSQL_RES *result;
	MYSQL_ROW row;
	char query[256];

	memset(query,0,256);
	sprintf(query,"select passwd from userinfo where userid='%s'",userid);

	state = mysql_query((MYSQL *)conn, query);
	if( state == -1 ) {
		printf("testXX%s\n",mysql_error((MYSQL *)conn));
		return 0;
	}
	result = mysql_store_result((MYSQL *)conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("mysql fail return value 0 \n");
		mysql_free_result(result);
		return 0;
	}
	row = mysql_fetch_row(result);
	mysql_free_result(result);
	len = strlen(row[0]);
	if(passlen==len){
		if(!strncmp(row[0],passwd,len)){

			memset(query,0,256);
			sprintf(query,"select * from character where userid='%s'",userid);
			state = mysql_query((MYSQL *)conn, query);
			if( state == -1 ) {
				printf("testXX%s\n",mysql_error((MYSQL *)conn));
				return 0;
			}
			result = mysql_store_result((MYSQL *)conn);
			state = mysql_num_rows(result);
			if( state == 0 ) {
				printf("mysql fail return value 0 \n");
				mysql_free_result(result);
				return 0;
			}
			row = mysql_fetch_row(result);
			c->nLen = strlen(row[1]);//char name length
			memcpy(&c->char_name[0],&row[1][0],c->nLen);	// NAME
			c->race		=	atoi(row[2]);		// RACE
			c->sex		=	atoi(row[3]);		// SEX
			c->nation	=	atoi(row[4]);		// NATION

			c->str		=	atoi(row[5]);	// STR
			c->dex		=	atoi(row[6]);	// DEX
			c->intel	=	atoi(row[7]);	// INT

			c->mana_c	=	atoi(row[8]);	// MANA
			c->hp_c		=	atoi(row[9]);	// HP
			c->exp		=	atoi(row[10]);	// EXP
			c->level	=	atoi(row[11]);	// LV
			c->lvpoint	=	atoi(row[12]);	// PT
			c->skexp	=	atoi(row[13]);	// PT

			c->jobno	=	atoi(row[14]);	//JOB
			c->classno	=	atoi(row[15]);	//CLASS
			c->classlevel	=	atoi(row[16]);	//CLASSLV
			c->worldmap	=	atoi(row[17]);	//LOC_SVR
			c->Cx		=	atoi(row[18]);	//LOCX
			c->Cz		=	atoi(row[19]);	//LOCZ
			c->Ax		=	c->Cx/S_UNITSIZE;
			c->Az		=	c->Cz/S_UNITSIZE;
			c->Bx		=	c->Ax;
			c->Bz		=	c->Az;

			c->eq[0]	=	atoi(row[20]);	//I_HEAD
			c->eq[1]	=	atoi(row[21]);	//I_L_HAND
			c->eq[2]	=	atoi(row[22]);	//I_R_HAND
			c->eq[3]	=	atoi(row[23]);	//I_BODY
			c->eq[4]	=	atoi(row[24]);	//I_LEG
			c->eq[5]	=	atoi(row[25]);	//I_NECKLACE
			c->eq[6]	=	atoi(row[26]);	//I_RING1
			c->coin		=	atoi(row[27]);	//COIN
			mysql_free_result(result);

			memset(query,0,256);
			sprintf(query,"select * from USERITEM where userid='%s'",userid);
			state = mysql_query((MYSQL *)conn, query);
			if( state == -1 ) {
				printf("testXX%s\n",mysql_error((MYSQL *)conn));
				return 0;
			}
			result = mysql_store_result((MYSQL *)conn);
			state = mysql_num_rows(result);
			if( state == 0 ) {
				printf("mysql fail return value 0 \n");
				mysql_free_result(result);
				return 0;
			}
			row = mysql_fetch_row(result);
			c->inven[0]		=	atoi(row[2]);
			c->inven_cnt[0]		=	atoi(row[3]);
			c->inven[1]		=	atoi(row[4]);
			c->inven_cnt[1]		=	atoi(row[5]);
			c->inven[2]		=	atoi(row[6]);
			c->inven_cnt[2]		=	atoi(row[7]);
			c->inven[3]		=	atoi(row[8]);
			c->inven_cnt[3]		=	atoi(row[9]);
			mysql_free_result(result);

			memset(query,0,256);
			sprintf(query,"select * from SKILL where userid='%s'",userid);
			state = mysql_query((MYSQL *)conn, query);
			if( state == -1 ) {
				printf("testXX%s\n",mysql_error((MYSQL *)conn));
				return 0;
			}
			result = mysql_store_result((MYSQL *)conn);
			state = mysql_num_rows(result);
			if( state == 0 ) {
				printf("mysql fail return value 0 \n");
				mysql_free_result(result);
				return 0;
			}
			row = mysql_fetch_row(result);
			c->skill[0]		=	atoi(row[2]);
			c->skill_lv[0]		=	atoi(row[3]);
			c->skill[1]		=	atoi(row[4]);
			c->skill_lv[1]		=	atoi(row[5]);
			c->skill[2]		=	atoi(row[6]);
			c->skill_lv[2]		=	atoi(row[7]);
			c->skill[3]		=	atoi(row[8]);
			c->skill_lv[3]		=	atoi(row[9]);
			mysql_free_result(result);

			memset(query,0,256);
			sprintf(query,"select * from WAREHOUSE where userid='%s'",userid);
			state = mysql_query((MYSQL *)conn, query);
			if( state == -1 ) {
				printf("testXX%s\n",mysql_error((MYSQL *)conn));
				return 0;
			}
			result = mysql_store_result((MYSQL *)conn);
			state = mysql_num_rows(result);
			if( state == 0 ) {
				printf("mysql fail return value 0 \n");
				mysql_free_result(result);
				return 0;
			}
			row = mysql_fetch_row(result);
			c->ware[0]		=	atoi(row[1]);
			c->ware_cnt[0]		=	atoi(row[2]);
			c->ware[1]		=	atoi(row[3]);
			c->ware_cnt[1]		=	atoi(row[4]);
			c->ware[2]		=	atoi(row[5]);
			c->ware_cnt[2]		=	atoi(row[6]);
			c->ware[3]		=	atoi(row[7]);
			c->ware_cnt[3]		=	atoi(row[8]);
			c->ware[4]		=	atoi(row[9]);
			c->ware_cnt[4]		=	atoi(row[10]);
			c->ware[5]		=	atoi(row[11]);
			c->ware_cnt[5]		=	atoi(row[12]);
			c->ware[6]		=	atoi(row[13]);
			c->ware_cnt[6]		=	atoi(row[14]);
			c->ware[7]		=	atoi(row[15]);
			c->ware_cnt[7]		=	atoi(row[16]);
			mysql_free_result(result);

			c->mana_F_cnt		=0;	// ���� ȸ���� ī��Ʈ
			c->recov_F_cnt		=0;	// ����� ȸ���� ī��Ʈ
			c->attack_F_cnt		=0;	// ����� ���ݵ����̿� ī��Ʈ
			c->regen_F_cnt		=0;	// ���� ī����
			c->dbSaveCnt		=0;	// ������ ���� ī����
			c->move_F_cnt		=0;

			c->party.flag		=0;	// ��Ƽ �÷��� �ʱ�ȭ
			c->party.waitfor	=NULL;	// ��ٸ��� ��� �ʱ�ȭ
			c->party.cnt		=0;	// ��ٸ��� ��� �ʱ�ȭ
			c->party.memidx		=0;	// �ڽ��� ��ġ
			c->party.infoFcnt	=0;	// ���� ���� �˸� ī��Ʈ
			c->party.ison1		=0;	// 0: NULL  1:linked  2:myself(member#==NULL)
			c->party.ison2		=0;
			c->party.ison3		=0;

			c->trade.flag		=0;	// �ŷ� �÷��� �ʱ�ȭ
			c->moveLevel		=2;
			c->pkmode		=0;	// �÷��̾� ų ���� �⺻������ ��������(0), ��: 1

			// ������� ��� ��
			c->attack	= c->str+c->dex+c->intel+c->level+item_get_attack(c->eq[1])+item_get_attack(c->eq[2]); // ���� �߰�
			c->hp_m 	= c->str+c->dex+50;
			c->mana_m	= c->intel+50;
			c->defence	= item_get_defence(c->eq[0])+item_get_defence(c->eq[1])+item_get_defence(c->eq[2])+item_get_defence(c->eq[3])+item_get_defence(c->eq[4])+item_get_defence(c->eq[5])+item_get_defence(c->eq[6]);
			c->dbLoaded =1;
			return 1;

		}else{
			return 0;
		}
	}else{
		return 0;
	}
}