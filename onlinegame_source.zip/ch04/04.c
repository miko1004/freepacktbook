			case PK_USER_AUTH:
				idx=3;
				ulen=dat[idx];	// �̸� ����
				idx+=1;
				if(res<ulen+idx||ulen>31) return 0;	// ����
				memcpy(&name[0],&dat[idx],ulen);
				name[ulen]='\0';
				idx+=ulen;
				clen=dat[idx];	// pass ����
				idx+=1;
				if(res<clen+idx||clen>31) return 0;	// ����
				memcpy(&pass[0],&dat[idx],clen);
				pass[clen]='\0';
				res = db_user_auth(name, pass,clen,conn,c);
				printf("�������� ��� :%d %s \n",res,name);

				if(res==1){
					pthread_mutex_lock(&synclock);
					session_set_userid(c,name,ulen);
					mapinit(c);
					c->state=conn_state_authed;
					pthread_mutex_unlock(&synclock);
					mesg[pLen]=PK_USER_AUTH;
					pLen+=1;
					mesg[pLen]=svr_ret_tot();
					pLen+=1;
					mesg[pLen]=c->uLen;
					pLen+=1;
					memcpy(&mesg[pLen],&c->userid[0],c->uLen);
					pLen+=c->uLen;
					memcpy(&mesg[pLen],&c->userNo,2);
					pLen+=2;
					memcpy(&mesg[pLen],&nEnd,2);
					pLen+=2;
					memcpy(&mesg[0],&pLen,2);
					map_pData_snd(c,mesg,pLen);

					// �� ���� ����
					pLen=2;
					mesg[pLen]=PK_OBJ_ADD;
					pLen+=1;
					mesg[pLen]=0;  // ��ü Ÿ�� 0: ���� 1: NPC 2: ������
					pLen+=1;

					mesg[pLen]=1;//cnt
					pLen+=1;
					memcpy(&mesg[pLen],&c->userNo,2);  // ���⼭���� cnt��ŭ ����
					pLen+=2;
					mesg[pLen] = c->nLen;
					pLen+=1;
					memcpy(&mesg[pLen],&c->char_name[0],c->nLen);
					pLen+=c->nLen;
					mesg[pLen]=c->race;
					pLen+=1;
					mesg[pLen]=c->sex;
					pLen+=1;
					mesg[pLen]=c->nation;
					pLen+=1;

					memcpy(&mesg[pLen],&c->str,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->dex,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->intel,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->hp_c,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->mana_c,2);
					pLen+=2;

					memcpy(&mesg[pLen],&c->exp,4);
					pLen+=4;
					memcpy(&mesg[pLen],&c->level,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->lvpoint,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->skexp,4);
					pLen+=4;
					mesg[pLen]=c->jobno;
					pLen+=1;
					mesg[pLen]=c->classno;
					pLen+=1;
					mesg[pLen]=c->classlevel;
					pLen+=1;

					memcpy(&mesg[pLen],&c->eq[0],2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->eq[1],2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->eq[2],2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->eq[3],2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->eq[4],2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->coin,4);
					pLen+=4;

					mesg[pLen]=c->userStat;
					pLen+=1;
					if(c->userStat==S_STAND){  // ����
						mesg[pLen]=c->Dir;
						pLen+=1;
						memcpy(&mesg[pLen],&c->Ax,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Az,2);
						pLen+=2;
					}else if(c->userStat==S_MOVE){  // �̵�
						mesg[pLen]=c->Dir;
						pLen+=1;
						mesg[pLen]=c->moveLevel;
						pLen+=1;
						memcpy(&mesg[pLen],&c->Cx,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Cz,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Dx,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Dz,2);
						pLen+=2;
					}else if(c->userStat==S_FIGHT){  // ����
						mesg[pLen]=c->Dir;
						pLen+=1;
						mesg[pLen]=c->tgtype;  // Ÿ�� Ÿ��
						pLen+=1;
						if(c->tgtype==0){//pk
							usr=(type_session *)c->target;
							memcpy(&mesg[pLen],&usr->userNo,2);
							pLen+=2;
						}else{  // ����
							npc=(type_npc *)c->target;
							memcpy(&mesg[pLen],&npc->npc_id,2);
							pLen+=2;
						}
						memcpy(&mesg[pLen],&c->Ax,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Az,2);
						pLen+=2;
					}else{  // �ŷ�
						mesg[pLen]=c->Dir;
						pLen+=1;
						memcpy(&mesg[pLen],&c->Ax,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Az,2);
						pLen+=2;
					}
					memcpy(&mesg[pLen],&nEnd,2);
					pLen+=2;
					memcpy(&mesg[0],&pLen,2);
					map_usersend_All(c->Ax,c->Az,mesg,pLen,NULL);

					thr_inveninfo(c);  // �÷��׸� �ϳ� ���� Ŭ���̾�Ʈ�� ��û�� �� ������ �� �ִ�.
					thr_skillinfo(c);

					map_get_sectorinfo_All(c);	// ����� ���� �޾ƿ���
					npc_3x3_secterinfo(c);		// �ʵ��� NPC, ���� ���� �޾ƿ���
					item_3x3_secterinfo(c);		// �ʵ��� ������ ���� �޾ƿ���
				}else{
					return 0;
				}
			break;