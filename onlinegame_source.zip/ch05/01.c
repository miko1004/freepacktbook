		case PK_CMD_MV:
			memcpy(&Tx,&dat[3],2);
			memcpy(&Tz,&dat[5],2);
			DIR=dat[7];
			if(Tx>=M_SIZE_X||Tz>=M_SIZE_X||DIR>=8){
				res=0;
			}else{
				if(c->Cx==Tx&&c->Cz==Tz) res=0;
				else{
					pthread_mutex_lock(&synclock);
					res=mvAction_set(c,Tx,Tz,DIR);
					pthread_mutex_unlock(&synclock);
				}
			}
			printf("before:%d,%d after:%d,%d res:%d\n",c->Cx,c->Cz,Tx,Tz,res);

			mesg[rLen] = PK_OBJ_UPDATE_ACT;  // 2
			rLen+=1;
			mesg[rLen] = T_USER;	// ��ü Ÿ��: 0 - ����
			rLen+=1;
			mesg[rLen] = 1;  	// ī��Ʈ
			rLen+=1;
			memcpy(&mesg[rLen],&c->userNo,2);  // 8
			rLen+=2;
			mesg[rLen]=S_MOVE;
			rLen+=1;
			mesg[rLen]=c->Dir;
			rLen+=1;
			mesg[rLen]=c->moveLevel;
			rLen+=1;
			memcpy(&mesg[rLen],&c->Cx,2);
			rLen+=2;
			memcpy(&mesg[rLen],&c->Cz,2);
			rLen+=2;
			memcpy(&mesg[rLen],&c->Dx,2);
			rLen+=2;
			memcpy(&mesg[rLen],&c->Dz,2);
			rLen+=2;

			memcpy(&mesg[rLen],&nEnd,2);
			rLen+=2;
			memcpy(&mesg[0],&rLen,2);

			if(res==1){
				map_usersend_All(c->Ax,c->Az,mesg,rLen,NULL);
			}
		break;