				if(npcArray[i]->status==S_MOVE){
					if(npcArray[i]->dx!=npcArray[i]->x||npcArray[i]->dz!=npcArray[i]->z){
						npc_mv_set(i);
						continue;
					}else{
						npcArray[i]->move_F_cnt=0;
						npcArray[i]->rotate_F_cnt=0;
						npcArray[i]->status=S_STAND;
						npcArray[i]->mvstatus = 0;
					}
				}else{ // S_STAND.. �ð��� �Ŀ� �� ���� ���ϴ� ����

					if(npcArray[i]->rotate_F_cnt > rotate_time){  // �����̰� ���� �� ������ ��
						npcArray[i]->ret_F_cnt+=1;  // ��ȸ�� ī��Ʈ
						if(npcArray[i]->ret_F_cnt>10){  // 10�� ���� �ٳ����� ������ ��ġ�� ���ư���.
							npcArray[i]->ret_F_cnt=0;
							npcArray[i]->dx = npcArray[i]->Gx;
							npcArray[i]->dz = npcArray[i]->Gz;
						}else{
							Rest+=1;
							if(Rest>7) Rest=0;
							switch(Rest){
								case 0:
									npcArray[i]->dx = npcArray[i]->x-1;
									npcArray[i]->dz = npcArray[i]->z;
								break;
								case 1:
									npcArray[i]->dx = npcArray[i]->x-1;
									npcArray[i]->dz = npcArray[i]->z+1;
								break;
								case 2:
									npcArray[i]->dx = npcArray[i]->x+1;
									npcArray[i]->dz = npcArray[i]->z-1;
								break;
								case 3:
									npcArray[i]->dx = npcArray[i]->x-1;
									npcArray[i]->dz = npcArray[i]->z-1;
								break;
								case 4:
									npcArray[i]->dx = npcArray[i]->x+1;
									npcArray[i]->dz = npcArray[i]->z+1;
								break;

								case 5:
									npcArray[i]->dx = npcArray[i]->x;
									npcArray[i]->dz = npcArray[i]->z-1;
								break;
								case 6:
									npcArray[i]->dx = npcArray[i]->x+1;
									npcArray[i]->dz = npcArray[i]->z;
								break;
								case 7:
									npcArray[i]->dx = npcArray[i]->x;
									npcArray[i]->dz = npcArray[i]->z+1;
								break;
							}
						}
						j=0;
						while(1){
							torf = map_isgo(npcArray[i]->dx, npcArray[i]->dz);  // �̵� ���� ����
							if(torf==0){  // �̵� ����
								npcArray[i]->status=S_MOVE;
								npcArray[i]->mvstatus=0;
								break;
							}else{  // �̵� �Ұ�
								if(npcArray[i]->dx>=M_SIZE_X)
									npcArray[i]->dx = npcArray[i]->dx-1;
								else if(npcArray[i]->dz>=M_SIZE_X)
									npcArray[i]->dz = npcArray[i]->dz-1;
								else{
									npcArray[i]->dz = npcArray[i]->dz-1;
									npcArray[i]->dx = npcArray[i]->dx-1;
								}
							}
							if(j==20){  // ���� ���� ����
								npcArray[i]->status=S_STAND;
								break;
							}
							j++;
						}

						if(npcArray[i]->dx==npcArray[i]->x&&npcArray[i]->dz==npcArray[i]->z){
							npcArray[i]->status=S_STAND;
						}else{
							npcArray[i]->mvstatus=0;
							npcArray[i]->status=S_MOVE;
						}
						npcArray[i]->rotate_F_cnt = 0;
					}else npcArray[i]->rotate_F_cnt++;

					if(npcArray[i]->HP!=npcArray[i]->tHP){//recover
						if(npcArray[i]->HP>npcArray[i]->tHP){
							npcArray[i]->HP = npcArray[i]->tHP;
							continue;
						}else{
							npcArray[i]->recov_F_cnt++;
							if(npcArray[i]->recov_F_cnt>30){
								npcArray[i]->HP++;
								npcArray[i]->recov_F_cnt=0;
							}
						}
					}
				}