void * Thread_sync(void *arg){  // ���� ĳ������ ���⸦ ���ߴ� ������

	struct timeval start,stop;
	long	tmp,utmp;
	short regenTime,Half_sec;
	int maxNo;
	type_session * c;

	sleep(3);
	regenTime = _ONE_SEC*30;
	Half_sec = _ONE_SEC/2;
	for(;;){
		gettimeofday(&start,NULL);
		pthread_mutex_lock(&synclock);
		maxNo = svr_ret_tot();
		for(c=ret_session_first(maxNo);c;c=ret_session_next(maxNo))
		{
			if(c->state==conn_state_empty||c->state==conn_state_destroy) continue;
			if(c->userStat == S_MOVE){ 			// �̵�
				if(c->Cx == c->Dx&& c->Cz==c->Dz){	// ������ ����
					c->userStat = S_STAND;		// ����
				}else{
					map_chrAction_calc(c);
				}
			}

			if(c->attack_F_cnt>-1){
				c->attack_F_cnt+=1;
				if(c->attack_F_cnt>Half_sec) c->attack_F_cnt=-1;
			}

			if(c->party.flag==1&&c->party.ison1==2){	// ��Ƽ��
				if(c->party.infoFcnt>_TWO_MIN){
					c->party.infoFcnt=0;
					thr_party_info(c);
				}else c->party.infoFcnt++;
			}
			c->dbSaveCnt++;
			/*
			if(c->dbSaveCnt>�ð���){
				db_save_data(c,conn);
				c->dbSaveCnt=0;
			}
			*/
		}
		pthread_cond_signal(&synccond);
		pthread_mutex_unlock(&synclock);

		gettimeofday(&stop,NULL);
		tmp = stop.tv_sec - start.tv_sec;
		utmp = stop.tv_usec - start.tv_usec;

		if(tmp>1){	// 1������ 0.033�� 33000/

		}else if(tmp==1){
			utmp = 1000000 + utmp;	// �ɸ� �ð�
			if(utmp<AFRAME){
				stop.tv_sec=0;
				stop.tv_usec=AFRAME-utmp;
				select(0, NULL, NULL, NULL, &stop);
			}
		}else{
			if(utmp<AFRAME){
				stop.tv_sec=0;
				stop.tv_usec=AFRAME-utmp;
				select(0, NULL, NULL, NULL, &stop);
			}
		}
	} // for ���� ��
}