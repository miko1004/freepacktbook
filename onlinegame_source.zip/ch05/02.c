static short mvAction_set(type_session * c,short Dx, short Dz, short dirL){  // ������ ����

	if (!c) return 0;
	c->Dir		= dirL;
	c->userStat	= 1;
	if((map_isgo(Dx,Dz))==1) return 0;
	c->Dx 	= Dx;//dest set
	c->Dz 	= Dz;
	return 1;
}