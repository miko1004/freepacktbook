extern void map_bk_sectorinfo(type_session * c){  // character�� ���� �̵����� ���� ���ο� ���Ϳ� ������ �����Ѵ�.

	int x,z;
	int ax,az,i;
	short dLen=2;
	char udata[128];
	unsigned short	nEnd = PEND;
	type_session * usr;
	type_npc * npc;

	memset(udata,0,128);
	udata[dLen] = PK_OBJ_ADD;	// 2
	dLen+=1;
	udata[dLen] = T_USER;		// ��ü Ÿ��: ����	//3
	dLen+=1;
	udata[dLen] = 1;		// 4
	dLen+=1;

	memcpy(&udata[dLen],&c->userNo,2); // ���⼭���� cnt��ŭ ����
	dLen+=2;
	udata[dLen] = c->nLen;
	dLen+=1;
	memcpy(&udata[dLen],&c->char_name[0],c->nLen);
	dLen+=c->nLen;
	udata[dLen]=c->race;
	dLen+=1;
	udata[dLen]=c->sex;
	dLen+=1;
	udata[dLen]=c->nation;
	dLen+=1;

	memcpy(&udata[dLen],&c->str,2);
	dLen+=2;
	memcpy(&udata[dLen],&c->dex,2);
	dLen+=2;
	memcpy(&udata[dLen],&c->intel,2);
	dLen+=2;
	memcpy(&udata[dLen],&c->hp_c,2);
	dLen+=2;
	memcpy(&udata[dLen],&c->mana_c,2);
	dLen+=2;

	memcpy(&udata[dLen],&c->exp,4);
	dLen+=4;
	memcpy(&udata[dLen],&c->level,2);
	dLen+=2;
	memcpy(&udata[dLen],&c->lvpoint,2);
	dLen+=2;
	memcpy(&udata[dLen],&c->skexp,4);
	dLen+=4;
	udata[dLen]=c->jobno;
	dLen+=1;
	udata[dLen]=c->classno;
	dLen+=1;
	udata[dLen]=c->classlevel;
	dLen+=1;

	memcpy(&udata[dLen],&c->eq[0],2);
	dLen+=2;
	memcpy(&udata[dLen],&c->eq[1],2);
	dLen+=2;
	memcpy(&udata[dLen],&c->eq[2],2);
	dLen+=2;
	memcpy(&udata[dLen],&c->eq[3],2);
	dLen+=2;
	memcpy(&udata[dLen],&c->eq[4],2);
	dLen+=2;
	memcpy(&udata[dLen],&c->coin,4);
	dLen+=4;

	udata[dLen]=c->userStat;
	dLen+=1;
	if(c->userStat==0){	// ����
		udata[dLen]=c->Dir;
		dLen+=1;
		memcpy(&udata[dLen],&c->Ax,2);
		dLen+=2;
		memcpy(&udata[dLen],&c->Az,2);
		dLen+=2;
	}else if(c->userStat==1){	// �̵�
		udata[dLen]=c->Dir;
		dLen+=1;
		udata[dLen]=c->moveLevel;
		dLen+=1;
		memcpy(&udata[dLen],&c->Cx,2);
		dLen+=2;
		memcpy(&udata[dLen],&c->Cz,2);
		dLen+=2;
		memcpy(&udata[dLen],&c->Dx,2);
		dLen+=2;
		memcpy(&udata[dLen],&c->Dz,2);
		dLen+=2;
	}else if(c->userStat==2){	// ����
		udata[dLen]=c->Dir;
		dLen+=1;
		udata[dLen]=c->tgtype;	// Ÿ�� Ÿ��
		dLen+=1;
		if(c->tgtype==0){	// pk
			usr=(type_session *)c->target;
			memcpy(&udata[dLen],&usr->userNo,2);
			dLen+=2;
		}else{			// ����
			npc=(type_npc *)c->target;
			memcpy(&udata[dLen],&npc->npc_id,2);
			dLen+=2;
		}
		memcpy(&udata[dLen],&c->Ax,2);
		dLen+=2;
		memcpy(&udata[dLen],&c->Az,2);
		dLen+=2;
	}else{	// �ŷ�, ����
		udata[dLen]=c->Dir;
		dLen+=1;
		memcpy(&udata[dLen],&c->Ax,2);
		dLen+=2;
		memcpy(&udata[dLen],&c->Az,2);
		dLen+=2;
	}

	memcpy(&udata[dLen],&nEnd,2);
	dLen+=2;
	memcpy(&udata[0],&dLen,2);

	x = c->Bx - c->Ax;	// 0
	z = c->Bz - c->Az;	// 1

	if(x==0 && z<0){	// 12�� ���� ��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az +1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){

				map_secdata_snd(ax, az, udata, dLen);

			}else continue;

		} // for ���� ��
	}else if(x<0  && z<0){  // 1�� ���� ��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az +1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;

		} // for ���� ��

		for(i=0;i<2;i++){
			ax = c->Ax +1;
			az = c->Az -i;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;
		} // for ���� ��

	}else if(x<0 && z==0){  // 3�� ���� ��

		for(i=3;i>0;i--){
			ax = c->Ax +1;//28
			az = c->Az -i+2;//14

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az,udata, dLen);
			}else continue;

		} // for ���� ��
	}else if(x<0  && z>0){ // 4�� ���� ��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az -1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;

		}// for ���� ��

		for(i=0;i<2;i++){
			ax = c->Ax +1;
			az = c->Az +i;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az,udata, dLen);
			}else continue;

		} // for ���� ��

	}else if(x==0 && z>0){ // 6�� ���� ��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az -1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;

		} // for ���� ��
	}else if(x>0  && z>0){ // 7�� ���� ��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az -1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;

		}// for ���� ��

		for(i=0;i<2;i++){
			ax = c->Ax -1;
			az = c->Az +i;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;

		}// for ���� ��


	}else if(x>0  && z==0){ // 9�� ���� ��

		for(i=3;i>0;i--){

			ax = c->Ax -1;
			az = c->Az -i+2;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;

		} // for ���� ��
	}else if(x>0  && z<0){ // 10�� ���� ��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az +1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;

		}// for ���� ��

		for(i=0;i<2;i++){
			ax = c->Ax -1;
			az = c->Az -i;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;

		} // for ���� ��

	}
}