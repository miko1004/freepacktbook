#ifndef PUBLIC_INCLUDED
#include "publicInc.h"
#endif



typedef struct packet
{
	int					cli_sock;
	int					size;
	char              data[MAX_PACKET_SIZE];
	void *				session;
}
type_packet;



extern type_packet * packet_create();
extern void packet_destroy(type_packet const * packet);
