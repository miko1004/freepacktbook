#include		<stdio.h>
#include		<sys/types.h>
#include 	<strings.h>
#include 	<stdlib.h>
#include 	<math.h>
#define MAP_INTERNAL_ACCESS
#include "map.h"
#include "svr.h"
#include "db.h"
#include "item.h"

static type_map	mapArray[S_WIDTH][S_WIDTH];
static char			map[M_SIZE_X][M_SIZE_X];




extern void map_Load()//Thread_recvpack���� �ε�
{
	FILE * fp;
	unsigned int mxtileno;
	unsigned int i,x,y;
	char val;

	fp = fopen (MAP_FILE,"r");
	if (fp == NULL){
		printf ("file Open error\n");
		exit(1);
	}

	fread(&mxtileno, 4 , 1 , fp);
	for(i=0; i<mxtileno; i++)
	{
		fread(&val,1,1,fp);//0:use 1:monster 2:npc 3:not use
		x = i%M_SIZE_X;//x ��ǥ
		y = i/M_SIZE_X;//z ��ǥ
		if(val==0) map[x][y]=0;
		else if(val>9&&val<100){
//printf("monster load no:%d\n",val);
			npc_set(2,val,x,y);
			map[x][y]=0;
		}else if(val>99){
//printf("npc load no:%d\n",val);
			npc_set(1,val,x,y);
			map[x][y]=0;
		}else map[x][y]=1;//���� ���°�..
	}
}







extern void * voidlist_get_first(type_objlist const * const * * save,unsigned short i, unsigned short j)
{
	void * conn;

	if (!save)
		return NULL;
	*save = (type_objlist const * const *)&(mapArray[i][j].objL); /* avoid warning */
	if (!**save)
	{
		*save = NULL;
		return NULL;
	}
	conn = get_node_objlist(**save);
	*save = get_next_node_objlist_const(**save);
	return conn;
}







extern void * voidlist_get_next(type_objlist const * const * * save)
{
	void * conn;

	if (!save)
	return NULL;

	if (!*save || !**save)
	{
		*save = NULL;
		return NULL;
	}
	conn = get_node_objlist(**save);
	*save = get_next_node_objlist_const(**save);
	return conn;
}








extern void mapinit(type_session * c){//ĳ������ġ ��Ʈ
	add_node_objlist(&(mapArray[c->Ax][c->Ay].objL),c);//direct map address access
}






extern void map_char_rm(type_session * c){

	type_objlist * * pos;
	pos =  find_node_objlist(&(mapArray[c->Ax][c->Ay].objL),c);
	if(pos==NULL)
		return;
	rm_objlist(pos);
}







extern int map_char_one_mv(type_session * c,unsigned short x,unsigned short y){//��ĭ�� �̵���Ŵ

	type_objlist * * pos;
	type_objlist * tmp;
	short tx,ty;

	if(x>=S_WIDTH||y>=S_WIDTH){

		 return 0;
	}
	if(x==c->Ax&&y==c->Ay){
		return 0;
	}
	tx = c->Ax - x;
	ty = c->Ay - y;
	if(tx>1||tx<-1||ty>1||ty<-1){

		return 0;
	}
	if(mapArray[c->Ax][c->Ay].objL==NULL){

		return 0;
	}
	pos =  find_node_objlist(&(mapArray[c->Ax][c->Ay].objL),c);
	if(pos==NULL){

		return 0;
	}
	tmp = pop_data(pos);
	if(!tmp){

		return 0;
	}
	insert_node_objlist(&(mapArray[x][y].objL), tmp);
	c->Ax=x;
	c->Ay=y;

	map_bk_sectorinfo(c);	//���ο� �������� �� ���� ������
	map_get_sectorinfo(c);	//���ο� ���� ������� ���� ������ �ޱ�
	item_part_sectinfo(c);	//���ο� ������ ������ ����Ʈ �ޱ�
	npc_chr_mv_addinfo(c);	//���ο� ������ npc����Ʈ �ޱ�

	c->Bx=x;
	c->By=y;
	return 1;
}








extern void map_usersend_All(unsigned short mapSizeX, unsigned short mapSizeY,char * retdata,int len,type_session * c){//��ǥ x,y�� �迭�ּҸ� �޴´�.... chr �� ���ϰ�� ��ο��� ������. chr�� ������� chr�� ���� ������

	int i,j,x,y;
	type_objlist  const * const * tmp_objlist;
	void * tmp_char;	//
	void * ntmp_char;	//
	type_session * tc;
	type_packet	* relaypacket;
	pthread_mutex_lock(&sendQuelock);
	for (i=3;i>0;i--) {
		x = mapSizeX -i+2;
		if(x<0 || x>S_WIDTH-1) continue;

		for(j=3;j>0;j--){
			y = mapSizeY -j+2;
			if(y<0||y>S_WIDTH-1) continue;

			for(tmp_char=voidlist_get_first(&tmp_objlist,x,y); tmp_char; tmp_char=ntmp_char)
			{
				ntmp_char = voidlist_get_next(&tmp_objlist);
				tc = (type_session *)tmp_char;
				if(tc->state==conn_state_destroy) continue;

				if(c==NULL){
					if (!(relaypacket = packet_create())){
				 		pthread_mutex_unlock(&sendQuelock);
				 		return;
					}
					memset(relaypacket->data,0,MAX_PACKET_SIZE);
					relaypacket->size = len;
					relaypacket->cli_sock = tc->sock;
					relaypacket->session = tc;
					memcpy(&relaypacket->data[0],&retdata[0],len);/////////////////////////////
					queue_push_packet_raw(&send_que,relaypacket);//��Ŷ�� ���̰� �� �ִ�..
				}else{
					if(c!=tc){
						if (!(relaypacket = packet_create())){
					 		pthread_mutex_unlock(&sendQuelock);
					 		return;
						}
						memset(relaypacket->data,0,MAX_PACKET_SIZE);
						relaypacket->size = len;
						relaypacket->cli_sock = tc->sock;
						relaypacket->session = tc;
						memcpy(&relaypacket->data[0],&retdata[0],len);/////////////////////////////
						queue_push_packet_raw(&send_que,relaypacket);//��Ŷ�� ���̰� �� �ִ�..
					}
				}// end if(chr==NULL)
			}
		}//inner for loop
	}//end first for loop
	pthread_cond_signal(&sendQuecond);
	pthread_mutex_unlock(&sendQuelock);
}







extern void map_bk_sectorinfo(type_session * c){//character�� ���� �̵����� ���� ���ο� ���Ϳ� ������ �������ش�..

	int x,y;
	int ax,ay,i;
	short dLen=2;
	char udata[128];
	unsigned short	nEnd = PEND;
	type_session * usr;
	type_npc * npc;

	memset(udata,0,128);
	udata[dLen] = PK_OBJ_ADD;//2
	dLen+=1;
	udata[dLen] = T_USER;//obj_type : user	//3
	dLen+=1;
	udata[dLen] = 1;					//4
	dLen+=1;

	memcpy(&udata[dLen],&c->userNo,2);//���⼭���� cnt��ŭ ����
	dLen+=2;
	udata[dLen] = c->nLen;
	dLen+=1;
	memcpy(&udata[dLen],&c->char_name[0],c->nLen);
	dLen+=c->nLen;
	udata[dLen]=c->race;
	dLen+=1;
	udata[dLen]=c->sex;
	dLen+=1;
	udata[dLen]=c->nation;
	dLen+=1;

	memcpy(&udata[dLen],&c->str,2);
	dLen+=2;
	memcpy(&udata[dLen],&c->dex,2);
	dLen+=2;
	memcpy(&udata[dLen],&c->intel,2);
	dLen+=2;
	memcpy(&udata[dLen],&c->hp_c,2);
	dLen+=2;
	memcpy(&udata[dLen],&c->mana_c,2);
	dLen+=2;

	memcpy(&udata[dLen],&c->exp,4);
	dLen+=4;
	memcpy(&udata[dLen],&c->level,2);
	dLen+=2;
	memcpy(&udata[dLen],&c->lvpoint,2);
	dLen+=2;
	memcpy(&udata[dLen],&c->skexp,4);
	dLen+=4;
	udata[dLen]=c->jobno;
	dLen+=1;
	udata[dLen]=c->classno;
	dLen+=1;
	udata[dLen]=c->classlevel;
	dLen+=1;

	memcpy(&udata[dLen],&c->eq[0],2);
	dLen+=2;
	memcpy(&udata[dLen],&c->eq[1],2);
	dLen+=2;
	memcpy(&udata[dLen],&c->eq[2],2);
	dLen+=2;
	memcpy(&udata[dLen],&c->eq[3],2);
	dLen+=2;
	memcpy(&udata[dLen],&c->eq[4],2);
	dLen+=2;
	memcpy(&udata[dLen],&c->coin,4);
	dLen+=4;

	udata[dLen]=c->userStat;
	dLen+=1;
	if(c->userStat==0){//stand
		udata[dLen]=c->Dir;
		dLen+=1;
		memcpy(&udata[dLen],&c->Ax,2);
		dLen+=2;
		memcpy(&udata[dLen],&c->Ay,2);
		dLen+=2;
	}else if(c->userStat==1){//move
		udata[dLen]=c->Dir;
		dLen+=1;
		udata[dLen]=c->moveLevel;
		dLen+=1;
		memcpy(&udata[dLen],&c->Cx,2);
		dLen+=2;
		memcpy(&udata[dLen],&c->Cy,2);
		dLen+=2;
		memcpy(&udata[dLen],&c->Dx,2);
		dLen+=2;
		memcpy(&udata[dLen],&c->Dy,2);
		dLen+=2;
	}else if(c->userStat==2){//fight
		udata[dLen]=c->Dir;
		dLen+=1;
		udata[dLen]=c->tgtype;//Ÿ��Ÿ��
		dLen+=1;
		if(c->tgtype==0){//pk
			usr=(type_session *)c->target;
			memcpy(&udata[dLen],&usr->userNo,2);
			dLen+=2;
		}else{//mon
			npc=(type_npc *)c->target;
			memcpy(&udata[dLen],&npc->npc_id,2);
			dLen+=2;
		}
		memcpy(&udata[dLen],&c->Ax,2);
		dLen+=2;
		memcpy(&udata[dLen],&c->Ay,2);
		dLen+=2;
	}else{//trade, die
		udata[dLen]=c->Dir;
		dLen+=1;
		memcpy(&udata[dLen],&c->Ax,2);
		dLen+=2;
		memcpy(&udata[dLen],&c->Ay,2);
		dLen+=2;
	}

	memcpy(&udata[dLen],&nEnd,2);
	dLen+=2;
	memcpy(&udata[0],&dLen,2);

	x = c->Bx - c->Ax;//0
	y = c->By - c->Ay;//1

	if(x==0 && y<0){// 12�ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			ay = c->Ay +1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH){

				map_secdata_snd(ax, ay, udata, dLen);

			}else continue;

		}//end for loop
	}else if(x<0  && y<0){// 1 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			ay = c->Ay +1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH){
				map_secdata_snd(ax, ay, udata, dLen);
			}else continue;

		}//end for loop

		for(i=0;i<2;i++){
			ax = c->Ax +1;
			ay = c->Ay -i;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH){
				map_secdata_snd(ax, ay, udata, dLen);
			}else continue;
		}//end for loop

	}else if(x<0 && y==0){// 3 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax +1;//28
			ay = c->Ay -i+2;//14

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH){
				map_secdata_snd(ax, ay,udata, dLen);
			}else continue;

		}//end for loop
	}else if(x<0  && y>0){// 4 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			ay = c->Ay -1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH){
				map_secdata_snd(ax, ay, udata, dLen);
			}else continue;

		}//end for loop

		for(i=0;i<2;i++){
			ax = c->Ax +1;
			ay = c->Ay +i;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH){
				map_secdata_snd(ax, ay,udata, dLen);
			}else continue;

		}//end for loop

	}else if(x==0 && y>0){// 6 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			ay = c->Ay -1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH){
				map_secdata_snd(ax, ay, udata, dLen);
			}else continue;

		}//end for loop
	}else if(x>0  && y>0){// 7 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			ay = c->Ay -1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH){
				map_secdata_snd(ax, ay, udata, dLen);
			}else continue;

		}//end for loop

		for(i=0;i<2;i++){
			ax = c->Ax -1;
			ay = c->Ay +i;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH){
				map_secdata_snd(ax, ay, udata, dLen);
			}else continue;

		}//end for loop


	}else if(x>0  && y==0){// 9 �ù���	��

		for(i=3;i>0;i--){

			ax = c->Ax -1;
			ay = c->Ay -i+2;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH){
				map_secdata_snd(ax, ay, udata, dLen);
			}else continue;

		}//end for loop
	}else if(x>0  && y<0){// 10�ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			ay = c->Ay +1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH){
				map_secdata_snd(ax, ay, udata, dLen);
			}else continue;

		}//end for loop

		for(i=0;i<2;i++){
			ax = c->Ax -1;
			ay = c->Ay -i;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH){
				map_secdata_snd(ax, ay, udata, dLen);
			}else continue;

		}//end for loop

	}
}








extern void map_get_sectorinfo(type_session * c){//character�� ���� �̵����� ���� ���ο� ���Ϳ� ������ �޴´�..

	int x,y,ax,ay,i;

	x = c->Bx - c->Ax;
	y = c->By - c->Ay;
	if(x==0 && y<0){// 12�ù���	��
		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			ay = c->Ay +1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd_client(ax, ay,c);
			else continue;
		}//end for loop
	}else if(x<0  && y<0){// 1 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			ay = c->Ay +1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd_client(ax, ay,c);
			else continue;
		}//end for loop

		for(i=0;i<2;i++){
			ax = c->Ax +1;
			ay = c->Ay -i;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd_client(ax, ay,c);
			else continue;
		}//end for loop

	}else if(x<0 && y==0){// 3 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax +1;
			ay = c->Ay -i+2;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd_client(ax, ay,c);
			else continue;
		}//end for loop
	}else if(x<0  && y>0){// 4 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			ay = c->Ay -1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd_client(ax, ay,c);
			else continue;
		}//end for loop

		for(i=0;i<2;i++){
			ax = c->Ax +1;
			ay = c->Ay +i;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd_client(ax, ay,c);
			else continue;
		}//end for loop

	}else if(x==0 && y>0){// 6 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			ay = c->Ay -1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd_client(ax, ay,c);
			else continue;
		}//end for loop
	}else if(x>0  && y>0){// 7 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			ay = c->Ay -1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd_client(ax, ay,c);
			else continue;
		}//end for loop

		for(i=0;i<2;i++){
			ax = c->Ax -1;
			ay = c->Ay +i;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd_client(ax, ay,c);
			else continue;
		}//end for loop


	}else if(x>0  && y==0){// 9 �ù���	��

		for(i=3;i>0;i--){

			ax = c->Ax -1;
			ay = c->Ay -i+2;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd_client(ax, ay,c);
			else continue;
		}//end for loop
	}else if(x>0  && y<0){// 10�ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			ay = c->Ay +1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd_client(ax, ay,c);
			else continue;
		}//end for loop

		for(i=0;i<2;i++){
			ax = c->Ax -1;
			ay = c->Ay -i;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd_client(ax, ay,c);
			else continue;
		}//end for loop

	}
}









extern void map_userDisconn(type_session * c){

	char data[16];
	short dLen = 2,objcnt=1;
	unsigned short	nEnd = PEND;
printf("map_userDisconn\n");
	data[dLen] = 1;
	dLen+=1;
	data[dLen] =RET_TRUE;
	dLen+=1;
	memcpy(&data[dLen],&objcnt,2);
	dLen+=2;
	data[dLen] =1;
	dLen+=1;
	data[dLen] =1;
	dLen+=1;
	memcpy(&data[dLen],&c->userNo,2);
	dLen+=2;
	data[dLen] =1;
	dLen+=1;
	memcpy(&data[dLen],&nEnd,2);
	dLen+=2;
	memcpy(&data[0],&dLen,2);
printf("��Ŀ��Ʈ ��Ŷ������ ������ �ε���..%d\n",c->userNo);
	map_usersend_All(c->Ax,c->Ay,data,dLen,c);
}








extern void map_secdata_snd_client(short ax, short ay,type_session * c){//ax,ay ������ �ѵ� �����͸� Ŭ���̾�Ʈ�� �޴´�.

	type_objlist  const * const * tmp_objlist;
	void * tmp_char;
	void * ntmp_char;
	type_session * tc;
	short objCnt=0,dLen = 2;
	char  udata[MAX_PACKET_SIZE];
	unsigned short	nEnd = PEND;
	type_session * usr;
	type_npc * npc;

	udata[dLen] = PK_OBJ_ADD;//2
	dLen+=1;
	udata[dLen] = T_USER;//obj_type : user	//3
	dLen+=1;
	//udata[dLen] = objCnt;					//4
	dLen+=1;

	for(tmp_char=voidlist_get_first(&tmp_objlist,ax,ay); tmp_char; tmp_char=ntmp_char)
	{
		ntmp_char = voidlist_get_next(&tmp_objlist);
		tc=(type_session *)tmp_char;
		objCnt+=1;

		memcpy(&udata[dLen],&tc->userNo,2);//���⼭���� cnt��ŭ ����
		dLen+=2;
		udata[dLen] = tc->nLen;
		dLen+=1;
		memcpy(&udata[dLen],&tc->char_name[0],tc->nLen);
		dLen+=tc->nLen;
		udata[dLen]=tc->race;
		dLen+=1;
		udata[dLen]=tc->sex;
		dLen+=1;
		udata[dLen]=tc->nation;
		dLen+=1;

		memcpy(&udata[dLen],&tc->str,2);
		dLen+=2;
		memcpy(&udata[dLen],&tc->dex,2);
		dLen+=2;
		memcpy(&udata[dLen],&tc->intel,2);
		dLen+=2;
		memcpy(&udata[dLen],&tc->hp_c,2);
		dLen+=2;
		memcpy(&udata[dLen],&tc->mana_c,2);
		dLen+=2;

		memcpy(&udata[dLen],&tc->exp,4);
		dLen+=4;
		memcpy(&udata[dLen],&tc->level,2);
		dLen+=2;
		memcpy(&udata[dLen],&tc->lvpoint,2);
		dLen+=2;
		memcpy(&udata[dLen],&tc->skexp,4);
		dLen+=4;
		udata[dLen]=tc->jobno;
		dLen+=1;
		udata[dLen]=tc->classno;
		dLen+=1;
		udata[dLen]=tc->classlevel;
		dLen+=1;

		memcpy(&udata[dLen],&tc->eq[0],2);
		dLen+=2;
		memcpy(&udata[dLen],&tc->eq[1],2);
		dLen+=2;
		memcpy(&udata[dLen],&tc->eq[2],2);
		dLen+=2;
		memcpy(&udata[dLen],&tc->eq[3],2);
		dLen+=2;
		memcpy(&udata[dLen],&tc->eq[4],2);
		dLen+=2;
		memcpy(&udata[dLen],&tc->coin,4);
		dLen+=4;

		udata[dLen]=tc->userStat;
		dLen+=1;
		if(tc->userStat==0){//stand
			udata[dLen]=tc->Dir;
			dLen+=1;
			memcpy(&udata[dLen],&tc->Ax,2);
			dLen+=2;
			memcpy(&udata[dLen],&tc->Ay,2);
			dLen+=2;
		}else if(tc->userStat==1){//move
			udata[dLen]=tc->Dir;
			dLen+=1;
			udata[dLen]=tc->moveLevel;
			dLen+=1;
			memcpy(&udata[dLen],&tc->Cx,2);
			dLen+=2;
			memcpy(&udata[dLen],&tc->Cy,2);
			dLen+=2;
			memcpy(&udata[dLen],&tc->Dx,2);
			dLen+=2;
			memcpy(&udata[dLen],&tc->Dy,2);
			dLen+=2;
		}else if(tc->userStat==2){//fight
			udata[dLen]=tc->Dir;
			dLen+=1;
			udata[dLen]=tc->tgtype;//Ÿ��Ÿ��
			dLen+=1;
			if(tc->tgtype==0){//pk
				usr=(type_session *)tc->target;
				memcpy(&udata[dLen],&usr->userNo,2);
				dLen+=2;
			}else{//mon
				npc=(type_npc *)tc->target;
				memcpy(&udata[dLen],&npc->npc_id,2);
				dLen+=2;
			}
			memcpy(&udata[dLen],&tc->Ax,2);
			dLen+=2;
			memcpy(&udata[dLen],&tc->Ay,2);
			dLen+=2;
		}else{//trade,die
			udata[dLen]=tc->Dir;
			dLen+=1;
			memcpy(&udata[dLen],&tc->Ax,2);
			dLen+=2;
			memcpy(&udata[dLen],&tc->Ay,2);
			dLen+=2;
		}

		if(dLen>MAX_PACKET_SIZE-40){
			memcpy(&udata[dLen],&nEnd,2);
			dLen+=2;
			memcpy(&udata[0],&dLen,2);
			udata[4] = objCnt;				//4
			map_pData_snd(c,udata,dLen);
			objCnt=0;
			dLen=5;
		}
	}//end for loop

	if(objCnt>0){
		memcpy(&udata[dLen],&nEnd,2);
		dLen+=2;
		memcpy(&udata[0],&dLen,2);
		udata[4] = objCnt;				//4
		map_pData_snd(c,udata,dLen);
	}
}








extern void map_secdata_snd(short ax, short ay, char *retdata,short dLen){//ax,ay ������ �ѵ����� retdata�� ������.

	type_objlist  const * const * tmp_objlist;
	void * tmp_char;
	void * ntmp_char;
	type_session * tc;
	type_packet	* relaypacket;
//printf("map_secdata_snd\n");
	pthread_mutex_lock(&sendQuelock);
	for(tmp_char=voidlist_get_first(&tmp_objlist,ax,ay); tmp_char; tmp_char=ntmp_char)
	{
		ntmp_char = voidlist_get_next(&tmp_objlist);
		tc = (type_session *)tmp_char;

			if (!(relaypacket = packet_create())){
				pthread_mutex_unlock(&sendQuelock);
		 		return;
			}
			memset(relaypacket->data,0,MAX_PACKET_SIZE);
			relaypacket->size = dLen;
			relaypacket->cli_sock = tc->sock;
			relaypacket->session = tc;
			memcpy(&relaypacket->data[0],&retdata[0],dLen);/////////////////////////////


			queue_push_packet_raw(&send_que,relaypacket);//��Ŷ�� ���̰� �� �ִ�..
//			sendQuedone++;//ť�� �Է� �� �������� �������Ѿߵ�...
	}
	pthread_cond_signal(&sendQuecond);
	pthread_mutex_unlock(&sendQuelock);
}









extern void map_pData_snd(type_session * c, char *retdata,short dLen){//���������� ������...

	type_packet	* relaypacket;

	if(c==NULL) return;

	if (!(relaypacket = packet_create())){
 		return;
	}
	memset(relaypacket->data,0,MAX_PACKET_SIZE);
	relaypacket->size = dLen;
	relaypacket->cli_sock = c->sock;
	relaypacket->session = c;
	memcpy(&relaypacket->data[0],&retdata[0],dLen);/////////////////////////////

	pthread_mutex_lock(&sendQuelock);
	queue_push_packet_raw(&send_que,relaypacket);//��Ŷ�� ���̰� �� �ִ�..
	pthread_cond_signal(&sendQuecond);
	pthread_mutex_unlock(&sendQuelock);

}








extern void map_get_sectorinfo_All(type_session * c){

	int i,j,x,y;
	type_objlist  const * const * tmp_objlist;
	void * tmp_char;	//
	void * ntmp_char;	//
	type_session * tc;
	short objCnt=0,dLen = 2;
	char  udata[MAX_PACKET_SIZE];
	unsigned short	nEnd = PEND;
	type_session * usr;
	type_npc * npc;

	udata[dLen] = PK_OBJ_ADD;				//2
	dLen+=1;
	udata[dLen] = T_USER;//obj_type : user	//3
	dLen+=1;
	//udata[dLen] = objCnt;					//4
	dLen+=1;

	for (i=3;i>0;i--) {
		x = c->Ax -i+2;
		if(x<0 || x>S_WIDTH-1) continue;

		for(j=3;j>0;j--){
			y = c->Ay -j+2;
			if(y<0||y>S_WIDTH-1) continue;

			for(tmp_char=voidlist_get_first(&tmp_objlist,x,y); tmp_char; tmp_char=ntmp_char)
			{
				ntmp_char = voidlist_get_next(&tmp_objlist);
				tc = (type_session *)tmp_char;
				objCnt+=1;

				memcpy(&udata[dLen],&tc->userNo,2);//���⼭���� cnt��ŭ ����
				dLen+=2;
				udata[dLen] = tc->nLen;
				dLen+=1;
				memcpy(&udata[dLen],&tc->char_name[0],tc->nLen);
				dLen+=tc->nLen;
				udata[dLen]=tc->race;
				dLen+=1;
				udata[dLen]=tc->sex;
				dLen+=1;
				udata[dLen]=tc->nation;
				dLen+=1;

				memcpy(&udata[dLen],&tc->str,2);
				dLen+=2;
				memcpy(&udata[dLen],&tc->dex,2);
				dLen+=2;
				memcpy(&udata[dLen],&tc->intel,2);
				dLen+=2;
				memcpy(&udata[dLen],&tc->hp_c,2);
				dLen+=2;
				memcpy(&udata[dLen],&tc->mana_c,2);
				dLen+=2;

				memcpy(&udata[dLen],&tc->exp,4);
				dLen+=4;
				memcpy(&udata[dLen],&tc->level,2);
				dLen+=2;
				memcpy(&udata[dLen],&tc->lvpoint,2);
				dLen+=2;
				memcpy(&udata[dLen],&tc->skexp,4);
				dLen+=4;
				udata[dLen]=tc->jobno;
				dLen+=1;
				udata[dLen]=tc->classno;
				dLen+=1;
				udata[dLen]=tc->classlevel;
				dLen+=1;

				memcpy(&udata[dLen],&tc->eq[0],2);
				dLen+=2;
				memcpy(&udata[dLen],&tc->eq[1],2);
				dLen+=2;
				memcpy(&udata[dLen],&tc->eq[2],2);
				dLen+=2;
				memcpy(&udata[dLen],&tc->eq[3],2);
				dLen+=2;
				memcpy(&udata[dLen],&tc->eq[4],2);
				dLen+=2;
				memcpy(&udata[dLen],&tc->coin,4);
				dLen+=4;

				udata[dLen]=tc->userStat;
				dLen+=1;
				if(tc->userStat==S_STAND){//stand
					udata[dLen]=tc->Dir;
					dLen+=1;
					memcpy(&udata[dLen],&tc->Ax,2);
					dLen+=2;
					memcpy(&udata[dLen],&tc->Ay,2);
					dLen+=2;
				}else if(tc->userStat==S_MOVE){//move
					udata[dLen]=tc->Dir;
					dLen+=1;
					udata[dLen]=tc->moveLevel;
					dLen+=1;
					memcpy(&udata[dLen],&tc->Cx,2);
					dLen+=2;
					memcpy(&udata[dLen],&tc->Cy,2);
					dLen+=2;
					memcpy(&udata[dLen],&tc->Dx,2);
					dLen+=2;
					memcpy(&udata[dLen],&tc->Dy,2);
					dLen+=2;
				}else if(tc->userStat==S_FIGHT){//fight
					udata[dLen]=tc->Dir;
					dLen+=1;

					udata[dLen]=tc->tgtype;//Ÿ��Ÿ��
					dLen+=1;
					if(tc->tgtype==0){//pk
						usr=(type_session *)tc->target;
						memcpy(&udata[dLen],&usr->userNo,2);
						dLen+=2;
					}else{//mon
						npc=(type_npc *)tc->target;
						memcpy(&udata[dLen],&npc->npc_id,2);
						dLen+=2;
					}

					memcpy(&udata[dLen],&tc->Ax,2);
					dLen+=2;
					memcpy(&udata[dLen],&tc->Ay,2);
					dLen+=2;
				}else{//trade
					udata[dLen]=tc->Dir;
					dLen+=1;
					memcpy(&udata[dLen],&tc->Ax,2);
					dLen+=2;
					memcpy(&udata[dLen],&tc->Ay,2);
					dLen+=2;
				}

				if(dLen>MAX_PACKET_SIZE-50){
					memcpy(&udata[dLen],&nEnd,2);
					dLen+=2;
					memcpy(&udata[0],&dLen,2);
					udata[4] = objCnt;				//4
					map_pData_snd(c,udata,dLen);
					objCnt=0;
					dLen=5;
				}
			}
		}//inner for loop
	}//end first for loop

	if(objCnt>0){
		memcpy(&udata[dLen],&nEnd,2);
		dLen+=2;
		memcpy(&udata[0],&dLen,2);
		udata[4] = objCnt;				//4
		map_pData_snd(c,udata,dLen);
	}
}









extern void map_sec_test(){//ax,ay ������ �ѵ����� retdata�� ������.

	type_objlist  const * const * tmp_objlist;
	void * tmp,* ntmp;
	type_session * tc;

	printf("sect 0,0 user list:");
	for(tmp=voidlist_get_first(&tmp_objlist,0,0);tmp;tmp=ntmp)
	{
		ntmp = voidlist_get_next(&tmp_objlist);
		tc = (type_session *)tmp;
		printf(" %s ",tc->userid);
	}
	printf("\n");
}









extern short map_isgo(unsigned short x, unsigned short y){
	if(x>=M_SIZE_X || y>=M_SIZE_X) return 1;
	return map[x][y];
}









extern void map_chrAction_calc(type_session * c){//���� ��ġ���� ������ ���� ���µ� �ʿ��� ��(one)Ÿ�� �̵��� ���Ѵ�.

	short tmpx, tmpy,res,Ax,Ay,DIRx,DIRy;
	tmpx = c->Cx;
	tmpy = c->Cy;

	if(c->move_F_cnt>=GAME_FRAME){//�ӵ��� ���� �̵� ������ ��������..

		DIRx = c->Cx - c->Dx;
		DIRy = c->Cy - c->Dy;

		if(DIRx==0 && DIRy<0){
			c->Dir= 4;	// 12�ù���(���� �´°�)
			tmpy +=1;
		}else if(DIRx<0  && DIRy<0){
			c->Dir= 3;	// 1 �ù���
		 	tmpx +=1;
			tmpy +=1;
		}else if(DIRx<0 && DIRy==0){
			c->Dir= 2;	// 3 �ù���
		 	tmpx +=1;
		}else if(DIRx<0  && DIRy>0){
			c->Dir= 1;	// 5 �ù���
		 	tmpx +=1;
			tmpy -=1;
		}else if(DIRx==0 && DIRy>0){
			c->Dir= 0;	// 6 �ù���
			tmpy -=1;
		}else if(DIRx>0  && DIRy>0){
			c->Dir= 7;	// 7 �ù���
		 	tmpx -=1 ;
			tmpy -=1;
		}else if(DIRx>0  && DIRy==0){
			c->Dir= 6;	// 9 �ù���
		 	tmpx -=1;
		}else if(DIRx>0  && DIRy<0){
			c->Dir= 5;	// 11�ù���
		 	tmpx -=1;
			tmpy +=1;
		}

		if( tmpx<0 || tmpx >= M_SIZE_X || tmpy<0 || tmpy >=M_SIZE_X) return;//�ٱ��ʿ��� ��������..
		res = map_isgo(tmpx,tmpy);
//printf("map_chrAction_calc %d\n",res);
		if(res==0){
			printf("CHR_MOV %s�� %d,%d���� %d,%d�� �̵�\n",c->userid,c->Cx,c->Cy,tmpx,tmpy);
			c->Cx=tmpx;
			c->Cy=tmpy;
			Ax=tmpx/S_UNITSIZE;//������ǥx
			Ay=tmpy/S_UNITSIZE;//������ǥy
			if(c->Ax!=Ax||c->Ay!=Ay){
				map_char_one_mv(c,Ax,Ay);
			}
		}
		c->move_F_cnt = 0;
	}else c->move_F_cnt++;
}










extern short map_ret_dist(unsigned short x, unsigned short y,unsigned short xx, unsigned short yy ){
	short dx,dy,tmp;

	if(x>=M_SIZE_X||xx>=M_SIZE_X||y>=M_SIZE_X||yy>=M_SIZE_X) return -1;

	dx=xx-x;
	dy=yy-y;
	tmp = dx*dx+dy*dy;
	tmp = sqrt(tmp);
	return tmp;
}


extern short map_ret_chrdist(unsigned short Ax, unsigned short Ay,unsigned short idx){

	int i,j,x,y;
	short dx,dy,tmp;
	type_objlist  const * const * tmp_objlist;
	void * tmp_char;
	void * ntmp_char;
	type_session * c;

	for (i=3;i>0;i--) {
		x = Ax -i+2;
		if(x<0 || x>S_WIDTH-1) continue;
		for(j=3;j>0;j--){
			y = Ay -j+2;
			if(y<0||y>S_WIDTH-1) continue;
			for(tmp_char=voidlist_get_first(&tmp_objlist,x,y); tmp_char; tmp_char=ntmp_char)
			{
				ntmp_char = voidlist_get_next(&tmp_objlist);
				c = (type_session *)tmp_char;
				if(c->userNo == idx){
					dx=c->Cx-x;
					dy=c->Cy-y;
					tmp = dx*dx+dy*dy;
					tmp = sqrt(tmp);
					return tmp;
				}
			}
		}
	}
	return -1;
}









//extern short map_in_ischr(type_session * c){//�ɸ��Ͱ� �ִ� ���̳�?

//	if(c->Ptid==1) return 1;
//	else return 0;
//}

extern void * map_ret_Activ_tg(unsigned short npcx, unsigned short npcy,unsigned short sight){//������ ���Ϳ��� ��ó���� ���� �������� �̴´�.

	int i,j,x,y;
	type_objlist  const * const * tmp_objlist;
	void * tmp_char;	//
	void * ntmp_char;	//
	type_session * c;
	unsigned short Len;
	unsigned short mapSizeX,mapSizeY;

	mapSizeX=npcx/S_UNITSIZE;
	mapSizeY=npcy/S_UNITSIZE;
	for (i=3;i>0;i--) {
		x = mapSizeX -i+2;
		if(x<0 || x>S_WIDTH-1) continue;

		for(j=3;j>0;j--){
			y = mapSizeY -j+2;
			if(y<0||y>S_WIDTH-1) continue;

			for(tmp_char=voidlist_get_first(&tmp_objlist,x,y); tmp_char; tmp_char=ntmp_char)
			{
				ntmp_char = voidlist_get_next(&tmp_objlist);
				c = (type_session *)tmp_char;
				Len = map_ret_dist(npcx, npcy, c->Cx,c->Cy);
				if(sight>=Len){
					return c;
				}
			}
		}
	}//end first for loop
	return NULL;
}









extern type_session * map_ret_chr(unsigned short Ax,unsigned short Ay,unsigned short tidx){

	int i,j,x,y;
	type_objlist  const * const * tmp_objlist;
	void * tmp_char;
	void * ntmp_char;
	type_session * c;

	for (i=3;i>0;i--) {
		x = Ax -i+2;
		if(x<0 || x>S_WIDTH-1) continue;
		for(j=3;j>0;j--){
			y = Ay -j+2;
			if(y<0||y>S_WIDTH-1) continue;
			for(tmp_char=voidlist_get_first(&tmp_objlist,x,y); tmp_char; tmp_char=ntmp_char)
			{
				ntmp_char = voidlist_get_next(&tmp_objlist);
				c = (type_session *)tmp_char;
				if(c->userNo == tidx){
					return c;
				}
			}
		}
	}
	return NULL;
}









extern void map_party_sendAll(void * chrr,char * data,int len){

	type_session * master=NULL;
	type_session * tchr=NULL;

	master=(type_session *)chrr;

	if(master==NULL) return;
	if(master->party.ison1==1){//party member
		master=(type_session *)master->party.master;
	}

	map_pData_snd(master, data,len);
	if(master->party.ison2==1){
		tchr=(type_session *)master->party.mem2;
		if(tchr!=NULL) map_pData_snd(tchr, data,len);
	}
	if(master->party.ison3==1){
		tchr=(type_session *)master->party.mem3;
		if(tchr!=NULL) map_pData_snd(tchr, data,len);
	}
}









extern void map_party_sendAll_EXCEPT(void * chrr,char * data,int len){

	type_session * master;
	type_session * chr;
	type_session * tchr;

	chr=(type_session *)chrr;

	if(chr==NULL) return;

	if(chr->party.ison1==1){//party member
		master=(type_session *)chr->party.master;
		if(master) map_pData_snd(master, data,len);
		else return;
		if(master->party.ison2==1&&chr->party.ison2!=2){
			tchr=(type_session *)master->party.mem2;
			if(tchr!=NULL) map_pData_snd(tchr, data,len);
		}
		if(master->party.ison3==1&&chr->party.ison3!=2){
			tchr=(type_session *)master->party.mem3;
			if(tchr!=NULL) map_pData_snd(tchr, data,len);
		}
	}else{//master
		master=(type_session *)chrr;
		if(master==NULL) return;
		if(master->party.ison2==1){
			tchr=(type_session *)master->party.mem2;
			if(tchr!=NULL) map_pData_snd(tchr, data,len);
		}
		if(master->party.ison3==1){
			tchr=(type_session *)master->party.mem3;
			if(tchr!=NULL) map_pData_snd(tchr, data,len);
		}
	}
}




