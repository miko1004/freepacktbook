#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/select.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <math.h>
#include <mysql.h>

#include "svr.h"
#include "map.h"
#include "db.h"
#include "item.h"

static type_npc 	 * npcArray[_MAX_MONSTER_NO];//����� ��( ������ npc����Ʈ) �迭 �ʱ�ȭ �ʿ�!!
static type_npcmap	mapNpcArray[S_WIDTH][S_WIDTH];
static type_gnpc 		def_mon[21];//���� ���� ����Ʈ
static type_gnpc 		def_npc[1];//NPC ���� ����Ʈ
static int				npc_cnt=0;
static short			mon=0,npc=0;



extern void * voidnpclist_get_first(type_objlist const * const * * save,unsigned short i, unsigned short j)
{
    void * conn;

    if (!save)
	return NULL;

    *save = (type_objlist const * const *)&(mapNpcArray[i][j].objL); /* avoid warning */

    if (!**save)
    {
	*save = NULL;
	return NULL;
    }
    conn = get_node_objlist(**save);
    *save = get_next_node_objlist_const(**save);

    return conn;
}






extern void * voidnpclist_get_next(type_objlist const * const * * save)
{
    void * conn;

    if (!save)
	return NULL;

    if (!*save || !**save)
    {
	*save = NULL;
	return NULL;
    }
    conn = get_node_objlist(**save);
    *save = get_next_node_objlist_const(**save);

    return conn;
}







extern void npc_set_def(char div, short no, char gtype, char level, char speed, short * item, char * rate){

	if(div==0){//npc
		def_npc[no].no=no;
		def_npc[no].gtype=gtype;
		def_npc[no].level=level;
		def_npc[no].speed=speed;
		memcpy(&def_npc[no].item,&item,24);//short 2  2*12
		memcpy(&def_npc[no].rate,&rate,12);
	}else{//monster
		def_mon[no].no=no;
		def_mon[no].gtype=gtype;
		def_mon[no].level=level;
		def_mon[no].speed=speed;
		memcpy(&def_mon[no].item,&item,24);//short 2  2*12
		memcpy(&def_mon[no].rate,&rate,12);
	}
}







extern void npc_set(char div,short no,short x,short y){//char gtype, char level, char speed,

	type_npc * temp=NULL;
	char level=0;


	if (!(temp = malloc(sizeof(type_npc)))){
		printf("�޸��Ҵ� ����\n");
		return;
	}
	temp->div		=	div;

	if(div==1){
		no=no-100;
		temp->npc_id=npc;
		npc+=1;
		temp->speed	= def_npc[no].speed;
		temp->gtype	= def_npc[no].gtype;
	}else{
		no=no-10;
		temp->npc_id=mon;
		mon+=1;
		temp->speed	= def_mon[no].speed;
		temp->gtype	= def_mon[no].gtype;
	}
	temp->x 						= x;
	temp->y						= y;
	temp->dx						= x;
	temp->dy						= y;
	temp->DirLoc				= 0;
	temp->ARx					= x/S_UNITSIZE;
	temp->ARy					= y/S_UNITSIZE;
	temp->BSx					= temp->ARx;
	temp->BSy					= temp->ARy;
	temp->Gx						= x;
	temp->Gy						= y;
	temp->level					= level;

	temp->sk_stat				= S_STAND;
	temp->mvstatus				= 0;
	temp->targetChr			= NULL;
	temp->tgFlag				= 0;
	temp->recov_F_cnt			= 0;
	temp->move_F_cnt			= 0;
	temp->heat_F_cnt			= 0;
	temp->active_F_cnt		= 0;
	temp->rotate_F_cnt		= 0;
	temp->ret_F_cnt			= 0;
	temp->wait_F_cnt			= 0;
	temp->regen_F_cnt			= 0;

	switch(temp->gtype){
		case 0:
		temp->tHP				= level * 50;
		temp->HP					= temp->tHP;
		temp->AP					= level + 10;
		temp->DP					= level + 10;
		temp->EXP				= level * 10;
		temp->Sight				= 5;
		temp->tgLen				= 1;
		temp->bat_type			= 0;
		break;
		case 1:
		temp->tHP				= level * 60;
		temp->HP					= temp->tHP;
		temp->AP					= level + 12;
		temp->DP					= level + 12;
		temp->EXP				= level * 12;
		temp->Sight				= 6;
		temp->tgLen				= 2;
		temp->bat_type			= 0;
		break;
		case 2:
		temp->tHP				= level * 70;
		temp->HP					= temp->tHP;
		temp->AP					= level + 14;
		temp->DP					= level + 14;
		temp->EXP				= level * 14;
		temp->Sight				= 7;
		temp->tgLen				= 2;
		temp->bat_type			= 0;
		break;
		case 3:
		temp->tHP				= level * 70;
		temp->HP					= temp->tHP;
		temp->AP					= level + 16;
		temp->DP					= level + 16;
		temp->EXP				= level * 16;
		temp->Sight				= 8;
		temp->tgLen				= 3;
		temp->bat_type			= 0;
		break;
	}

	npcArray[npc_cnt] =temp;
	npc_mapinit(npcArray[npc_cnt]);//��ġ����
	npc_cnt+=1;
printf("npc �߰� ���� ī��Ʈ:%d type:%d speed:%d,no:%d %d,%d\n",npc_cnt,temp->div,temp->speed,no,temp->x,temp->y);
}







extern void npc_mapinit(type_npc * npc){//npc��ġ ��Ʈ
	npc->ARx = npc->x/S_UNITSIZE;
	npc->ARy = npc->y/S_UNITSIZE;
	add_node_objlist(&(mapNpcArray[npc->ARx][npc->ARy].objL),npc);//direct map address access
}






void * Thread_npc_sync(void *arg){//syncronizer thread for npc

	struct timeval start,stop;
	long	tmp,utmp;
	int 	i,j,state;
	type_session * tgChr;
	type_npc * tmpNpc;
	MYSQL * conn;
	MYSQL mysql;
	short rotate_time = GAME_FRAME*5;//5��
	short Rest = 0,torf=0,dist=0;
	//int cnt=0;

	for(i=0;i<_MAX_MONSTER_NO;i++){
		npcArray[i]=NULL;
	}
	conn = mysql_connect(&mysql, _DBSERV, _DBID, _DBPASS);
	if( conn == NULL ) {
		printf("mysql error in connection\n");
		return 0;
	}

	state = mysql_select_db(conn,_DBDB);
	if( state == -1 ) {
		printf("mysql select db error %s\n",mysql_error(conn));
		mysql_close(conn);
		return 0;
	}
/*
	mysql_init(&mysql);
	conn = mysql_real_connect(&mysql, _DBSERV, _DBID, _DBPASS,_DBDB,3306,NULL,0);
	if( conn == NULL ) {
		printf(mysql_error(&mysql));
	}
*/
	db_load_npcList(conn);//from db.c
	map_Load();
	db_load_skillList(conn);
	db_load_itemList(conn);
	mysql_close(conn);
	printf("npc �Ѽ�:%d\n",npc_cnt);
	sleep(2);
	for(;;){
		gettimeofday(&start,NULL);
		pthread_mutex_lock(&npclock);
		for(i=0;i<npc_cnt; i++)//linked list syncronize
		{
/*if(i==1){
	cnt+=1;
	if(cnt>GAME_FRAME){
		cnt=0;
		printf("%d�� NPC status:%d, div:%d speed:%d\n",i,npcArray[i]->status,npcArray[i]->div,npcArray[i]->speed);
	}
}*/
			if(npcArray[i]==NULL) continue;
			if(npcArray[i]->div==1||npcArray[i]->div==0) continue;//npc
			if(npcArray[i]->status==S_DIE){//��������

				if(npcArray[i]->regen_F_cnt>REGEN){
					npc_regen(i);//��Ȱ
					npcArray[i]->mvstatus = 0;
				}else npcArray[i]->regen_F_cnt++;
				continue;

			}else if(npcArray[i]->status==S_FIGHT){

				tgChr = (type_session *)npcArray[i]->targetChr;
				dist =map_ret_dist(npcArray[i]->x,npcArray[i]->y,tgChr->Cx,tgChr->Cy);//npc�� �ɸ����� �Ÿ� ����

				if(dist<0){
					npcArray[i]->targetChr =NULL;
					npcArray[i]->status=S_STAND;
					npcArray[i]->mvstatus = 0;
					continue;
				}

				if(npcArray[i]->tgLen>=dist){//Ÿ�ݰŸ� ���� �����Ƿ� Ÿ���� �Ѵ�. -->send list square
					if(npcArray[i]->heat_F_cnt>=_ONE_SEC){
						npc_attack_chr(tgChr,i);//attack
						npcArray[i]->move_F_cnt=0;
						npcArray[i]->heat_F_cnt=0;
						npcArray[i]->wait_F_cnt=0;
						npcArray[i]->mvstatus = 0;
					}else npcArray[i]->heat_F_cnt++;
				}else if(dist<_NPC_TGT_SIG){//�߰ݹ��� ���� �������

					npc_mv_set(i);
					continue;

				}else{//Ÿ���� �þ߿��� ���������..���..
					npcArray[i]->status=S_STAND;
					npcArray[i]->mvstatus = 0;
					npcArray[i]->tgFlag= 0;
				}
				continue;

			}else{//�����̳� ���� ���°� �ƴҰ�� - ��������� �ΰ�����...

				if(npcArray[i]->bat_type==T_ACTIVE){//�����ϴ� ������ ó��(�ش���� ������ �ൿ�ϰ� �ƴϸ� �׳� �ΰ�����)
					if((npcArray[i]->targetChr =map_ret_Activ_tg(npcArray[i]->x, npcArray[i]->y,npcArray[i]->Sight))!=NULL){//��ó�� Ÿ���� ������ �������� ����...
						tgChr = (type_session *)npcArray[i]->targetChr;
						npcArray[i]->targetNO = tgChr->userNo;
						npcArray[i]->status = S_FIGHT;
						npcArray[i]->tgFlag= 1;
						continue;
					}
				}else if(npcArray[i]->bat_type==T_GROUP){//������ npc(������ �ƴ����� �������� �ο�� ���� ���� �ο�)
					if((tmpNpc=npc_ret_fight(i))!=NULL){
						npcArray[i]->targetNO= tmpNpc->targetNO;
						npcArray[i]->targetChr= tmpNpc->targetChr;
						npcArray[i]->status = S_FIGHT;
						npcArray[i]->tgFlag= 1;
					}
				}

				if(npcArray[i]->status==S_MOVE){
					if(npcArray[i]->dx!=npcArray[i]->x||npcArray[i]->dy!=npcArray[i]->y){
						npc_mv_set(i);
						continue;
					}else{
						npcArray[i]->move_F_cnt=0;
						npcArray[i]->rotate_F_cnt=0;
						npcArray[i]->status=S_STAND;
						npcArray[i]->mvstatus = 0;

					}
				}else{//S_STAND.. �ð����Ŀ� ������ ���ϴ� ����...

					if(npcArray[i]->rotate_F_cnt > rotate_time){//�����̰� ������ �����϶�
						npcArray[i]->ret_F_cnt+=1;//��ȸ�� ī����..
						if(npcArray[i]->ret_F_cnt>10){//10�� ���� �ٳ����� ������ ��ġ�� ���ư���..
if(i==17){printf("NPC 8 ������������ �ǵ��ư��� Ÿ�̹�\n");}
							npcArray[i]->ret_F_cnt=0;
							npcArray[i]->dx = npcArray[i]->Gx;
							npcArray[i]->dy = npcArray[i]->Gy;
						}else{
							Rest+=1;
							if(Rest>7) Rest=0;
							switch(Rest){
								case 0:
									npcArray[i]->dx = npcArray[i]->x-5;
									npcArray[i]->dy = npcArray[i]->y;
								break;
								case 1:
									npcArray[i]->dx = npcArray[i]->x-5;
									npcArray[i]->dy = npcArray[i]->y+5;
								break;
								case 2:
									npcArray[i]->dx = npcArray[i]->x+5;
									npcArray[i]->dy = npcArray[i]->y-5;
								break;
								case 3:
									npcArray[i]->dx = npcArray[i]->x-5;
									npcArray[i]->dy = npcArray[i]->y-5;
								break;
								case 4:
									npcArray[i]->dx = npcArray[i]->x+5;
									npcArray[i]->dy = npcArray[i]->y+5;
								break;

								case 5:
									npcArray[i]->dx = npcArray[i]->x;
									npcArray[i]->dy = npcArray[i]->y-5;
								break;
								case 6:
									npcArray[i]->dx = npcArray[i]->x+5;
									npcArray[i]->dy = npcArray[i]->y;
								break;
								case 7:
									npcArray[i]->dx = npcArray[i]->x;
									npcArray[i]->dy = npcArray[i]->y+5;
								break;
							}
						}
						j=0;
						while(1){
							torf = map_isgo(npcArray[i]->dx, npcArray[i]->dy);//�̵���������?
							if(torf==0){//�̵�����
if(i==17) printf("%d�� NPC�� �̵� ������ �� ����:%d,%d��ǥ����:%d,%d\n",i,npcArray[i]->x, npcArray[i]->y,npcArray[i]->dx, npcArray[i]->dy);
								npcArray[i]->status=S_MOVE;
								npcArray[i]->mvstatus=0;
								break;
							}else{//�̵� �Ұ�
								if(npcArray[i]->dx>=M_SIZE_X)
									npcArray[i]->dx = npcArray[i]->dx+5;
								else if(npcArray[i]->dy>=M_SIZE_X)
									npcArray[i]->dy = npcArray[i]->dy+5;
								else{
									npcArray[i]->dy = npcArray[i]->dy+5;
									npcArray[i]->dx = npcArray[i]->dx+5;
								}
if(i==17) printf("%d�� NPC�� �̵� �Ұ��� ��ǥ���� �ٽ� ã�� ����:%d,%d��ǥ����:%d,%d\n",i,npcArray[i]->x, npcArray[i]->y,npcArray[i]->dx, npcArray[i]->dy);
							}
							if(j==20){//���ѷ��� ����
								npcArray[i]->status=S_STAND;
								break;
							}
							j++;
						}

						if(npcArray[i]->dx==npcArray[i]->x&&npcArray[i]->dy==npcArray[i]->y){
							npcArray[i]->status=S_STAND;
						}else{
							npcArray[i]->mvstatus=0;
							npcArray[i]->status=S_MOVE;
						}
						npcArray[i]->rotate_F_cnt = 0;
					}else npcArray[i]->rotate_F_cnt++;

					if(npcArray[i]->HP!=npcArray[i]->tHP){//recover
						if(npcArray[i]->HP>npcArray[i]->tHP){
							npcArray[i]->HP = npcArray[i]->tHP;
							continue;
						}else{
							npcArray[i]->recov_F_cnt++;
							if(npcArray[i]->recov_F_cnt>30){
								npcArray[i]->HP++;
								npcArray[i]->recov_F_cnt=0;
							}
						}
					}
				}
			}////�����̳� ���� ���°� �ƴҰ�� - ��������� �ΰ�����... end
		}

		pthread_mutex_unlock(&npclock);
		gettimeofday(&stop,NULL);
		tmp = stop.tv_sec - start.tv_sec;
		utmp = stop.tv_usec - start.tv_usec;
		if(tmp>1){
		}else if(tmp==1){
			utmp = 1000000 + utmp;
			if(utmp<AFRAME){
				stop.tv_sec=0;
				stop.tv_usec=AFRAME-utmp;
//printf("NPC THREAD SLEEP time: %ld\n",stop.tv_usec);
				select(0, NULL, NULL, NULL, &stop);
			}
		}else{
			if(utmp<AFRAME){
				stop.tv_sec=0;
				stop.tv_usec=AFRAME-utmp;
//printf("NPC THREAD SLEEP time: %ld\n",stop.tv_usec);
				select(0, NULL, NULL, NULL, &stop);
			}
		}
	}//end for loop
}







//�ɸ����� ���� �̵����� ���� ���ο� ���Ϳ� NPC ������ �޴´�..
extern void npc_chr_mv_addinfo(void * session){

	int x,y,ax,ay,i;
	type_session * chr;

	chr = (type_session *)session;
	x = chr->Bx - chr->Ax;
	y = chr->By - chr->Ay;
	if(x==0 && y<0){// 12�ù���	��

		for(i=3;i>0;i--){
			ax = chr->Ax -i+2;
			ay = chr->Ay +1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				npc_1x1_sectorinfo(ax, ay,chr);
			else continue;
		}//end for loop
	}else if(x<0  && y<0){// 1 �ù���	��

		for(i=3;i>0;i--){
			ax = chr->Ax -i+2;
			ay = chr->Ay +1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				npc_1x1_sectorinfo(ax, ay,chr);
			else continue;
		}//end for loop

		for(i=0;i<2;i++){
			ax = chr->Ax +1;
			ay = chr->Ay -i;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				npc_1x1_sectorinfo(ax, ay,chr);
			else continue;
		}//end for loop

	}else if(x<0 && y==0){// 3 �ù���	��

		for(i=3;i>0;i--){
			ax = chr->Ax +1;
			ay = chr->Ay -i+2;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				npc_1x1_sectorinfo(ax, ay,chr);
			else continue;
		}//end for loop
	}else if(x<0  && y>0){// 4 �ù���	��

		for(i=3;i>0;i--){
			ax = chr->Ax -i+2;
			ay = chr->Ay -1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				npc_1x1_sectorinfo(ax, ay,chr);
			else continue;
		}//end for loop

		for(i=0;i<2;i++){
			ax = chr->Ax +1;
			ay = chr->Ay +i;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				npc_1x1_sectorinfo(ax, ay,chr);
			else continue;
		}//end for loop

	}else if(x==0 && y>0){// 6 �ù���	��

		for(i=3;i>0;i--){
			ax = chr->Ax -i+2;
			ay = chr->Ay -1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				npc_1x1_sectorinfo(ax, ay,chr);
			else continue;
		}//end for loop
	}else if(x>0  && y>0){// 7 �ù���	��

		for(i=3;i>0;i--){
			ax = chr->Ax -i+2;
			ay = chr->Ay -1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				npc_1x1_sectorinfo(ax, ay,chr);
			else continue;
		}//end for loop

		for(i=0;i<2;i++){
			ax = chr->Ax -1;
			ay = chr->Ay +i;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				npc_1x1_sectorinfo(ax, ay,chr);
			else continue;
		}//end for loop


	}else if(x>0  && y==0){// 9 �ù���	��

		for(i=3;i>0;i--){

			ax = chr->Ax -1;
			ay = chr->Ay -i+2;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				npc_1x1_sectorinfo(ax, ay,chr);
			else continue;
		}//end for loop
	}else if(x>0  && y<0){// 10�ù���	��

		for(i=3;i>0;i--){
			ax = chr->Ax -i+2;
			ay = chr->Ay +1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				npc_1x1_sectorinfo(ax, ay,chr);
			else continue;
		}//end for loop

		for(i=0;i<2;i++){
			ax = chr->Ax -1;
			ay = chr->Ay -i;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				npc_1x1_sectorinfo(ax, ay,chr);
			else continue;
		}//end for loop

	}
}







//Ŭ���̾�Ʈ���� ������ npc������ �����ش�.
extern void npc_1x1_sectorinfo(unsigned short x, unsigned short y,void * session){

	type_objlist  const * const * tmp_objlist;
	void * ntmp_npc;
	type_session * chr;
	type_npc * tmp_npc;
	unsigned short objCnt=0;
	short Len=2,tmp;
	char retdata[MAX_PACKET_SIZE];
	unsigned short	nEnd = PEND;

	chr = (type_session *)session;

	retdata[Len] = PK_OBJ_ADD;				//2
	Len+=1;
	retdata[Len] = T_NPC;//obj_type : NPC	//3
	Len+=1;
	//retdata[Len] = objCnt;				//4
	Len+=1;
	tmp = 1024-40;
	for(tmp_npc=voidnpclist_get_first(&tmp_objlist,x,y); tmp_npc; tmp_npc=ntmp_npc)
	{
		tmp_npc = (type_npc *)tmp_npc;
		ntmp_npc = voidnpclist_get_next(&tmp_objlist);
		if(tmp_npc->status==S_DIE) continue;
		objCnt+=1;
		retdata[Len] = tmp_npc->div;//������ npc����
		Len+=1;
		retdata[Len] = tmp_npc->gtype;//����Ÿ��
		Len+=1;
		memcpy(&retdata[Len],&tmp_npc->npc_id,2);
		Len+=2;
		memcpy(&retdata[Len],&tmp_npc->level,2);
		Len+=2;
		memcpy(&retdata[Len],&tmp_npc->tHP,2);
		Len+=2;
		memcpy(&retdata[Len],&tmp_npc->HP,2);
		Len+=2;
		memcpy(&retdata[Len],&tmp_npc->AP,2);
		Len+=2;
		retdata[Len] = tmp_npc->status;
		Len+=1;
		retdata[Len] = tmp_npc->DirLoc;
		Len+=1;

		if(tmp_npc->status==S_STAND){//stand
			memcpy(&retdata[Len],&tmp_npc->x,2);
			Len+=2;
			memcpy(&retdata[Len],&tmp_npc->y,2);
			Len+=2;
		}else if(tmp_npc->status==S_MOVE){//move
			retdata[Len] = tmp_npc->DirLoc;
			Len+=1;
			retdata[Len] = tmp_npc->speed;
			Len+=1;
			memcpy(&retdata[Len],&tmp_npc->x,2);
			Len+=2;
			memcpy(&retdata[Len],&tmp_npc->y,2);
			Len+=2;
			memcpy(&retdata[Len],&tmp_npc->dx,2);
			Len+=2;
			memcpy(&retdata[Len],&tmp_npc->dy,2);
			Len+=2;
		}else if(tmp_npc->status==S_FIGHT){//fight
			memcpy(&retdata[Len],&tmp_npc->x,2);
			Len+=2;
			memcpy(&retdata[Len],&tmp_npc->y,2);
			Len+=2;
			memcpy(&retdata[Len],&tmp_npc->targetNO,2);
			Len+=2;
		}

		if(Len>tmp){
			memcpy(&retdata[Len],&nEnd,2);
			Len+=2;
			retdata[4] = objCnt;
			Len+=1;
			memcpy(&retdata[0],&Len,2);
			map_pData_snd(chr,retdata,Len);
			Len=5;
			objCnt=0;
		}
	}

	if(objCnt>0){
		memcpy(&retdata[Len],&nEnd,2);
		Len+=2;
		retdata[4] = objCnt;
		Len+=1;
		memcpy(&retdata[0],&Len,2);
		map_pData_snd(chr,retdata,Len);
	}
}








//9�� ������ ���� ������ �����ش�.�ɸ� ó�� �����..
extern void npc_3x3_secterinfo(void * session){

	int i,j,x,y;
	type_objlist  const * const * tmp_objlist;
	void * ntmp_npc;	//
	type_session * chr;
	type_npc * tmp_npc;
	unsigned short objCnt=0;
	short Len,tmp;
	char retdata[MAX_PACKET_SIZE];
	unsigned short	nEnd = PEND;

	chr = (type_session *)session;

	retdata[Len] = PK_OBJ_ADD;				//2
	Len+=1;
	retdata[Len] = T_NPC;//obj_type : NPC	//3
	Len+=1;
	//retdata[Len] = objCnt;				//4
	Len+=1;
	tmp = 1024-40;
	for (i=3;i>0;i--) {
		x = chr->Ax -i+2;
		if(x<0 || x>S_WIDTH-1) continue;

		for(j=3;j>0;j--){
			y = chr->Ay -j+2;
			if(y<0||y>S_WIDTH-1) continue;

			for(tmp_npc=voidnpclist_get_first(&tmp_objlist,x,y); tmp_npc; tmp_npc=ntmp_npc)
			{
				tmp_npc = (type_npc *)tmp_npc;
				ntmp_npc = voidnpclist_get_next(&tmp_objlist);
				if(tmp_npc->status==S_DIE) continue;
				objCnt+=1;
				retdata[Len] = tmp_npc->div;//������ npc����
				Len+=1;
				retdata[Len] = tmp_npc->gtype;//����Ÿ��
				Len+=1;
				memcpy(&retdata[Len],&tmp_npc->npc_id,2);
				Len+=2;
				memcpy(&retdata[Len],&tmp_npc->level,2);
				Len+=2;
				memcpy(&retdata[Len],&tmp_npc->tHP,2);
				Len+=2;
				memcpy(&retdata[Len],&tmp_npc->HP,2);
				Len+=2;
				memcpy(&retdata[Len],&tmp_npc->AP,2);
				Len+=2;
				retdata[Len] = tmp_npc->status;
				Len+=1;
				retdata[Len] = tmp_npc->DirLoc;
				Len+=1;

				if(tmp_npc->status==S_STAND){//stand
					memcpy(&retdata[Len],&tmp_npc->x,2);
					Len+=2;
					memcpy(&retdata[Len],&tmp_npc->y,2);
					Len+=2;
				}else if(tmp_npc->status==S_MOVE){//move
					retdata[Len] = tmp_npc->DirLoc;
					Len+=1;
					retdata[Len] = tmp_npc->speed;
					Len+=1;
					memcpy(&retdata[Len],&tmp_npc->x,2);
					Len+=2;
					memcpy(&retdata[Len],&tmp_npc->y,2);
					Len+=2;
					memcpy(&retdata[Len],&tmp_npc->dx,2);
					Len+=2;
					memcpy(&retdata[Len],&tmp_npc->dy,2);
					Len+=2;
				}else if(tmp_npc->status==S_FIGHT){//fight
					memcpy(&retdata[Len],&tmp_npc->x,2);
					Len+=2;
					memcpy(&retdata[Len],&tmp_npc->y,2);
					Len+=2;
					memcpy(&retdata[Len],&tmp_npc->targetNO,2);
					Len+=2;
				}

				if(Len>tmp){
					memcpy(&retdata[Len],&nEnd,2);
					Len+=2;
					retdata[4] = objCnt;
					Len+=1;
					memcpy(&retdata[0],&Len,2);
					map_pData_snd(chr,retdata,Len);
					Len=5;
					objCnt=0;
				}
			}
		}
	}
	if(objCnt>0){
		memcpy(&retdata[Len],&nEnd,2);
		Len+=2;
		retdata[4] = objCnt;
		Len+=1;
		memcpy(&retdata[0],&Len,2);
		map_pData_snd(chr,retdata,Len);
	}
}








//npc�� ���� �̵����� ���� ���ο� ���Ϳ� ������ �������ش�..
extern void npc_mv_addinfo(type_npc * npc){

	int x,y;
	int ax,ay,i;
	short dLen=2;
	char udata[128];
	unsigned short	nEnd = PEND;

	udata[dLen] = PK_OBJ_ADD;
	dLen+=1;
	udata[dLen] = T_NPC;//NPC
	dLen+=1;
	udata[dLen] = 1;
	dLen+=1;
	udata[dLen] = npc->div;
	dLen+=1;
	udata[dLen] = npc->gtype;
	dLen+=1;
	memcpy(&udata[dLen],&npc->npc_id,2);
	dLen+=2;
	memcpy(&udata[dLen],&npc->level,2);
	dLen+=2;
	memcpy(&udata[dLen],&npc->tHP,2);
	dLen+=2;
	memcpy(&udata[dLen],&npc->HP,2);
	dLen+=2;
	udata[dLen] = npc->status;
	dLen+=1;
	udata[dLen] = npc->DirLoc;
	dLen+=1;
	if(npc->status==S_STAND){//stand
		memcpy(&udata[dLen],&npc->x,2);
		dLen+=2;
		memcpy(&udata[dLen],&npc->y,2);
		dLen+=2;
	}else if(npc->status==S_MOVE){
		udata[dLen] = npc->DirLoc;
		dLen+=1;
		udata[dLen] = npc->speed;
		dLen+=1;
		memcpy(&udata[dLen],&npc->x,2);
		dLen+=2;
		memcpy(&udata[dLen],&npc->y,2);
		dLen+=2;
		memcpy(&udata[dLen],&npc->dx,2);
		dLen+=2;
		memcpy(&udata[dLen],&npc->dy,2);
		dLen+=2;
	}else if(npc->status==S_FIGHT){
		memcpy(&udata[dLen],&npc->x,2);
		dLen+=2;
		memcpy(&udata[dLen],&npc->y,2);
		dLen+=2;
		memcpy(&udata[dLen],&npc->targetNO,2);
		dLen+=2;
	}
	memcpy(&udata[dLen],&nEnd,2);
	dLen+=2;
	memcpy(&udata[0],&dLen,2);

	x = npc->BSx - npc->ARx;
	y = npc->BSy - npc->ARy;
	if(x==0 && y<0){// 12�ù���	��

		for(i=3;i>0;i--){
			ax = npc->ARx -i+2;
			ay = npc->ARy +1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd(ax, ay, udata, dLen);
			else continue;
		}//end for loop
	}else if(x<0  && y<0){// 1 �ù���	��

		for(i=3;i>0;i--){
			ax = npc->ARx -i+2;
			ay = npc->ARy +1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd(ax, ay, udata, dLen);
			else continue;
		}//end for loop

		for(i=0;i<2;i++){
			ax = npc->ARx +1;
			ay = npc->ARy -i;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd(ax, ay, udata, dLen);
			else continue;
		}//end for loop

	}else if(x<0 && y==0){// 3 �ù���	��

		for(i=3;i>0;i--){
			ax = npc->ARx +1;
			ay = npc->ARy -i+2;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd(ax, ay,udata, dLen);
			else continue;
		}//end for loop
	}else if(x<0  && y>0){// 4 �ù���	��

		for(i=3;i>0;i--){
			ax = npc->ARx -i+2;
			ay = npc->ARy -1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd(ax, ay, udata, dLen);
			else continue;
		}//end for loop

		for(i=0;i<2;i++){
			ax = npc->ARx +1;
			ay = npc->ARy +i;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd(ax, ay,udata, dLen);
			else continue;
		}//end for loop

	}else if(x==0 && y>0){// 6 �ù���	��

		for(i=3;i>0;i--){
			ax = npc->ARx -i+2;
			ay = npc->ARy -1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd(ax, ay, udata, dLen);
			else continue;
		}//end for loop
	}else if(x>0  && y>0){// 7 �ù���	��

		for(i=3;i>0;i--){
			ax = npc->ARx -i+2;
			ay = npc->ARy -1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd(ax, ay, udata, dLen);
			else continue;
		}//end for loop

		for(i=0;i<2;i++){
			ax = npc->ARx -1;
			ay = npc->ARy +i;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd(ax, ay, udata, dLen);
			else continue;
		}//end for loop


	}else if(x>0  && y==0){// 9 �ù���	��

		for(i=3;i>0;i--){

			ax = npc->ARx -1;
			ay = npc->ARy -i+2;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd(ax, ay, udata, dLen);
			else continue;
		}//end for loop
	}else if(x>0  && y<0){// 10�ù���	��

		for(i=3;i>0;i--){
			ax = npc->ARx -i+2;
			ay = npc->ARy +1;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd(ax, ay, udata, dLen);
			else continue;
		}//end for loop

		for(i=0;i<2;i++){
			ax = npc->ARx -1;
			ay = npc->ARy -i;

			if(ax>=0 && ax<S_WIDTH && ay>=0 && ay<S_WIDTH)
				map_secdata_snd(ax, ay, udata, dLen);
			else continue;
		}//end for loop

	}
	npc->BSx = npc->ARx;
	npc->BSy = npc->ARy;
}








extern void npc_attack_chr(void * chrr, unsigned short idx){

	short	DaMaGe,DIRx,DIRy,HP;
	char mesg[64];
	unsigned short rLen = 2;
	unsigned short	nEnd = PEND;
	type_session * chr;

	if(idx>=_MAX_MONSTER_NO) return;
	if(chrr==NULL){
		npcArray[idx]->status=S_STAND;
		npcArray[idx]->dx = npcArray[idx]->Gx;
		npcArray[idx]->dy = npcArray[idx]->Gy;
		npcArray[idx]->targetChr=NULL;
		npcArray[idx]->tgFlag= 0;
		return;
	}

	if(npcArray[idx]->status==S_DIE) return;
	chr = (type_session *)chrr;
	if(chr->userStat == S_DIE){
		npcArray[idx]->status=S_STAND;
		npcArray[idx]->dx = npcArray[idx]->Gx;
		npcArray[idx]->dy = npcArray[idx]->Gy;
		npcArray[idx]->targetChr=NULL;
		npcArray[idx]->tgFlag= 0;
		return;
	}
	DIRx = npcArray[idx]->x - chr->Cx;
	DIRy = npcArray[idx]->y - chr->Cy;

	if(DIRx==0 && DIRy<0) npcArray[idx]->DirLoc= 4;			// 12�ù���
	else if(DIRx<0  && DIRy<0) npcArray[idx]->DirLoc= 3;	// 1 �ù���
	else if(DIRx<0 && DIRy==0) npcArray[idx]->DirLoc= 2;	// 3 �ù���
	else if(DIRx<0  && DIRy>0) npcArray[idx]->DirLoc= 1;	// 5 �ù���
	else if(DIRx==0 && DIRy>0) npcArray[idx]->DirLoc= 0;	// 6 �ù���
	else if(DIRx>0  && DIRy>0) npcArray[idx]->DirLoc= 7;	// 7 �ù���
	else if(DIRx>0  && DIRy==0) npcArray[idx]->DirLoc= 6;	// 9 �ù���
	else if(DIRx>0  && DIRy<0) npcArray[idx]->DirLoc= 5;	// 11�ù���
	pthread_mutex_unlock(&npclock);

	DaMaGe=npcArray[idx]->AP - chr->defence;
	if(DaMaGe<0) DaMaGe=0;
	HP = chr->hp_c - DaMaGe;
	if(HP<0) HP=0;

	mesg[rLen] = PK_OBJ_UPDATE_ACT;//2
	rLen+=1;
	mesg[rLen] = T_NPC;//obj_type:0 - user
	rLen+=1;
	mesg[rLen] = 1;//count
	rLen+=1;
	mesg[rLen] = npcArray[idx]->div;//count
	rLen+=1;
	memcpy(&mesg[rLen],&npcArray[idx]->npc_id,2);//8
	rLen+=2;
	mesg[rLen]=S_FIGHT;
	rLen+=1;
	mesg[rLen]=npcArray[idx]->DirLoc;
	rLen+=1;
	mesg[rLen]=T_USER;//target type
	rLen+=1;
	memcpy(&mesg[rLen],&chr->userNo,2);//target id no.
	rLen+=2;
	memcpy(&mesg[rLen],&HP,2);//target HP
	rLen+=2;
	memcpy(&mesg[rLen],&nEnd,2);
	rLen+=2;
	memcpy(&mesg[0],&rLen,2);
	map_usersend_All(chr->Ax, chr->Ay, mesg, rLen,NULL);//arg5�� NULL�� ����� ...�����ϱ�..

	pthread_mutex_lock(&synclock);//#########################################
	if(HP==0){//chr die
		chr->userStat = S_DIE;
		chr->hp_c	  = chr->hp_m/10;
		pthread_mutex_unlock(&synclock);
//		MonsterChrDie(idx,chr);//������ �˸�..
		pthread_mutex_lock(&npclock);

		npcArray[idx]->status=S_STAND;
		npcArray[idx]->targetChr=NULL;
		npcArray[idx]->tgFlag= 0;

		return;
	}else chr->hp_c=HP;
	pthread_mutex_unlock(&synclock);
	pthread_mutex_lock(&npclock);
	npcArray[idx]->tgFlag= 1;
}








extern void npc_chr_die(unsigned short npcId, void * chrr){//�ɸ����� ������ �˸���..�ӽ÷� �Ǿ�����...�ٽ� ������..

	type_session * chr;
	char packet1[36];
	unsigned short tlen = 2;
	unsigned short	nEnd = PEND;

	chr = (type_session *)chrr;
	packet1[tlen] = PK_OBJ_UPDATE_ACT;
	tlen+=1;
	packet1[tlen] = T_USER;
	tlen+=1;
	packet1[tlen] = 1;
	tlen+=1;
	memcpy(&packet1[tlen],&chr->userNo,2);
	tlen+=2;
	packet1[tlen] = S_DIE;
	tlen+=1;
	packet1[tlen] = chr->Dir;
	tlen+=1;
	memcpy(&packet1[tlen],&chr->Cx,2);
	tlen+=2;
	memcpy(&packet1[tlen],&chr->Cy,2);
	tlen+=2;
	memcpy(&packet1[tlen],&nEnd,2);
	tlen+=2;
	memcpy(&packet1[0],&tlen,2);
	map_usersend_All(chr->Ax, chr->Ay, packet1, tlen, chr);
}








extern void npc_mv_set(unsigned short idx){//�Ϲ��̵�..

//	short DIRx,DIRy;
	int res=0;

	if(npcArray[idx]->move_F_cnt>=NPC_MV_FRAME){//ù�����ӿ��� path find �� �����ϼ� �ִ����� �����ش�.�浹üũ..

		npcArray[idx]->move_F_cnt=0;

/*		DIRx = npcArray[idx]->x - npcArray[idx]->dx;
		DIRy = npcArray[idx]->y - npcArray[idx]->dy;

		if(DIRx==0 && DIRy<0) npcArray[idx]->DirLoc= 4;			// 6�ù���
		else if(DIRx<0  && DIRy<0) npcArray[idx]->DirLoc= 3;	// 7 �ù���
		else if(DIRx<0 && DIRy==0) npcArray[idx]->DirLoc= 2;	// 9 �ù���
		else if(DIRx<0  && DIRy>0) npcArray[idx]->DirLoc= 1;	// 10 �ù���
		else if(DIRx==0 && DIRy>0) npcArray[idx]->DirLoc= 0;	// 12 �ù���
		else if(DIRx>0  && DIRy>0) npcArray[idx]->DirLoc= 7;	// 1 �ù���
		else if(DIRx>0  && DIRy==0) npcArray[idx]->DirLoc= 6;	// 3 �ù���
		else if(DIRx>0  && DIRy<0) npcArray[idx]->DirLoc= 5;	// 4�ù���
*/
		res=npc_mv_one(npcArray[idx]);//ī��Ʈ�� �ٵǾ����� ��ĭ ����

		if(npcArray[idx]->mvstatus==0){//ó�� ���Ҷ�
			if(res==1){//
				if(npcArray[idx]->x == npcArray[idx]->dx
				&&npcArray[idx]->y == npcArray[idx]->dy){//������ ����
/*if(idx==1){
	printf("������ ����!!!! %d\n",idx);
}*/
					if(npcArray[idx]->tgFlag==0) npcArray[idx]->status= S_STAND;
					else npcArray[idx]->status= S_FIGHT;
					npcArray[idx]->mvstatus=0;//�̵�..
				}else npcArray[idx]->mvstatus=1;//�̵�..
			}
		}else{
			if(res==0){//���� �̵� ����
				npcArray[idx]->status=S_STAND;
				npcArray[idx]->mvstatus=0;//�̵�..
			}else{//�̵� ������..
				if(npcArray[idx]->x == npcArray[idx]->dx && npcArray[idx]->y == npcArray[idx]->dy){
/*if(idx==1){
	printf("������ ����!!!! %d\n",idx);
}*/
					if(npcArray[idx]->tgFlag==0) npcArray[idx]->status= S_STAND;
					else npcArray[idx]->status= S_FIGHT;
					npcArray[idx]->mvstatus=0;//�̵�..
				}
			}
		}

	}else npcArray[idx]->move_F_cnt++;
}








extern int npc_mv_one(type_npc * npc){//��ĭ�� �̵���Ŵ

	type_objlist * * pos;
	type_objlist * tmp;
	short tmpx,tmpy;
	unsigned short	nEnd = PEND;
	char mesg[64];
	short rLen=2;
	short DIRx,DIRy;

	if(npc->x==npc->dx&&npc->y==npc->dy){
//if(npc->npc_id==1) printf("��ǥ������ �����ؼ� �������\n");
		return 1;
	}

	DIRx = npc->x - npc->dx;
	DIRy = npc->y - npc->dy;
	tmpx = npc->x;
	tmpy = npc->y;

	if(DIRx==0 && DIRy<0){
		npc->DirLoc= 4;	// 12�ù���(���� �´°�)
		tmpy +=1;
	}else if(DIRx<0  && DIRy<0){
		npc->DirLoc= 3;	// 1 �ù���
	 	tmpx +=1;
		tmpy +=1;
	}else if(DIRx<0 && DIRy==0){
		npc->DirLoc= 2;	// 3 �ù���
	 	tmpx +=1;
	}else if(DIRx<0  && DIRy>0){
		npc->DirLoc= 1;	// 5 �ù���
	 	tmpx +=1;
		tmpy -=1;
	}else if(DIRx==0 && DIRy>0){
		npc->DirLoc= 0;	// 6 �ù���
		tmpy -=1;
	}else if(DIRx>0  && DIRy>0){
		npc->DirLoc= 7;	// 7 �ù���
	 	tmpx -=1 ;
		tmpy -=1;
	}else if(DIRx>0  && DIRy==0){
		npc->DirLoc= 6;	// 9 �ù���
	 	tmpx -=1;
	}else if(DIRx>0  && DIRy<0){
		npc->DirLoc= 5;	// 11�ù���
	 	tmpx -=1;
		tmpy +=1;
	}

	//�� �κп� ��ã�⸦ ������ �ִ�.
if(npc->npc_id==17) printf("%d npc %d,%d -> %d,%d�� ��ĭ�̵�\n",npc->npc_id,npc->x,npc->y,tmpx,tmpy);
	if(tmpx<0) tmpx=0;
	if(tmpy<0) tmpy=0;
	npc->x=tmpx;
	npc->y=tmpy;
	if(npc->x>=M_SIZE_X||npc->y>=M_SIZE_X){
		npc->status= S_STAND;
		npc->x=npc->Gx;
		npc->y=npc->Gy;
	}


	if(npc->mvstatus==0){//0�̸� ó�� �����̴� ���̹Ƿ� ��Ŷ �߼��ؾ���.

		mesg[rLen] = PK_OBJ_UPDATE_ACT;//2
		rLen+=1;
		mesg[rLen] = T_NPC;//obj_type:0 - user
		rLen+=1;
		mesg[rLen] = 1;//count
		rLen+=1;
		mesg[rLen] = npc->div;
		rLen+=1;
		memcpy(&mesg[rLen],&npc->npc_id,2);//8
		rLen+=2;
		mesg[rLen]=S_MOVE;
		rLen+=1;
		mesg[rLen]=npc->DirLoc;
		rLen+=1;
		mesg[rLen]=npc->speed;
		rLen+=1;
		memcpy(&mesg[rLen],&npc->x,2);
		rLen+=2;
		memcpy(&mesg[rLen],&npc->y,2);
		rLen+=2;
		memcpy(&mesg[rLen],&npc->dx,2);
		rLen+=2;
		memcpy(&mesg[rLen],&npc->dy,2);
		rLen+=2;
		memcpy(&mesg[rLen],&nEnd,2);
		rLen+=2;
		memcpy(&mesg[0],&rLen,2);
		map_usersend_All(npc->ARx, npc->ARy,mesg,rLen,NULL);//�������� ����..
		npc->mvstatus=1;
	}

	tmpx = npc->x/S_UNITSIZE;
	tmpy = npc->y/S_UNITSIZE;

	if(tmpx!=npc->ARx || tmpy!=npc->ARy){

		if (!npc){
			printf("npc pointer null \n");
			return 0;
		}

		if(mapNpcArray[npc->ARx][npc->ARy].objL==NULL){
			printf("mapArray NULL list in map_char_mv\n");
			return 0;
		}

		pos =  find_node_objlist(&(mapNpcArray[npc->ARx][npc->ARy].objL),npc);

		if(pos==NULL){
			printf("pos not found\n");
			return 0;
		}

		tmp = pop_data(pos);

		if (!tmp){
			printf("no pop \n");
			return 0;
		}
		insert_node_objlist(&(mapNpcArray[tmpx][tmpy].objL), tmp);

		npc->ARx = tmpx;
		npc->ARy = tmpy;

		npc_mv_addinfo(npc);//npc�� ���� �̵����� ���� ���ο� ���Ϳ� ������ �������ش�..
	}
	return 1;
}









extern void npc_regen(unsigned short idx){

	char retdata[32];
	unsigned short Len = 2;
	unsigned short	nEnd = PEND;
	type_objlist * * pos;
	type_objlist * tmp;
	unsigned short tmpx,tmpy,x=0,y=0;
	int i,j,res,random;

	random = (((unsigned int)rand())^((unsigned int)time(NULL)))%4;
	npcArray[idx]->x=npcArray[idx]->Gx+random;
	npcArray[idx]->y=npcArray[idx]->Gy+random;

	for(i=1,j=0;i<8;i++,j++){
		res=i%2;
		if(res==1){
			npcArray[idx]->x+=i;
			npcArray[idx]->y+=j;
		}else{
			npcArray[idx]->x-=i;
			npcArray[idx]->y-=j;
		}
		res=map_isgo(npcArray[idx]->x,npcArray[idx]->y);
		if(res==0){
			break;
			res=-1;
		}
	}
	if(res==-1){
		npcArray[idx]->x=npcArray[idx]->Gx;
		npcArray[idx]->y=npcArray[idx]->Gy;
	}

	tmpx = npcArray[idx]->x/S_UNITSIZE;//regen �� ������ ������ǥ�� �̸� ������...
	tmpy = npcArray[idx]->y/S_UNITSIZE;

	npcArray[idx]->status = S_STAND;
	npcArray[idx]->HP = npcArray[idx]->tHP;

	if(tmpx!=npcArray[idx]->ARx || tmpy!=npcArray[idx]->ARy){

		if (!npcArray[idx]) return;

		if(mapNpcArray[x][y].objL==NULL)	return;
		pos =  find_node_objlist(&(mapNpcArray[x][y].objL),npcArray[idx]);
		if(pos==NULL) return;
		tmp = pop_data(pos);

		if (!tmp) return;

		insert_node_objlist(&(mapNpcArray[tmpx][tmpy].objL), tmp);
		npcArray[idx]->ARx = tmpx;
		npcArray[idx]->ARy = tmpy;
	}
	npcArray[idx]->BSx = tmpx;
	npcArray[idx]->BSy = tmpy;

	retdata[Len] = PK_OBJ_ADD;				//2
	Len+=1;
	retdata[Len] = T_NPC;//obj_type : NPC	//3
	Len+=1;
	retdata[Len] = 1;				//4
	Len+=1;
	retdata[Len] = npcArray[idx]->div;//������ npc����
	Len+=1;
	retdata[Len] = npcArray[idx]->gtype;//����Ÿ��
	Len+=1;
	memcpy(&retdata[Len],&npcArray[idx]->npc_id,2);
	Len+=2;
	memcpy(&retdata[Len],&npcArray[idx]->level,2);
	Len+=2;
	memcpy(&retdata[Len],&npcArray[idx]->tHP,2);
	Len+=2;
	memcpy(&retdata[Len],&npcArray[idx]->HP,2);
	Len+=2;
	memcpy(&retdata[Len],&npcArray[idx]->AP,2);
	Len+=2;
	retdata[Len] = S_REGEN;
	Len+=1;
	retdata[Len] = npcArray[idx]->DirLoc;
	Len+=1;
	memcpy(&retdata[Len],&npcArray[idx]->x,2);
	Len+=2;
	memcpy(&retdata[Len],&npcArray[idx]->y,2);
	Len+=2;
	memcpy(&retdata[Len],&nEnd,2);
	Len+=2;
	memcpy(&retdata[0],&Len,2);
	map_usersend_All(npcArray[idx]->ARx, npcArray[idx]->ARy, retdata, Len, NULL);
}









extern type_npc * npc_ret_fight(unsigned short idx){//���� �ο�� �ִ� npcã��

	int i,j,x,y;
	type_objlist  const * const * tmp_objlist;
	void * ntmp_npc;	//
	type_npc * tmp_npc;
	short Len;

	for (i=3;i>0;i--) {
		x = npcArray[idx]->ARx -i+2;
		if(x<0 || x>S_WIDTH-1) continue;

		for(j=3;j>0;j--){
			y = npcArray[idx]->ARy -j+2;
			if(y<0||y>S_WIDTH-1) continue;

			for(tmp_npc=voidnpclist_get_first(&tmp_objlist,x,y); tmp_npc; tmp_npc=ntmp_npc)
			{
				tmp_npc = (type_npc *)tmp_npc;
				ntmp_npc = voidnpclist_get_next(&tmp_objlist);
				if(tmp_npc->status==S_DIE) continue;
				if(tmp_npc->tgFlag==1){
					Len = map_ret_dist(npcArray[idx]->x, npcArray[idx]->y, tmp_npc->x,tmp_npc->y);
					if(npcArray[idx]->Sight>=Len) return tmp_npc;
				}
			}
		}
	}
	return NULL;
}










extern int npc_ret_dist(unsigned short x, unsigned short y, unsigned short idx){//x,y ����ǥ, idx=����index

	int tmp,dx,dy;

	if(idx >=_MAX_MONSTER_NO) return -1;
	dx = npcArray[idx]->x - x;
	dy = npcArray[idx]->y - y;
	tmp = dx*dx + dy*dy;
	if(tmp==0) return 0;
	tmp = sqrt(tmp);
	return tmp;//��ǥ�� �ɸ��� ���� �Ÿ�..
}









extern short npc_chr_attack_npc(void * chr, unsigned short Index,void * conn){

	int	rLen=2;
	short	result=0,wasLVup=0;
	short DaMaGe;
	int exp=0,coin=0;
	type_session *c,*mc,*pc;
	char mesg[32];
	unsigned short	nEnd = PEND;
	int pt0,pt1,pt2;

	c = (type_session *)chr;
	if(Index>_MAX_MONSTER_NO) return 0;
	if(npcArray[Index]->div==1) return 0;
	if(npcArray[Index]->status==S_DIE) return 0;//�̹����� ����

	pthread_mutex_lock(&npclock);
	npcArray[Index]->targetNO = c->userNo;
	npcArray[Index]->targetChr = c;
	npcArray[Index]->mvstatus=0;
	npcArray[Index]->status = S_FIGHT;

	DaMaGe = c->attack-npcArray[Index]->DP;//������ �⺻���� �⺻ ��������
	if(DaMaGe<0) DaMaGe=1;

	npcArray[Index]->HP=npcArray[Index]->HP-DaMaGe;

	if(npcArray[Index]->HP<=0){
		result=1;//monster die
		npcArray[Index]->HP=0;
		npcArray[Index]->targetNO = 0;
		npcArray[Index]->targetChr = NULL;
		npcArray[Index]->status = S_DIE;
		pthread_mutex_unlock(&npclock);

		exp = npcArray[Index]->EXP;
		coin += npcArray[Index]->level*10;

	}else{
		pthread_mutex_unlock(&npclock);

		pthread_mutex_lock(&synclock);
		c->userStat = S_FIGHT;//�ӽð�
		c->tgtype = 1;//npc/usr
		c->target = npcArray[Index];
		c->target_id = Index;
		c->attack_F_cnt=0;
		pthread_mutex_unlock(&synclock);
	}
	mesg[rLen] = PK_OBJ_UPDATE_ACT;//2
	rLen+=1;
	mesg[rLen] = T_USER;//obj_type:0 - user
	rLen+=1;
	mesg[rLen] = 1;//count
	rLen+=1;
	memcpy(&mesg[rLen],&c->userNo,2);//8
	rLen+=2;
	mesg[rLen]=S_FIGHT;
	rLen+=1;
	mesg[rLen]=c->Dir;
	rLen+=1;
	mesg[rLen]=T_NPC;
	rLen+=1;
	memcpy(&mesg[rLen],&Index,2);//target id no.
	rLen+=2;
	memcpy(&mesg[rLen],&npcArray[Index]->HP,2);//target HP==0 �̸� ����
	rLen+=2;
	if(npcArray[Index]->HP==0){
		memcpy(&mesg[rLen],&c->exp,4);//target HP==0�̸� ����ġ ����
		rLen+=2;
	}
	memcpy(&mesg[rLen],&nEnd,2);
	rLen+=2;
	memcpy(&mesg[0],&rLen,2);
	map_usersend_All(c->Ax, c->Ay, mesg, rLen,NULL);

	if(result==1){//npc die item make
		//item drop
		 npc_drop_item(npcArray[Index], c->userNo);

		if(c->party.flag==1){//��Ƽ�� ����ġ ����..
			if(c->party.ison1==2){//�ڽ��� ��Ƽ���϶�
				coin = coin/c->party.cnt;
				exp = exp/c->party.cnt;
				mc=c;
			}else{
				mc=(type_session *)c->party.master;
				if(mc==NULL) return 0;
				coin = coin/mc->party.cnt;
				exp = exp/mc->party.cnt;
			}
			pthread_mutex_lock(&synclock);
			mc->coin+= coin;
			mc->exp +=exp;
			pt0=db_chk_lvup(mc,conn);

			if(mc->party.ison2==1){
				pc=(type_session *)mc->party.mem2;
				if(pc==NULL){
					pthread_mutex_unlock(&synclock);
					return 0;
				}
				pc->coin+= coin;
				pc->exp +=exp;
				pt1=db_chk_lvup(pc,conn);;
			}
			if(mc->party.ison3==1){
				pc=(type_session *)mc->party.mem3;
				if(pc==NULL){
					pthread_mutex_unlock(&synclock);
					return 0;
				}
				pc->coin+= coin;
				pc->exp +=exp;
				pt2=db_chk_lvup(pc,conn);//levelup check
			}
			pthread_mutex_unlock(&synclock);

			if(pt0==1){
				rLen=2;
				mesg[rLen] = PK_LEVELUP;//2
				rLen+=1;
				mesg[rLen] = mc->level;//4
				rLen+=1;
				memcpy(&mesg[rLen],&nEnd,2);
				rLen+=2;
				memcpy(&mesg[0],&rLen,2);
				map_pData_snd(mc,mesg,rLen);
			}
			if(pt1==1){
				pc=(type_session *)mc->party.mem2;
				if(pc==NULL) return 0;
				rLen=2;
				mesg[rLen] = PK_LEVELUP;//2
				rLen+=1;
				mesg[rLen] = pc->level;//4
				rLen+=1;
				memcpy(&mesg[rLen],&nEnd,2);
				rLen+=2;
				memcpy(&mesg[0],&rLen,2);
				map_pData_snd(pc,mesg,rLen);
			}
			if(pt2==1){
				pc=(type_session *)mc->party.mem3;
				if(pc==NULL) return 0;
				rLen=2;
				mesg[rLen] = PK_LEVELUP;//2
				rLen+=1;
				mesg[rLen] = pc->level;//4
				rLen+=1;
				memcpy(&mesg[rLen],&nEnd,2);
				rLen+=2;
				memcpy(&mesg[0],&rLen,2);
				map_pData_snd(pc,mesg,rLen);
			}

		}else{
			pthread_mutex_lock(&synclock);
			c->coin += coin;
			c->exp +=exp;
			wasLVup=db_chk_lvup(c,conn);//check lvup 0:not lvup 1:lvup
			pthread_mutex_unlock(&synclock);

			if(wasLVup==1){//status recal
				rLen=2;
				mesg[rLen] = PK_LEVELUP;//2
				rLen+=1;
				mesg[rLen] = c->level;//4
				rLen+=1;
				memcpy(&mesg[rLen],&nEnd,2);
				rLen+=2;
				memcpy(&mesg[0],&rLen,2);
				map_pData_snd(chr,mesg,rLen);
			}
		}
	}
	return 1;
}










extern short npc_drop_item(type_npc * npc, unsigned short userNo){

	type_itemLst_field * temp;
	unsigned int ItmNo;
	int tmp=0,cnt=0,loopCnt=0,i;
	short dLen=2;
	char data[128];
	unsigned short	nEnd = PEND;

	tmp = (((unsigned int)rand())^((unsigned int)time(NULL)))%100;//10%Ȯ���� ������2�� ȹ��
	if(tmp<10) loopCnt=2;
	else loopCnt=1;

	data[dLen] = PK_OBJ_ADD;
	dLen+=1;
	data[dLen] = T_ITEM;
	dLen+=1;
//	data[dLen]= 1;//cnt
	dLen+=1;

	for(i=0;i<12;i++){
		tmp = (((unsigned int)rand())^((unsigned int)time(NULL)))%100;
		if(npc->div==1){//npc
			if(def_npc[npc->npc_id].rate[i]>=tmp){
				if(def_npc[npc->npc_id].item[i]==0) continue;
				cnt+=1;
				if (!(temp = malloc(sizeof(type_itemLst_field)))) return 0;

				temp->rmFcnt	=0;
				temp->rmHcnt	=0;

				pthread_mutex_lock(&itemlock);
				temp->item_idx_cnt=item_ret_default_cnt(def_npc[npc->npc_id].item[i]);
				if(temp->item_idx_cnt==0){
					free(temp);
					pthread_mutex_unlock(&itemlock);
					continue;
				}
				ItmNo =  retNullitemIdx();//�ε��� ����
				setitemIdx(ItmNo);
				temp->idx		=ItmNo;
				item_add_sect(npc->ARx,npc->ARy,temp);
				temp->x=npc->x;
				temp->y=npc->y;
				temp->item_idx=def_npc[npc->npc_id].item[i];
				pthread_mutex_unlock(&itemlock);

				memcpy(&data[dLen],&temp->idx,2);
				dLen+=2;
				memcpy(&data[dLen],&temp->x,2);
				dLen+=2;
				memcpy(&data[dLen],&temp->y,2);
				dLen+=2;
				memcpy(&data[dLen],&temp->item_idx,2);
				dLen+=2;
				memcpy(&data[dLen],&temp->item_idx_cnt,2);
				dLen+=2;
			}
		}else{//monster
			if(def_mon[npc->npc_id].rate[i]>=tmp){
				if(def_mon[npc->npc_id].item[i]==0) continue;
				cnt+=1;

				if (!(temp = malloc(sizeof(type_itemLst_field)))) return 0;

				temp->rmFcnt	=0;
				temp->rmHcnt	=0;

				pthread_mutex_lock(&itemlock);
				temp->item_idx_cnt=item_ret_default_cnt(def_npc[npc->npc_id].item[i]);
				if(temp->item_idx_cnt==0){
					free(temp);
					pthread_mutex_unlock(&itemlock);
					continue;
				}
				ItmNo =  retNullitemIdx();//�ε��� ����
				setitemIdx(ItmNo);
				temp->idx		=ItmNo;
				item_add_sect(npc->ARx,npc->ARy,temp);
				temp->x=npc->x;
				temp->y=npc->y;
				temp->item_idx=def_mon[npc->npc_id].item[i];
				pthread_mutex_unlock(&itemlock);

				memcpy(&data[dLen],&temp->idx,2);
				dLen+=2;
				memcpy(&data[dLen],&temp->x,2);
				dLen+=2;
				memcpy(&data[dLen],&temp->y,2);
				dLen+=2;
				memcpy(&data[dLen],&temp->item_idx,2);
				dLen+=2;
				memcpy(&data[dLen],&temp->item_idx_cnt,2);
				dLen+=2;
			}
		}
		if(cnt==loopCnt) break;
	}
		data[4]= cnt;//cnt
		memcpy(&data[dLen],&nEnd,2);
		dLen+=2;
		memcpy(&data[0],&dLen,2);
		map_usersend_All(npc->ARx,npc->ARy,data,dLen,NULL);
	return 1;
}









extern void npc_skill_1(void * chr,unsigned short pwr, unsigned short xx, unsigned short yy,char * gDat,void * conn){//����

	int i,j,x,y,Ax,Ay;
	type_objlist  const * const * tmp_objlist;
	void * ntmp_npc;
	type_npc * tmp_npc;
	short Len=1,dist,cnt=0,range=4,wasLVup=0,rLen,exp=0,coin=0,result=0;
	char mesg[32];
	type_session *c,*pc,*mc;
	unsigned short	nEnd = PEND;
	int pt1=0,pt2=0,pt0=0;

	c=(type_session *)chr;

	Ax	=  xx/S_UNITSIZE;
	Ay	=  yy/S_UNITSIZE;
	if(Ax>=32||Ay>=32) return;

	pthread_mutex_lock(&npclock);
	for (i=3;i>0;i--) {
		x = Ax -i+2;
		if(x<0 || x>S_WIDTH-1) continue;

		for(j=3;j>0;j--){
			y = Ay -j+2;
			if(y<0||y>S_WIDTH-1) continue;

			for(tmp_npc=voidnpclist_get_first(&tmp_objlist,x,y); tmp_npc; tmp_npc=ntmp_npc)
			{
				tmp_npc = (type_npc *)tmp_npc;
				ntmp_npc = voidnpclist_get_next(&tmp_objlist);
				if(tmp_npc->div==1) continue;//npc continue;
				if(tmp_npc->status==S_DIE) continue;
				dist = npc_ret_dist(xx,yy,tmp_npc->npc_id);
				if(range>=dist&&dist!=-1){
					cnt+=1;
					gDat[Len]=2;
					Len+=1;
					memcpy(&gDat[Len],&tmp_npc->npc_id,2);
					Len+=2;
					tmp_npc->HP-=pwr;
					if(tmp_npc->HP<=0){
						result=1;//monster die
						tmp_npc->HP=0;
						tmp_npc->targetNO = 0;
						tmp_npc->targetChr = NULL;
						tmp_npc->status = S_DIE;
						coin += tmp_npc->level*10;
						exp += tmp_npc->EXP;

					}else{
						tmp_npc->targetNO = c->userNo;
						tmp_npc->targetChr = c;
						tmp_npc->mvstatus=0;
						tmp_npc->status = S_FIGHT;
					}
					memcpy(&gDat[Len],&tmp_npc->HP,2);
					Len+=2;
				}
			}
		}
	}
	pthread_mutex_unlock(&npclock);

	if(c->party.flag==1){//��Ƽ�� ����ġ ����..
		if(c->party.ison1==2){//�ڽ��� ��Ƽ���϶�
			coin = coin/c->party.cnt;
			exp = exp/c->party.cnt;
			mc=c;
		}else{
			mc=(type_session *)c->party.master;
			if(mc==NULL) return;
			coin = coin/mc->party.cnt;
			exp = exp/mc->party.cnt;
		}
		pthread_mutex_lock(&synclock);
		mc->coin+= coin;
		mc->exp +=exp;
		pt0=db_chk_lvup(mc,conn);

		if(mc->party.ison2==1){
			pc=(type_session *)mc->party.mem2;
			if(pc==NULL) return;
			pc->coin+= coin;
			pc->exp +=exp;
			pt1=db_chk_lvup(pc,conn);;
		}
		if(mc->party.ison3==1){
			pc=(type_session *)mc->party.mem3;
			if(pc==NULL) return;
			pc->coin+= coin;
			pc->exp +=exp;
			pt2=db_chk_lvup(pc,conn);//levelup check
		}
		pthread_mutex_unlock(&synclock);

		if(pt0==1){
			rLen=2;
			mesg[rLen] = PK_LEVELUP;//2
			rLen+=1;
			mesg[rLen] = mc->level;//4
			rLen+=1;
			memcpy(&mesg[rLen],&nEnd,2);
			rLen+=2;
			memcpy(&mesg[0],&rLen,2);
			map_pData_snd(mc,mesg,rLen);
		}
		if(pt1==1){
			pc=(type_session *)mc->party.mem2;
			if(pc==NULL) return;
			rLen=2;
			mesg[rLen] = PK_LEVELUP;//2
			rLen+=1;
			mesg[rLen] = pc->level;//4
			rLen+=1;
			memcpy(&mesg[rLen],&nEnd,2);
			rLen+=2;
			memcpy(&mesg[0],&rLen,2);
			map_pData_snd(pc,mesg,rLen);
		}
		if(pt2==1){
			pc=(type_session *)mc->party.mem3;
			if(pc==NULL) return;
			rLen=2;
			mesg[rLen] = PK_LEVELUP;//2
			rLen+=1;
			mesg[rLen] = pc->level;//4
			rLen+=1;
			memcpy(&mesg[rLen],&nEnd,2);
			rLen+=2;
			memcpy(&mesg[0],&rLen,2);
			map_pData_snd(pc,mesg,rLen);
		}

	}else{
		pthread_mutex_lock(&synclock);
		c->coin += coin;
		c->exp +=exp;
		wasLVup=db_chk_lvup(c,conn);//check lvup 0:not lvup 1:lvup
		pthread_mutex_unlock(&synclock);

		if(wasLVup==1){//status recal
			rLen=2;
			mesg[rLen] = PK_LEVELUP;//2
			rLen+=1;
			mesg[rLen] = c->level;//4
			rLen+=1;
			memcpy(&mesg[rLen],&nEnd,2);
			rLen+=2;
			memcpy(&mesg[0],&rLen,2);
			map_pData_snd(chr,mesg,rLen);
		}
	}
	gDat[0]=cnt;
}








