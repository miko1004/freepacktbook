#define SKILL_INCLUDED
#ifndef PUBLIC_INCLUDED
#include "publicInc.h"
#endif




extern void skill_use(void * chr,char * dat,void * conn);
extern void skill_defset(unsigned char type,unsigned char skillidx, char * lvpwr, char * lvupcost, unsigned int getcoin);
extern void skill_get(void * chr, char * dat);
extern void skill_lvup(void * chr, char * dat);
