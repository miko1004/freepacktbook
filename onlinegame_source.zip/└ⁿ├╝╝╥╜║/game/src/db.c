#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <strings.h>
#include <mysql.h>
#include "svr.h"
#include "db.h"
#include "item.h"
#define CIRQUE_SIZE 1024

static int exp_list[MAXUSERLEVEL+1];

struct svrLst
{
	unsigned char 			ip[4];//ip for tcp
	unsigned short 		tport;//port for tcp
	type_sockadr			udpSvr;//udp socket struct
	int						udpLen;//udp len
}worldinfo[MX_SVR_NO];

typedef struct cqueues{

	struct cqueues * 	next;
	unsigned int		index;
	char					query[1024];

}t_cir_queue;

static int cirQueLen=0,getPos=0,putPos=0,overPos=-1;
static t_cir_queue DBcircQue[CIRQUE_SIZE];
static MYSQL *connCHR,mysqlCHR;

extern int db_init(){

	int state;

	connCHR = mysql_connect(&mysqlCHR, _DBSERV, _DBID, _DBPASS);
	if( connCHR == NULL ) {
		printf("connCHR error in connection\n");
		return 0;
	}

	state = mysql_select_db(connCHR,_DBDB);
	if( state == -1 ) {
		printf("a %s\n",mysql_error(connCHR));
		mysql_close(connCHR);
		return 0;
	}

	return 1;
}



extern int db_user_auth(char * userid, char *passwd, int passlen, void * conn,type_session * c)
{
	int	state,len;
	MYSQL_RES *result;
	MYSQL_ROW row;
	char query[256];

	memset(query,0,256);
	sprintf(query,"select passwd from userinfo where userid='%s'",userid);

	state = mysql_query((MYSQL *)conn, query);
	if( state == -1 ) {
		printf("testXX%s\n",mysql_error((MYSQL *)conn));
		return 0;
	}
	result = mysql_store_result((MYSQL *)conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("mysql fail return value 0 \n");
		mysql_free_result(result);
		return 0;
	}
	row = mysql_fetch_row(result);
	mysql_free_result(result);
	len = strlen(row[0]);
	if(passlen==len){
		if(!strncmp(row[0],passwd,len)){

			memset(query,0,256);
			sprintf(query,"select * from characters where userid='%s'",userid);
			state = mysql_query((MYSQL *)conn, query);
			if( state == -1 ) {
				printf("testXX%s\n",mysql_error((MYSQL *)conn));
				return 0;
			}
printf("%s\n",query);
			result = mysql_store_result((MYSQL *)conn);
			state = mysql_num_rows(result);
			if( state == 0 ) {
				printf("mysql fail return value 0 \n");
				mysql_free_result(result);
				return 0;
			}
			row = mysql_fetch_row(result);
			c->nLen = strlen(row[1]);//char name length
			memcpy(&c->char_name[0],&row[1][0],c->nLen);	//NAME
			c->race			=	atoi(row[2]);	//RACE
			c->sex			=	atoi(row[3]);	//SEX
			c->nation		=	atoi(row[4]);	//NATION

			c->str			=	atoi(row[5]);	//STR
			c->dex			=	atoi(row[6]);	//DEX
			c->intel			=	atoi(row[7]);	//INT

			c->mana_c		=	atoi(row[8]);	//MANA
			c->hp_c			=	atoi(row[9]);	//HP
			c->exp			=	atoi(row[10]); //EXP
			c->level			=	atoi(row[11]);	//LV
			c->lvpoint		=	atoi(row[12]);	//PT
			c->skexp			=	atoi(row[13]);	//PT

			c->jobno			=	atoi(row[14]);	//JOB
			c->classno		=	atoi(row[15]);	//CLASS
			c->classlevel	=	atoi(row[16]);	//CLASSLV
			c->worldmap		=	atoi(row[17]);	//LOC_SVR
			c->Cx				=	atoi(row[18]);	//LOCX
			c->Cy				=	atoi(row[19]);	//LOCy
			c->Ax				=  c->Cx/S_UNITSIZE;
			c->Ay				=  c->Cy/S_UNITSIZE;
			c->Bx				=  c->Ax;
			c->By				=  c->Ay;

			c->eq[0]			=	atoi(row[20]);	//I_HEAD
			c->eq[1]			=	atoi(row[21]);	//I_L_HAND
			c->eq[2]			=	atoi(row[22]);	//I_R_HAND
			c->eq[3]			=	atoi(row[23]);	//I_BODY
			c->eq[4]			=	atoi(row[24]);	//I_LEG
			c->eq[5]			=	atoi(row[25]);	//I_NECKLACE
			c->eq[6]			=	atoi(row[26]);	//I_RING1
			c->coin			=	atoi(row[27]);	//COIN
			mysql_free_result(result);

			memset(query,0,256);
			sprintf(query,"select * from useritem where userid='%s'",userid);
			state = mysql_query((MYSQL *)conn, query);
			if( state == -1 ) {
				printf("testXX%s\n",mysql_error((MYSQL *)conn));
				return 0;
			}
			result = mysql_store_result((MYSQL *)conn);
			state = mysql_num_rows(result);
			if( state == 0 ) {
				printf("mysql fail return value 0 \n");
				mysql_free_result(result);
				return 0;
			}
			row = mysql_fetch_row(result);
			c->inven[0]					=	atoi(row[2]);
			c->inven_cnt[0]			=	atoi(row[3]);
			c->inven[1]					=	atoi(row[4]);
			c->inven_cnt[1]			=	atoi(row[5]);
			c->inven[2]					=	atoi(row[6]);
			c->inven_cnt[2]			=	atoi(row[7]);
			c->inven[3]					=	atoi(row[8]);
			c->inven_cnt[3]			=	atoi(row[9]);
			mysql_free_result(result);

			memset(query,0,256);
			sprintf(query,"select * from skill where userid='%s'",userid);
			state = mysql_query((MYSQL *)conn, query);
			if( state == -1 ) {
				printf("testXX%s\n",mysql_error((MYSQL *)conn));
				return 0;
			}
			result = mysql_store_result((MYSQL *)conn);
			state = mysql_num_rows(result);
			if( state == 0 ) {
				printf("mysql fail return value 0 \n");
				mysql_free_result(result);
				return 0;
			}
			row = mysql_fetch_row(result);
			c->skill[0]					=	atoi(row[2]);
			c->skill_lv[0]				=	atoi(row[3]);
			c->skill[1]					=	atoi(row[4]);
			c->skill_lv[1]				=	atoi(row[5]);
			c->skill[2]					=	atoi(row[6]);
			c->skill_lv[2]				=	atoi(row[7]);
			c->skill[3]					=	atoi(row[8]);
			c->skill_lv[3]				=	atoi(row[9]);
			mysql_free_result(result);

			memset(query,0,256);
			sprintf(query,"select * from warehouse where userid='%s'",userid);
			state = mysql_query((MYSQL *)conn, query);
			if( state == -1 ) {
				printf("testXX%s\n",mysql_error((MYSQL *)conn));
				return 0;
			}
			result = mysql_store_result((MYSQL *)conn);
			state = mysql_num_rows(result);
			if( state == 0 ) {
				printf("mysql fail return value 0 \n");
				mysql_free_result(result);
				return 0;
			}
			row = mysql_fetch_row(result);
			c->ware[0]					=	atoi(row[1]);
			c->ware_cnt[0]				=	atoi(row[2]);
			c->ware[1]					=	atoi(row[3]);
			c->ware_cnt[1]				=	atoi(row[4]);
			c->ware[2]					=	atoi(row[5]);
			c->ware_cnt[2]				=	atoi(row[6]);
			c->ware[3]					=	atoi(row[7]);
			c->ware_cnt[3]				=	atoi(row[8]);
			c->ware[4]					=	atoi(row[9]);
			c->ware_cnt[4]				=	atoi(row[10]);
			c->ware[5]					=	atoi(row[11]);
			c->ware_cnt[5]				=	atoi(row[12]);
			c->ware[6]					=	atoi(row[13]);
			c->ware_cnt[6]				=	atoi(row[14]);
			c->ware[7]					=	atoi(row[15]);
			c->ware_cnt[7]				=	atoi(row[16]);
			mysql_free_result(result);

			c->mana_F_cnt				=0;//���� ȸ���� ī����..
			c->recov_F_cnt				=0;//����� ȸ���� ī����..
			c->attack_F_cnt			=0;//����� ���ݵ����̿� ī����..
			c->regen_F_cnt				=0;//���� ī����
			c->dbSaveCnt				=0;//������ ���� ī����
			c->move_F_cnt				=0;

			c->party.flag				=0;//��Ƽ �÷��� �ʱ�ȭ
			c->party.waitfor			=NULL;//��ٸ��»�� �ʱ�ȭ
			c->party.cnt				=0;//��ٸ��»�� �ʱ�ȭ
			c->party.memidx			=0;	//�ڽ��� ��ġ..
			c->party.infoFcnt			=0;	//���� ������ �˸� ī��Ʈ..
			c->party.ison1				=0;	//0:NULL 	1:linked		2:myself(member#==NULL)
			c->party.ison2				=0;
			c->party.ison3				=0;

			c->trade.flag				=0;//�ŷ� �÷��� �ʱ�ȭ
			c->moveLevel				=2;
			c->pkmode					=0;//player kill mode default off:0 on:1
			//������� ��� ����..
			c->attack	= c->str+c->dex+c->intel+c->level+item_get_attack(c->eq[1])+item_get_attack(c->eq[2]);//���� �߰�
			c->hp_m 		= c->str+c->dex+50;
			c->mana_m	= c->intel+50;
			c->defence	=item_get_defence(c->eq[0])+item_get_defence(c->eq[1])+item_get_defence(c->eq[2])+item_get_defence(c->eq[3])+item_get_defence(c->eq[4])+item_get_defence(c->eq[5])+item_get_defence(c->eq[6]);
			c->dbLoaded =1;
			return 1;

		}else{
			return 0;
		}
	}else{
		return 0;
	}
}












extern void db_load_itemList(void * con)
{
	int	state,cnt=0;
	MYSQL	*	conn;
	MYSQL_RES *result;
	MYSQL_ROW row;
	char query[256];

	conn =(MYSQL *)con;
	item_init();
	memset(query,0,256);
	sprintf(query,"select * from ITEM");

	state = mysql_query(conn, query);
	if( state == -1 ) {
	//	printf("db_load_itemList:%s\n",mysql_error(conn));
		return ;
	}
	result = mysql_store_result(conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
	//	printf("db no item list found0 \n");
		mysql_free_result(result);
		return ;
	}

	while((row = mysql_fetch_row(result))!= NULL){
		cnt++;
		item_load(row);//row ������ ����Ʈ�� �߰�..
	}
printf("������ �� %d �� �ε��\n",cnt);
	mysql_free_result(result);

}











extern void db_load_expList(void * con)//Thread_recvpack in svr.c
{
	int	state,lv;
	MYSQL	*	conn;
	MYSQL_RES *result;
	MYSQL_ROW row;
	char query[256];

	conn =(MYSQL *)con;
	item_init();
	memset(query,0,256);
	sprintf(query,"select * from expp order by lv asc");

	state = mysql_query(conn, query);
	if( state == -1 ) {
		printf("db_load_expList:%s\n",mysql_error(conn));
		return ;
	}
	result = mysql_store_result(conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("db no exp list found0 \n");
		mysql_free_result(result);
		return ;
	}
	while((row = mysql_fetch_row(result))!= NULL){
		lv=atoi(row[0]);
		exp_list[lv]=atoi(row[1]);
		printf("����%d�� �� %d�� ����ġ�� �־�� %d�� ������ ��\n",lv,exp_list[lv],lv+1);
	}
	mysql_free_result(result);

}










extern void db_load_npcList(void * con)//
{
	int	state,i;
	MYSQL	*	conn;
	MYSQL_RES *result;
	MYSQL_ROW row;
	char query[256];
	char div,level,gtype,speed;
	char no;
	short item[12];
	char rate[12];

	conn =(MYSQL *)con;
	item_init();
	memset(query,0,256);
	sprintf(query,"select * from npc");

	state = mysql_query(conn, query);
	if( state == -1 ) {
		printf("db_load_npcList:%s\n",mysql_error(conn));
		return ;
	}
	result = mysql_store_result(conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("db no npc list found0 \n");
		mysql_free_result(result);
		return ;
	}
	while((row = mysql_fetch_row(result))!= NULL){
		div=atoi(row[0]);
		no=atoi(row[1]);
		gtype=atoi(row[2]);
		level=atoi(row[3]);
		speed=atoi(row[4]);
		for(i=0;i<12;i++){
			item[i]=atoi(row[5+i]);
			rate[i]=atoi(row[17+i]);
		}

		npc_set_def(div,no,gtype,level,speed,item,rate);
		if(div==0) printf("NPC load no:%d	gtype:%d	level:%d	speed:%d\n",no,gtype,level,speed);
		else printf("MONSTER load no:%d	gtype:%d	level:%d	speed:%d\n",no,gtype,level,speed);
	}
	mysql_free_result(result);
}










extern int db_chk_lvup(void * cc,void * con)
{
	type_session * c;
	MYSQL	*	conn;
//	char query[256];
//	int state;

	c=(type_session *)cc;
	conn =(MYSQL *)con;
	if(c->level>MAXUSERLEVEL||c->level==0) return 0;
	if(exp_list[c->level]<=c->exp){
		c->level+=1;
		c->lvpoint+=1;
/*		sprintf(query,"update characters set LV='%d',PT='%d' where userid='%s'",c->level,c->lvpoint,c->userid);

		state = mysql_query(conn, query);
		if( state == -1 ) {
			printf("update lv & lvpoint error:%s\n",mysql_error(conn));
			return 0;
		}
*/
		return 1;
	}else return 0;

}










extern void db_load_skillList(void * con)
{
	int	sktype,coin,skidx,state;
	MYSQL	*	conn;
	MYSQL_RES *result;
	MYSQL_ROW row;
	char query[256];

	conn =(MYSQL *)con;
	item_init();
	memset(query,0,256);
	sprintf(query,"select * from skilldef");

	state = mysql_query(conn, query);
	if( state == -1 ) {
		printf("db_load_expList:%s\n",mysql_error(conn));
		return ;
	}
	result = mysql_store_result(conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("skill def\n");
		mysql_free_result(result);
		return ;
	}
	while((row = mysql_fetch_row(result))!= NULL){
		sktype=atoi(row[0]);
		skidx=atoi(row[1]);
		coin=atoi(row[2]);
		skill_defset(sktype,skidx,row[3],row[4],coin);
	}
	mysql_free_result(result);

}










extern int db_load_svrlist(){

	MYSQL mysql;
	MYSQL_RES *result;
	char query[128];
	int state,idx;
	MYSQL * conn;
	MYSQL_ROW row;

	conn = mysql_connect(&mysql, _DBSERV, _DBID, _DBPASS);
	if( conn == NULL ) {
		printf("mysql error in connection\n");
		return 0;
	}

	state = mysql_select_db(conn,_DBDB);
	if( state == -1 ) {
		printf("a %s\n",mysql_error(conn));
		mysql_close(conn);
		return 0;
	}
/*
	conn = mysql_real_connect(&mysql,"localhost","mitierra","boaboa","boa",0,(char *)NULL,0);
	if( conn == NULL ) {
		printf("db_load_expList realconnect error\n");
	}
*/
	memset(query,0,128);
	sprintf(query,"select * from SVRLIST");
	state = mysql_query(conn, query);
	if( state == -1 ){
		return 0;
	}

	result = mysql_store_result(conn);
	state = mysql_num_rows(result);

	if( state == 0 ){
		mysql_free_result(result);
		return 0;
	}else{

		while((row = mysql_fetch_row(result))!= NULL){
			idx = atoi(row[0]);
			worldinfo[idx].ip[0] = atoi(row[1]);
			worldinfo[idx].ip[1] = atoi(row[2]);
			worldinfo[idx].ip[2] = atoi(row[3]);
			worldinfo[idx].ip[3] = atoi(row[4]);
			worldinfo[idx].tport = atoi(row[5]);

			bzero(&worldinfo[idx].udpSvr, sizeof(worldinfo[idx].udpSvr));
			worldinfo[idx].udpSvr.sin_family = AF_INET;
			worldinfo[idx].udpSvr.sin_port = htons(atoi(row[7]));//port
			inet_pton(AF_INET, row[6], &worldinfo[idx].udpSvr.sin_addr);
			worldinfo[idx].udpLen = sizeof(worldinfo[idx].udpSvr);
		}
	}

	mysql_free_result(result);
	return 1;
}









extern char * db_ret_tcpip(int idx){//memcpy(g_tmp, db_ret_tcplip(svr_idx), 4);

	if(idx >=MX_SVR_NO)
		return NULL;
	return worldinfo[idx].ip;
}









extern short db_ret_tcpport(int idx){
	if(idx >=MX_SVR_NO)
		return -1;
	return worldinfo[idx].tport;
}






extern type_sockadr * db_ret_udpsock(int idx){
	if(idx >=MX_SVR_NO)
		return NULL;
	return &worldinfo[idx].udpSvr;
}






extern int db_ret_udpLen(int idx){
	if(idx >=MX_SVR_NO)
		return -1;
	return worldinfo[idx].udpLen;
}







extern short db_save_all(void * chrr,void * conns)
{
	int	state;

	char query[1024];
	type_session * c;
	MYSQL *st_conn;

	st_conn = (MYSQL *)conns;
	c = (type_session *)chrr;
	if(!c) return 0;
	if(c->dbLoaded==0) return 0;
	memset(query,0,1024);
	sprintf(query,"update characters set MANA='%d',HP='%d',EXP='%d',SKEXP='%d',CLASSLV='%d',LOC_SVR='%d',LOCX='%d',LOCY='%d',I_HEAD='%d',I_L_HAND='%d',I_R_HAND='%d',I_BODY='%d',I_LEG='%d',I_NECKLACE='%d',I_RING='%d',COIN='%d' where userid='%s'",
						c->mana_c,c->hp_c,c->exp,c->skexp,c->classlevel,c->worldmap,c->Cx,c->Cy,c->eq[0],c->eq[1],c->eq[2],c->eq[3],c->eq[4],c->eq[5],c->eq[6],c->coin,c->userid);

#ifdef _DB_QUERY_ENQUEUE
 	state = db_enque_qry(query);
#else
 	state = mysql_query(st_conn, query);
#endif
	if( state == -1 ) {
		printf("db_char_SAVE ALL1%s\n",mysql_error(st_conn));
		return 0;
	}
	printf("save query:%s\n",query);

	memset(query,0,1024);
	sprintf(query,"update skill set IDX0='%d',LV0='%d',IDX1='%d',LV1='%d',IDX2='%d',LV2='%d',IDX3='%d',LV3='%d' where USERID='%s'",
		c->skill[0],c->skill_lv[0],c->skill[1],c->skill_lv[1],c->skill[2],c->skill_lv[2],c->skill[3],c->skill_lv[3],c->userid);

#ifdef _DB_QUERY_ENQUEUE
 	state = db_enque_qry(query);
#else
 	state = mysql_query(st_conn, query);
#endif

	if( state == -1 ) {
		printf("db_char_SAVE ALL2%s\n",mysql_error(st_conn));
		return 0;
	}
	printf("save query:%s\n",query);

	memset(query,0,1024);
	sprintf(query,"update useritem set IDX_0='%d',Q_0='%d',IDX_1='%d',Q_1='%d',IDX_2='%d',Q_2='%d',IDX_3='%d',Q_3='%d' where USERID='%s'",
		c->inven[0],c->inven_cnt[0],c->inven[1],c->inven_cnt[1],c->inven[2],c->inven_cnt[2],c->inven[3],c->inven_cnt[3],c->userid);
#ifdef _DB_QUERY_ENQUEUE
 	state = db_enque_qry(query);
#else
 	state = mysql_query(st_conn, query);
#endif

	if( state == -1 ) {
		printf("db_useritem %s\n",mysql_error(st_conn));
		return -1;
	}

	memset(query,0,1024);
	sprintf(query,"update warehouse set IDX_0=%d,Q_0=%d,IDX_1=%d,Q_1=%d,IDX_2=%d,Q_2=%d,IDX_3=%d,Q_3=%d,IDX_4=%d,Q_4=%d,IDX_5=%d,Q_5=%d,IDX_6=%d,Q_6=%d,IDX_7=%d,Q_7=%d where USERID ='%s'",
		c->ware[0],c->ware_cnt[0],c->ware[1],c->ware_cnt[1],c->ware[2],c->ware_cnt[2],c->ware[3],c->ware_cnt[3],c->ware[4],c->ware_cnt[4],c->ware[5],c->ware_cnt[5],c->ware[6],c->ware_cnt[6],c->ware[7],c->ware_cnt[7],c->userid);
#ifdef _DB_QUERY_ENQUEUE
 	state = db_enque_qry(query);
#else
 	state = mysql_query(st_conn, query);
#endif

	if( state == -1 ) {
		printf("db_TB_HOSE %s\n",mysql_error(st_conn));
		return -1;
	}

	printf("save query:%s\n",query);
	return 1;
}



/*
1. �� �̺�Ʈ�� ���� ������ ����
2. �ð� ī��Ʈ�� ���� ������ ����
3. ���� ������ ���� ó���ϱ�..(ȯ��ť���)
*/


//##�� �̺�Ʈ�� ���� ������ ����
/*
 1.	�ݱ�					- ok
 2.	������				- ok
 3.	���					- ok
 4.	�ȱ�					- ok
 5.	��ȯ					- ok
 6.	�����ϱ�				- ok
 7.	��ġ����				- ok
 8.	â�� ����			- ok
 9.	â�� ��ġ����		- ok
10.	����ġ ����,��		- ok
11.	��ų ����/����		- ok
12.	������				- ok
13
*/


extern short db_item_pick(void * chr, unsigned short invidx)
{//�ݱ�,������,��� ��� ����..
	int	state;
	char query[1024];
	type_session * c;

	c = (type_session *)chr;

	memset(query,0,1024);

	sprintf(query,"update useritem set IDX_%d=%d,Q_%d=%d where USERID='%s' and NAME='%s'",
			invidx,c->inven[invidx],invidx,c->inven_cnt[invidx],c->userid,c->char_name);

#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_pick ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}

	return 1;
}


extern short db_item_drop(void * chr, unsigned short invidx)
{//�ݱ�,������,��� ��� ����..
	int	state;
	char query[1024];
	type_session * c;

	c = (type_session *)chr;

	memset(query,0,1024);

	sprintf(query,"update useritem set IDX_%d=%d,Q_%d=%d where USERID='%s' and NAME='%s'",
			invidx,c->inven[invidx],invidx,c->inven_cnt[invidx],c->userid,c->char_name);

#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_drop ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}

	return 1;
}

extern short db_item_buy(void * chr, unsigned short invidx)
{//�ݱ�,������,��� ��� ����..
	int	state;
	char query[1024];
	type_session * c;

	c = (type_session *)chr;

	memset(query,0,1024);
	sprintf(query,"update useritem set IDX_%d=%d,Q_%d=%d where USERID='%s' and NAME='%s'",
				invidx,c->inven[invidx],invidx,c->inven_cnt[invidx],c->userid,c->char_name);
#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_pick 1ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}

	sprintf(query,"update characters set coin=%d where USERID='%s' and NAME='%s'",
				c->coin,c->userid,c->char_name);
#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_buy 2ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}

	return 1;
}

extern short db_item_sell(void * chrr, char * data)
{
	int	state;
	char query[1024];
	int tot,invenidx,i,j;
	type_session * c;

	c=(type_session *)chrr;

	memset(query,0,1024);
	tot = data[5];
	sprintf(query,"update useritem set");
	for(i=0,j=4;i<tot;i++){
		invenidx=data[j];
		j+=2;
		if(i==0){
			 sprintf(query,"%s IDX_%d=%d,Q_%d=%d",
					query,invenidx,c->inven[invenidx],invenidx,c->inven_cnt[invenidx]);
		}else{
			sprintf(query,"%s ,IDX_%d=%d,Q_%d=%d",
					query,invenidx,c->inven[invenidx],invenidx,c->inven_cnt[invenidx]);//�޸� �߰�
		}
		
	}

	sprintf(query,"%s where USERID='%s' and NAME='%s'",query,c->userid,c->char_name);
#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_sell 1ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}

	memset(query,0,1024);
	sprintf(query,"update characters set coin=%d where USERID='%s' and NAME='%s'",
						c->coin,c->userid,c->char_name);
#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_sell 2ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}

	return 1;
}


extern short db_item_trade(void * schr, void * tchr, char * sChange, char * tChange)
{
	int	state;
	char squery[1024],tquery[1024];
	int i,schk=0,tchk=0;
	type_session * c, * tc;

	c=(type_session *)schr;
	tc=(type_session *)tchr;

	memset(squery,0,1024);
	memset(tquery,0,1024);

	sprintf(squery,"update useritem set");
	sprintf(tquery,"update useritem set");

	for(i=0;i<4;i++){
		if(sChange[i]==1){
			if(schk==0){
				sprintf(squery,"%s IDX_%d=%d,Q_%d=%d",
							squery,i,c->inven[i],i,c->inven_cnt[i]);
			}else{
				sprintf(squery,"%s ,IDX_%d=%d,Q_%d=%d",
							squery,i,c->inven[i],i,c->inven_cnt[i]);//�޸� �߰�
			}
			schk=1;
		}
		if(tChange[i]==1){
			if(tchk==0){
				sprintf(tquery,"%s IDX_%d=%d,Q_%d=%d",
							tquery,i,tc->inven[i],i,tc->inven_cnt[i]);
			}else{
				sprintf(tquery,"%s IDX_%d=%d,Q_%d=%d",
							tquery,i,tc->inven[i],i,tc->inven_cnt[i]);//�޸� �߰�
			}
			tchk=1;
		}
	}

	sprintf(squery,"%s where USERID='%s' and NAME='%s'",squery,c->userid,c->char_name);
#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(squery);
#else
	state = mysql_query(connCHR, squery);
#endif

	if( state == -1 ) {
		printf("db_item_trade 1sERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	sprintf(tquery,"%s where USERID='%s' and NAME='%s'",tquery,c->userid,c->char_name);
#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(tquery);
#else
	state = mysql_query(connCHR, tquery);
#endif

	if( state == -1 ) {
		printf("db_item_trade 1tERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	memset(squery,0,1024);
	memset(tquery,0,1024);
	sprintf(squery,"update characters set coin=%d where USERID='%s' and NAME='%s'",
				c->coin,c->userid,c->char_name);
#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(squery);
#else
	state = mysql_query(connCHR, squery);
#endif

	if( state == -1 ) {
		printf("db_item_trade 2sERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	sprintf(tquery,"update characters set coin=%d where USERID='%s' and NAME='%s'",
				tc->coin,tc->userid,c->char_name);
#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(tquery);
#else
	state = mysql_query(connCHR, tquery);
#endif

	if( state == -1 ) {
		printf("db_item_trade 2tERROR: %s\n",mysql_error(connCHR));
		return 0;
	}

	return 1;
}



extern short db_item_wear(void * chr,unsigned char invidx,unsigned char eqidx)
{
	int	state;
	char query[1024];
	type_session * c;

	c=(type_session *)chr;

	memset(query,0,1024);
 	 sprintf(query,"update useritem set IDX_%d=%d,Q_%d=%d where USERID='%s' and NAME='%s'",
 				invidx,c->inven[invidx],invidx,c->inven_cnt[invidx],c->userid,c->char_name);

#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_sell 1ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}

	memset(query,0,1024);
	switch(eqidx){
		case 0:
			sprintf(query,"update characters set I_HEAD=%d where USERID='%s' and NAME='%s'",
						c->eq[eqidx],c->userid,c->char_name);
		break;
		case 1:
			sprintf(query,"update characters set I_L_HAND=%d where USERID='%s' and NAME='%s'",
						c->eq[eqidx],c->userid,c->char_name);
		break;
		case 2:
			sprintf(query,"update characters set I_R_HAND=%d where USERID='%s' and NAME='%s'",
						c->eq[eqidx],c->userid,c->char_name);
		break;
		case 3:
			sprintf(query,"update characters set I_BODY=%d where USERID='%s' and NAME='%s'",
						c->eq[eqidx],c->userid,c->char_name);
		break;
		case 4:
			sprintf(query,"update characters set I_LEG=%d where USERID='%s' and NAME='%s'",
						c->eq[eqidx],c->userid,c->char_name);
		break;
		case 5:
			sprintf(query,"update characters set I_NECKLACE=%d where USERID='%s' and NAME='%s'",
						c->eq[eqidx],c->userid,c->char_name);
		break;
		case 6:
			sprintf(query,"update characters set I_RING=%d where USERID='%s' and NAME='%s'",
						c->eq[eqidx],c->userid,c->char_name);
		break;
		default: return 0;
	}

#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_wear ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	return 1;
}



extern short db_item_pos(void * chr,unsigned char sidx,unsigned char didx)
{
	int	state;
	char query[1024];
	type_session * c;

	c=(type_session *)chr;

	memset(query,0,1024);
	sprintf(query,"update useritem set IDX_%d=%d,Q_%d=%d,IDX_%d=%d,Q_%d=%d where USERID='%s' and NAME='%s'",
				sidx,c->inven[sidx],sidx,c->inven_cnt[sidx],didx,c->inven[didx],didx,c->inven_cnt[didx],
				c->userid,c->char_name);

#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_pos ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	return 1;
}


extern short db_item_warepos(void * chr,unsigned char invidx,unsigned char wareidx)
{//â��
	int	state;
	char query[1024];
	type_session * c;

	c=(type_session *)chr;

	memset(query,0,1024);
	 sprintf(query,"update useritem set IDX_%d=%d,Q_%d=%d where USERID='%s' and NAME='%s'",
				invidx,c->inven[invidx],invidx,c->inven_cnt[invidx],c->userid,c->char_name);

#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_pos ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	memset(query,0,1024);
	 sprintf(query,"update warehouse set IDX_%d=%d,Q_%d=%d where USERID='%s'",
				wareidx,c->ware[wareidx],wareidx,c->ware_cnt[wareidx],c->userid);

#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_warepos ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	return 1;
}

extern short db_save_exp_money(void * chr)
{//â��
	int	state;
	char query[1024];
	type_session * c;

	c=(type_session *)chr;

	memset(query,0,1024);
	 sprintf(query,"update characters set EXP=%d,COIN=%d where USERID='%s' and NAME='%s'",
				c->exp,c->coin,c->userid,c->char_name);

#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_pos ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	return 1;
}


extern short db_set_skill(void * chr, unsigned char skidx)
{//â��
	int	state;
	char query[1024];
	type_session * c;

	c=(type_session *)chr;

	memset(query,0,1024);
	 sprintf(query,"update skill set IDX%d=%d,LV%d=%d where USERID='%s' and HERO_NAME='%s'",
				skidx,c->skill[skidx],skidx,c->skill_lv[skidx],c->userid,c->char_name);

#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_add_skill ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	return 1;
}


extern short db_levelup(void * chr)
{//â��
	int	state;
	char query[1024];
	type_session * c;

	c=(type_session *)chr;

	memset(query,0,1024);
	 sprintf(query,"update characters set LV=%d,PT=%d where USERID='%s' and HERO_NAME='%s'",
				c->level,c->lvpoint,c->userid,c->char_name);

#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif
	if( state == -1 ) {
		printf("db_add_skill ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	return 1;
}



void * Thread_db(void *arg)
{
	int que_len;
	int state,i;
	t_cir_queue * tg;
	MYSQL * conn;
	MYSQL mysql;

	for(i=0;i<CIRQUE_SIZE;i++){//circular queue init
		if(CIRQUE_SIZE==i+1){
			DBcircQue[i].next=&DBcircQue[0];
		}else DBcircQue[i].next=&DBcircQue[i+1];
		DBcircQue[i].index=i;
	}

	conn = mysql_connect(&mysql, _DBSERV, _DBID, _DBPASS);
	if( conn == NULL ) {
		printf("mysql error in connection\n");
		return 0;
	}

	state = mysql_select_db(conn,_DBDB);
	if( state == -1 ) {
		printf("a %s\n",mysql_error(conn));
		mysql_close(conn);
		return 0;
	}

	for(;;){
		pthread_mutex_lock(&dbQuelock);
		que_len = cirQueLen;
		while(que_len==0){
			pthread_cond_wait(&dbQuecond,&dbQuelock);
			que_len = cirQueLen;
		}
		cirQueLen=0;
		overPos=DBcircQue[getPos].index;//�����÷ο� üũ�� ���� �ε����� �������� ù��°�� �Է��Ұ�..
		pthread_mutex_unlock(&dbQuelock);

		i=0;
		tg=&DBcircQue[getPos];
		while(i<que_len){
			i+=1;
			state = mysql_query(conn,tg->query);
			if( state == -1 ) {
				printf("db_thread ERROR: %s\n",mysql_error(conn));
			}
			tg = tg->next;
			getPos = tg->index;
		}//end while
	}
}

extern int db_enque_qry(char * qry){

	int state;
	pthread_mutex_lock(&dbQuelock);

	if(overPos==DBcircQue[putPos].index){//queue full
		pthread_cond_signal(&dbQuecond);
		pthread_mutex_unlock(&dbQuelock);
		state = mysql_query(connCHR, qry);//�ٷ� ����
		return state;
	}
	memset(DBcircQue[putPos].query,0,1024);
	sprintf(DBcircQue[putPos].query,"%s",qry);

	cirQueLen+=1;//ť ��忡 ������ �߰�
	putPos=DBcircQue[putPos].next->index;//������ �Է��Ұ� ť�� �ε���

	pthread_cond_signal(&dbQuecond);
	pthread_mutex_unlock(&dbQuelock);
	return 1;
}
