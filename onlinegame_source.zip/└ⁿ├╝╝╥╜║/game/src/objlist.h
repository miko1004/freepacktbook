#define OBJLIST_INCLUDED



typedef struct objlist
{
    struct objlist  *	next;
    void			*	data;
} type_objlist;




extern int add_node_objlist(type_objlist * * objlist, void *	data);
extern type_objlist * * find_node_objlist(type_objlist * * objlist, void *	data);

extern int rm_objlist(type_objlist * * objlist);
extern void * get_node_objlist(type_objlist const * objlist);
extern type_objlist const * const * get_next_node_objlist_const(type_objlist const * objlist);

extern type_objlist * pop_data(type_objlist * * objlist);
extern int insert_node_objlist(type_objlist * * target_objlist, type_objlist  * source_objlist);
