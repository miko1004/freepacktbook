#include "packet.h"


typedef struct queues
{
	type_packet  * packet;
	struct queues * next;
}
type_queue;



extern type_packet * queue_pull_packet(type_queue * * queue);
extern void queue_push_packet(type_queue * * queue, type_packet * packet);
extern int 	queue_get_length(type_queue const * const * queue);
extern void queue_push_packet_raw(type_queue * * queue, type_packet * packet);
