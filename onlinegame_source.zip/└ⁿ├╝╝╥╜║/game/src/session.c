#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <pthread.h>
#include "session.h"
#include "thr_act.h"
#include "map.h"
#include "db.h"
#define SESSION_NEED_ONLY_MUTEX
#include "svr.h"

static type_key key_array[2048];
static t_sessionArray sess_array[MAXUSERNUM];
static int sockTosess[MAXUSERNUM];
static int ar_idx;
static int ar_idx2;
static int ar_cnt;
static int ar_cnt2;




extern void init_t_sessionArray(){
	int i;

	for(i=0;i<MAXUSERNUM;i++){
		sess_array[i].flag=0;
	}
}






extern void reset_sessionArray(int idx){

	if(idx>=MAXUSERNUM || idx<0)
		return;
	sess_array[idx].flag=0;
}





extern type_session * ret_session(int idx){
	if(idx>=MAXUSERNUM || idx<=0) return NULL;
	return &sess_array[sockTosess[idx]].s;
}






extern type_session * ret_session_first(unsigned int max){

	int i;

	if(max==0) return NULL;

	for(i=0;i<MAXUSERNUM;i++){
		if(sess_array[i].flag==1){
			ar_idx=i;
			ar_cnt=1;
			return &sess_array[i].s;
		}
	}
	return NULL;
}






extern type_session * ret_session_next(unsigned int max){
	int i;

	if(max<=ar_cnt) return NULL;
	for(i=ar_idx+1;i<MAXUSERNUM;i++){
		if(sess_array[i].flag==1){
			ar_idx=i;
			ar_cnt+=1;
			return &sess_array[i].s;
		}
	}
	return NULL;
}







extern type_session * ret_session_first2(unsigned int max){

	int i;

	if(max==0) return NULL;

	for(i=0;i<MAXUSERNUM;i++){
		if(sess_array[i].flag==1){
			ar_idx2=i;
			ar_cnt2=1;
			return &sess_array[i].s;
		}
	}
	return NULL;
}







extern type_session * ret_session_next2(unsigned int max){

	int i;

	if(max<=ar_cnt2) return NULL;
	for(i=ar_idx2+1;i<MAXUSERNUM;i++){
		if(sess_array[i].flag==1){
			ar_idx2=i;
			ar_cnt2+=1;
			return &sess_array[i].s;
		}
	}
	return NULL;
}








extern type_session * session_create(int sock, unsigned int addr, unsigned short port)
{
	int i;

	if (sock<0) return NULL;
	for(i=0;i<MAXUSERNUM;i++){
		if(sess_array[i].flag==0){
			sess_array[i].flag=1;
			break;
		}
	}
	sess_array[i].s.sock             	= sock;
   sess_array[i].s.port           	 	= port;
   sess_array[i].s.disco					= 0;
   sess_array[i].s.addr             	= addr;
	sess_array[i].s.state            	= conn_state_empty;
   sess_array[i].s.clientver        	= 0;
	sess_array[i].s.frameCnt				= 0;//������ ī����
	sess_array[i].s.userStat				= 0;//�������� 0: �κ� 1:���ӹ����� 2:������ 3:����
	sess_array[i].s.roomNo					= 0;//default:0
	sess_array[i].s.dbLoaded				= 0;
	sess_array[i].s.userNo					= i;
	sockTosess[sock]							= i;//���Ͼ�̱��
	sess_array[i].s.Ax						= 0;
	sess_array[i].s.Ay						= 0;
	sess_array[i].s.Bx						= 0;
	sess_array[i].s.Bx						= 0;

	return &sess_array[i].s;
}








extern void session_clear(type_session * c)
{
	if (!c)
		return;

	if(c->party.flag==1) thr_party_discon(c,1);//disconn
	reset_sessionArray(c->userNo);
	map_char_rm(c);

	shutdown(c->sock,2);//0:��������, 1:�۽�����, 2: �ۼ��� ��� ����
	close(c->sock);//�ڿ� ����
}








extern int session_set_userid(type_session * c, char * msg,int len)
{
	if(len>20) return 0;
	memcpy(&c->userid[0],&msg[0],len);
	c->userid[len] = '\0';
	c->uLen = len;
	return 1;
}








extern int session_set_charname(type_session * c, char * msg,int len)
{
	if(len>20) return 0;
	memcpy(&c->char_name[0],&msg[0],len);
	c->char_name[len] = '\0';
	c->nLen = len;
	return 1;
}








extern short session_attack_chr(type_session * c,unsigned short Index,void * conn){

	int	rLen=2;
	short	result=0,wasLVup=0;
	short DaMaGe;
	short exp=0;
	char mesg[32];
	unsigned short	nEnd = PEND;

	if(Index>MAXUSERNUM) return 0;
	if(sess_array[Index].flag==0) return 0;//��������
	if(sess_array[Index].s.userStat==S_DIE) return 0;//���� ����

	pthread_mutex_lock(&synclock);
	DaMaGe = c->attack-sess_array[Index].s.defence;//������ �⺻���� �⺻ ��������
	if(DaMaGe<0) DaMaGe=1;

	sess_array[Index].s.hp_c=sess_array[Index].s.hp_c-DaMaGe;

	if(sess_array[Index].s.hp_c<=0){
		result=1;
		sess_array[Index].s.hp_c=0;
		sess_array[Index].s.userStat = S_DIE;

		exp = sess_array[Index].s.level*5;
		c->userStat = S_STAND;
		c->attack_F_cnt=0;
		c->exp +=exp;
		wasLVup=db_chk_lvup(c,conn);//check lvup 0:not lvup 1:lvup
	}

	pthread_mutex_unlock(&synclock);

	mesg[rLen] = PK_OBJ_UPDATE_ACT;//2
	rLen+=1;
	mesg[rLen] = T_USER;//obj_type:0 - user
	rLen+=1;
	mesg[rLen] = 1;//count
	rLen+=1;
	memcpy(&mesg[rLen],&c->userNo,2);//8
	rLen+=2;
	mesg[rLen]=S_FIGHT;
	rLen+=1;
	mesg[rLen]=c->Dir;
	rLen+=1;
	mesg[rLen]=T_USER;
	rLen+=1;
	memcpy(&mesg[rLen],&Index,2);//target id no.
	rLen+=2;
	memcpy(&mesg[rLen],&sess_array[Index].s.hp_c,2);//target HP==0 �̸� ����
	rLen+=2;
	if(sess_array[Index].s.hp_c==0){
		memcpy(&mesg[rLen],&c->exp,4);//target HP==0�̸� ����ġ ����
		rLen+=2;
	}
	memcpy(&mesg[rLen],&nEnd,2);
	rLen+=2;
	memcpy(&mesg[0],&rLen,2);
	map_usersend_All(c->Ax, c->Ay, mesg, rLen,NULL);

/*	if(result==1){//npc die item make
		//item drop
		 npc_drop_item(npcArray[Index], c->userNo);
	}*/

	if(wasLVup==1){//status recal
		rLen=2;
		mesg[rLen] = PK_LEVELUP;//2
		rLen+=1;
		mesg[rLen] = c->level;//4
		rLen+=1;
		memcpy(&mesg[rLen],&nEnd,2);
		rLen+=2;
		memcpy(&mesg[0],&rLen,2);
		map_pData_snd(c,mesg,rLen);
	}
	return 1;
}









extern type_session * session_ret_session(unsigned short idx){

	if(idx>=MAXUSERNUM) return NULL;
	if(sess_array[idx].flag==0) return NULL;
	return &sess_array[idx].s;
}








extern void session_init_keyArray(){
	int i;

	for(i=0;i<2048;i++){
		key_array[i].flag=0;
	}
}









extern int session_keynode_create(char * data, unsigned short svridx)
{
	int		cLen,i,aidx=-1;
	int		dLen = 10;

	cLen = data[dLen];//uid len
	dLen += 1;
	if(cLen <= 0 || cLen > 31) {
		printf("INVALID USERID LENGTH\n");
		return 0;
	}

	for(i=0;i<2048;i++){
		if(key_array[i].flag==0){
			aidx=i;
			key_array[i].flag=1;
			break;
		}
	}
	if(aidx==-1) return 0;

	memcpy(&key_array[aidx].userid[0], &data[dLen], cLen);
	key_array[aidx].userid[cLen] = '\0';
	key_array[aidx].Len=cLen;
	key_array[aidx].rmCnt=0;
	memcpy(&key_array[aidx].key, &data[6], 4);
	key_array[aidx].svridx = svridx;
   return 1;
}








extern void session_key_clear(char * userid,int uLen)
{
	int i;
	for(i=0;i<2048;i++){
		if(key_array[i].flag==1){
			if(key_array[i].Len==uLen){
				if(!strncmp(userid, key_array[i].userid, uLen)){
					key_array[i].flag=0;
					return;
				}
			}
		}
	}
}








extern void session_key_admin()
{
	int i;
	for(i=0;i<2048;i++){
		if(key_array[i].flag==1){
			if(key_array[i].rmCnt>50)
				key_array[i].flag=0;
			else
				key_array[i].rmCnt++;
		}
	}
}









extern int session_key_cmp(char * userid,int uLen, unsigned int key)
{
	int i;
	for(i=0;i<2048;i++){
		if(key_array[i].flag==1){
			if(key_array[i].Len==uLen){
				if(!strncmp(userid, key_array[i].userid, uLen)){
					if(key_array[i].key==key){
						key_array[i].flag=0;
						return key_array[i].svridx;
					}
				}
			}
		}
	}
	return -1;
}

