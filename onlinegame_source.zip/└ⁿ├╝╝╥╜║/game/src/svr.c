//#define SVR_INTERNAL_ACCESS
#include <mysql.h>
#include <netinet/tcp.h>
#include <strings.h>
#include <fcntl.h>

#include "svr.h"
#include "thr_act.h"
#include "db.h"


type_queue  * send_que=NULL;
int sendQuedone 		= 0;
int tUsercnt			= 0;
int signal_sock_no	= 0;


pthread_mutex_t 		sendQuelock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t			sendQuecond	= PTHREAD_COND_INITIALIZER;
pthread_mutex_t 		synclock		= PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t			synccond		= PTHREAD_COND_INITIALIZER;
pthread_mutex_t 		itemlock		= PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t 		npclock		= PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t 		keyLock 		= PTHREAD_MUTEX_INITIALIZER;

pthread_mutex_t 		dbQuelock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t			dbQuecond	= PTHREAD_COND_INITIALIZER;


typedef struct sockPair{
	int tcpSock;
	int udpSock;
} type_sockpair;





static void svr_send_Ack_key(int sockno,char * dat,short Len, int toidx);





void peer_die(){
	signal_sock_no=-2;
	printf("NO DESCRIPTER TO WRITE ERROR\n");
	return;
}





extern int svr_ret_tot(){
	return tUsercnt;
}





static void setup_signals(void)
{
	struct sigaction    sa;

	sa.sa_handler = peer_die;
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = 0;
	if (sigaction(SIGPIPE, &sa, NULL) == -1) {
		perror("sigaction(SIGPIPE)");
		exit(1);
	}
	return;
}






int main(){

	int 				tcpsock,udpsock,tresult;
	struct 			sockaddr_in	laddr,udservaddr;
	struct 			linger ling = { 1, 0 };
	type_sockpair 	sockPair;
	pthread_t      thread_id[7];
	pthread_attr_t attr;

	type_sockadr		*	testSvr;

	if ((tcpsock = socket(PF_INET,SOCK_STREAM,0))<0)
	{
		printf("error in sock \n");
		return -1;
	}

	if ((udpsock = socket(PF_INET,SOCK_DGRAM,0))<0)
	{
		printf("error in udpsock \n");
		return -1;
	}

	{
	const int	val=1;
	if (setsockopt(tcpsock,SOL_SOCKET,SO_REUSEADDR,&val,sizeof(int))<0)
		printf("error in sockopt1 \n");

	if (setsockopt(tcpsock,SOL_SOCKET,SO_KEEPALIVE,&val,sizeof(int))<0)
		printf("error in sockopt3 \n");

	if (setsockopt(tcpsock, SOL_SOCKET, SO_LINGER, (char *) &ling, sizeof(struct linger)) < 0)
		printf("[initialize_communication()] can't setsockopt(SO_LINGER)\n");
	}

	memset(&laddr,0,sizeof(laddr));
	laddr.sin_family = AF_INET;
	laddr.sin_port = htons((unsigned short)_G_TCP_PORT);
	laddr.sin_addr.s_addr =	htonl(INADDR_ANY);

	bzero(&udservaddr, sizeof(udservaddr));
	udservaddr.sin_family      = AF_INET;
	udservaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	udservaddr.sin_port        = htons((unsigned short)_G_UDP_PORT);

	if (bind(udpsock,(struct sockaddr *)&udservaddr, sizeof(udservaddr))<0)
	{
		printf("error in bind udp\n");
		close(tcpsock);
		return -1;
	}

	if (bind(tcpsock,(struct sockaddr *)&laddr,sizeof(laddr))<0)
	{
		printf("error in bind \n");
		close(tcpsock);
		return -1;
	}
	if (fcntl(tcpsock, F_SETFL, O_NONBLOCK) == -1) {
		printf("error in fcntl \n");
		close(tcpsock);
		return -1;
	}

	if (listen(tcpsock,LISTEN_QUEUE)<0)
	{
		printf("error in listen \n");
		close(tcpsock);
		return -1;
	}
	sockPair.tcpSock = tcpsock;
	sockPair.udpSock = udpsock;

	pthread_attr_init(&attr);
	pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM);

	init_t_sessionArray();//���� �ε��� �ʱ�ȭ
	setup_signals();//set up signals

	db_load_svrlist();//load svr list

	/*for test*/
	testSvr=db_ret_udpsock(0);
	printf("db svr%d UDP port:%d\n",0,ntohs(testSvr->sin_port));
	testSvr=db_ret_udpsock(1);
	printf("db svr%d UDP port:%d\n",1,ntohs(testSvr->sin_port));
	testSvr=db_ret_udpsock(2);
	printf("db svr%d UDP port:%d\n",2,ntohs(testSvr->sin_port));
	testSvr=db_ret_udpsock(3);
	printf("db svr%d UDP port:%d\n",3,ntohs(testSvr->sin_port));

	tresult = pthread_create(&thread_id[0], &attr, Thread_sendpack, 	NULL);
	if(tresult!=0) printf("thread send creation failed %d \n",tresult);
	tresult = pthread_create(&thread_id[2], &attr, Thread_recvpack, 	&sockPair);
	if(tresult!=0) printf("thread rcv creation failed %d \n",tresult);
	tresult = pthread_create(&thread_id[3], &attr, Thread_udpserv, 	&udpsock);
	if(tresult!=0) printf("thread udp creation failed %d \n",tresult);
	tresult = pthread_create(&thread_id[4], &attr, Thread_item_sync, 	NULL);
	if(tresult!=0) printf("thread item creation failed %d \n",tresult);
	tresult = pthread_create(&thread_id[5], &attr, Thread_npc_sync, 	NULL);
	if(tresult!=0) printf("thread npc creation failed %d \n",tresult);
	tresult = pthread_create(&thread_id[1], &attr, Thread_sync, 		NULL);
	if(tresult!=0) printf("thread sync creation failed %d \n",tresult);
	tresult = pthread_create(&thread_id[6], &attr, Thread_db, 		NULL);
	if(tresult!=0) printf("thread db creation failed %d \n",tresult);
	for(;;)
		pause();

	close(tcpsock);
	return 0;
}






void * Thread_recvpack(void *arg){

	int tcpsock;
	unsigned char msg[MAX_PACKET_SIZE],msgto[32][MAX_PACKET_SIZE];
	int		highest_fd;
	int		csocket,pCnt,mx;
	int		n;
	short	rPsize[8];

	type_sockpair sockPair;
	unsigned short	rEnd;
	unsigned short	nEnd = PEND;
	fd_set	rfds, efds;
	int divIdx,sizee=0;

	int state;
	MYSQL * conn;
	MYSQL mysql;
	type_session *		   c;
	type_session *		   nc;

	sockPair =  *((type_sockpair *)arg);
	tcpsock = sockPair.tcpSock;
	mysql_init(&mysql);

	conn = mysql_connect(&mysql, _DBSERV, _DBID, _DBPASS);
	if( conn == NULL ) {
		printf("mysql error in connection\n");
		return 0;
	}

	state = mysql_select_db(conn,_DBDB);
	if( state == -1 ) {
		printf("a %s\n",mysql_error(conn));
		mysql_close(conn);
		return 0;
	}

/*	conn = mysql_real_connect(&mysql, _DBSERV, _DBID, _DBPASS,_DBDB,3306,NULL,0);
	if( conn == NULL ) {
		printf(mysql_error(&mysql));
		//return ;
	}
*/
	db_load_expList(conn);//from db.c

	for(;;)
	{
		FD_ZERO(&rfds);
		FD_ZERO(&efds);
		highest_fd = tcpsock;
		FD_SET(tcpsock,&rfds);
		for(nc=ret_session_first2(tUsercnt);nc;nc=ret_session_next2(tUsercnt)){

			csocket = nc->sock;
			FD_SET(csocket,&rfds);
			FD_SET(csocket,&efds);//extra receive

			if (csocket>highest_fd)
				highest_fd = csocket;
		}

		if (select(highest_fd+1,&rfds,NULL,&efds,(struct timeval *)0)<0)
		{
			if (errno!=EINTR)
			continue;
		}

		/* incoming	connection (if select return new conn)*/
		if (FD_ISSET(tcpsock,&rfds))
		{
			int				    	asock;
			struct sockaddr_in 	caddr;
			unsigned int			caddr_len;

			/* accept the connection */
			caddr_len =	sizeof(caddr);
			if ((asock = accept(tcpsock,(struct sockaddr *)&caddr,&caddr_len))<0)
			{
	            if (errno == EINTR)
	                continue;              /* retry accept : back to while() */
	            else
						printf("error with accept\n");
				continue;
			}else{

			}

			if (fcntl(asock,F_SETFL,O_NONBLOCK)<0)
			{
				printf("error with fcntl\n");
				shutdown(asock,2);
				close(asock);
				continue;
			}

			pthread_mutex_lock(&synclock);
			if (!(c	= session_create(asock,ntohl(caddr.sin_addr.s_addr),ntohs(caddr.sin_port))))
			{
				printf("error with session create\n");
				pthread_mutex_unlock(&synclock);//�߿�..
				shutdown(asock,2);
				close(asock);
				continue;
			}
			pthread_mutex_unlock(&synclock);
			tUsercnt++;
		}

		for(c=ret_session_first2(tUsercnt);c;c=ret_session_next2(tUsercnt))
		{
			if (c->state==conn_state_destroy)
			{
				tUsercnt--;
				printf("abrut disconnectss\n");
				db_save_all(c, conn);
				pthread_mutex_lock(&synclock);
				session_clear(c);
				pthread_mutex_unlock(&synclock);
				continue;
			}

			csocket = c->sock;
			if (FD_ISSET(csocket,&rfds))
			{										//�ܼ��� �о�� �����Ͱ� ���� ��쿡�� errno�� EAGAIN���� ���õ˴ϴ�.
				memset(msg,0,sizeof(msg));//���ϰ��� -1�϶� errno�� EAGAIN�̶�� continue
												  //�׷��� ���� ��� ���� ������ ����ų� ������ �߻�
				if((sizee = recv(csocket, msg, sizeof(msg), 0))<=0){//abrupt disconnect
					printf("abrut disconnect in receive\n");//0�ϰ�� Ŭ���̾�Ʈ�� ����ŷ
					tUsercnt--;
					db_save_all(c, conn);
					pthread_mutex_lock(&synclock);
					session_clear(c);
					pthread_mutex_unlock(&synclock);
					continue;
				}
				memcpy(&rPsize[0],&msg[0],2);
				pCnt=0;//packet count reset
				//check packet validity
				if(rPsize[0]==sizee){
					memcpy(&rEnd,&msg[rPsize[0] -2],2);
					if(rEnd != nEnd){
						printf("��Ŷ�� ���� �߸���..\n");
						continue;
					}
					pCnt+=1;
				}else if(rPsize[0]<sizee){
					divIdx=0;
					mx=0;
					for(;;){
						if(divIdx>=sizee) break;
						memset(msgto[pCnt],0,MAX_PACKET_SIZE);
						memcpy(&msgto[pCnt][0],&msg[divIdx],rPsize[pCnt]);
						memcpy(&rEnd,&msgto[pCnt][rPsize[pCnt] -2],2);
						if(rEnd != nEnd){
							printf("��Ŷ�� ���� �߸���..(�پ����Ŷ�� �ձ��̸�ŭ ©������ �߸���..)\n");
							break;
						}else{
							mx+=rPsize[pCnt];
							pCnt+=1;divIdx=mx;
							memcpy(&rPsize[pCnt],&msg[divIdx],2);
						}
					}
				}else continue;
				if(pCnt==1){
					if (c->state==conn_state_empty){
						state = thr_beforeAuth(msg,c,conn,sockPair.udpSock);
						if(state==0){
							printf("���� �ɸ��ε� ����\n");
							c->state = conn_state_destroy;
							continue;
						}
					}else if(c->state==conn_state_authed){
						state = main_act(msg,rPsize[0],c,conn,sockPair.udpSock);
						if(state==0){
							printf("���� ����ó�� ����\n");
							continue;
						}
					}else continue;
				}else{
					for(n=0;n<pCnt;n++){
						if (c->state==conn_state_empty){
							state = thr_beforeAuth(msgto[n],c,conn,sockPair.udpSock);
							if(state==0){
								printf("���� �ɸ��ε� ����\n");
								c->state = conn_state_destroy;
								continue;
							}
						}else if(c->state==conn_state_authed){
							state = main_act(msgto[n],rPsize[n],c,conn,sockPair.udpSock);
							if(state==0){
								printf("���� ����ó�� ����\n");
								continue;
							}
						}else continue;
					}
				}
			}//if (FD_ISSET(csocket,&rfds)) end �����ʱ�ȭ���� ��Ŷ����

			if (FD_ISSET(csocket,&efds))
			{
				printf("abrut disconnect in efds\n");
				tUsercnt--;
				sizee = db_save_all(c, conn);;
				if(sizee==1) printf("DISCONNECT DATA SAVE OKOKOKOKOKOK\n");
				else  printf("DISCONNECT DATA SAVE FALSEFALSEFALSEFALSE\n");
				pthread_mutex_lock(&synclock);
				session_clear(c);
				pthread_mutex_unlock(&synclock);
			}
		}//end for linked list search loop
	}//end enless loop
	mysql_close(conn);
}








void * Thread_sendpack(void *arg)
{
	int i,j,ERRkey;
	int rets,tmp_sock;
	type_packet *	 packet;
	type_session * c;
	type_session * ERRmap[16];
	type_session * tmp;
	int que_len;

	for(i=0;i<16;i++)
		ERRmap[i]=NULL;

	for(;;){
		ERRkey=0;
		pthread_mutex_lock(&sendQuelock);
		que_len = queue_get_length((type_queue const	* const	*)&send_que);
		while(que_len==0){
			pthread_cond_wait(&sendQuecond,&sendQuelock);
			que_len = queue_get_length((type_queue const	* const	*)&send_que);
		}
		packet = queue_pull_packet(&send_que);
		i=0;
		while(i<que_len){
			i+=1;

			c = (type_session *)packet->session;
			tmp_sock = c->sock;

			if(!packet->session){
				printf("������ ���̴�.........................\n");
				packet_destroy(packet);
				if(i<que_len) packet = queue_pull_packet(&send_que);

			}else if(tmp_sock==-2){
				packet_destroy(packet);
				if(i<que_len) packet = queue_pull_packet(&send_que);
			}else{
					if(packet->size<5){
						printf("Send error ��Ŷ���̰� 5���� �۴�...%d\n",packet->data[2]);
					}else{
						rets = send(packet->cli_sock, packet->data, packet->size,0);
						if(rets<=0){
							printf("send errorsss\n");
							ERRmap[ERRkey]=c;
							ERRkey+=1;
						}
					}
					packet_destroy(packet);
					if(i<que_len) packet = queue_pull_packet(&send_que);
			}
		}//end while
		pthread_mutex_unlock(&sendQuelock);

		if(ERRkey!=0){
			pthread_mutex_lock(&synclock);
			for(j=0;j<ERRkey;j++){
				ERRmap[j]->sock= signal_sock_no;
				ERRmap[j]->state = conn_state_destroy;
				tmp=ERRmap[j];
				ERRmap[j]=NULL;
			}
			pthread_mutex_unlock(&synclock);
		}
	}
}








void * Thread_udpserv(void *arg){

	int udpsock,n,fromIDX,res;
	fd_set	rfds;
	int highest_fd;
	socklen_t	len;
	int SVRchk;
	type_sockadr * fromaddr,cliaddr;

	char msg[1024];
	char temp;
	short pLen;
	unsigned short	rEnd;
	unsigned short	nEnd = PEND;

	int state;
	MYSQL * conn;
	MYSQL mysql;

	udpsock = *((int *)arg);
	session_init_keyArray();

	conn = mysql_connect(&mysql, _DBSERV, _DBID, _DBPASS);
	if( conn == NULL ) {
		printf("mysql error in connection\n");
		return 0;
	}

	state = mysql_select_db(conn,_DBDB);
	if( state == -1 ) {
		printf("a %s\n",mysql_error(conn));
		mysql_close(conn);
		return 0;
	}

	while(1) {
		SVRchk=0;
		FD_ZERO(&rfds);
		highest_fd = udpsock;
		FD_SET(udpsock,&rfds);
		len = sizeof(cliaddr);
		select(highest_fd+1,&rfds,NULL,NULL,0);

		if (FD_ISSET(udpsock,&rfds)){
			memset(msg,0,1024);
			n = recvfrom(udpsock, msg, 1024, 0,(struct sockaddr *)&cliaddr, &len);
			memcpy(&pLen,&msg[0],2);
			if(n!=pLen){
				printf("UDP invalid udp packet rev ��Ŷ ���� Ʋ��.\n");
				continue;
			}
			if(n<5) continue;
			memcpy(&rEnd,&msg[n-2],2);
			if(rEnd != nEnd){
				printf("UDP ��Ŷ�� ���� �߸���..\n");
				continue;//��Ŷ�� ���� Ʋ��..
			}
			fromIDX=msg[3];
			fromaddr=db_ret_udpsock(fromIDX);
			if(cliaddr.sin_addr.s_addr != fromaddr->sin_addr.s_addr){//������ üũ
				printf("invalid packet from !!\n");
				continue;
			}
			temp=msg[2];//get head
			switch(temp){
				case PKU_MAP_KEY://Ÿ ������ ���� ���� �̵��� ���� Ű ��Ŷ ����
					pthread_mutex_lock(&keyLock);
					res = session_keynode_create(msg,fromIDX);//add key to key list
					pthread_mutex_unlock(&keyLock);
					if(res==1) svr_send_Ack_key(udpsock,msg,pLen,fromIDX);
				break;

				case PKU_MAP_KEY_OK://PKU_MAP_KEY_OK �� ���� ���� ��Ŷ ����
					thr_map_move_key_ok(msg,conn);
				break;

				default:
					printf("invalid packet recv\n");
					continue;
			}
		}
		pthread_mutex_lock(&keyLock);
		session_key_admin();
		pthread_mutex_unlock(&keyLock);
	}
}






static void svr_send_Ack_key(int sockno,char * dat,short Len, int toidx){

	type_sockadr * udpsock;

	dat[2]=PKU_MAP_KEY_OK;
	dat[3]=_MAP_IDX;//������ �ε���
	udpsock = db_ret_udpsock(toidx);
	sendto(sockno,  dat,  Len,  0, (SA *)udpsock, db_ret_udpLen(toidx));
}




