#ifndef PUBLIC_INCLUDED
#include "publicInc.h"
#endif



#include <sys/socket.h>
typedef struct sockaddr_in	type_sockadr;



extern int db_user_auth(char * userid, char *passwd, int passlen, void * conn,type_session * c);
extern void db_load_expList(void * con);
extern void db_load_npcList(void * con);
extern int db_chk_lvup(void * ch,void * con);
extern void db_load_skillList(void * con);
extern int db_load_svrlist();
extern char * db_ret_tcpip(int idx);
extern short db_ret_tcpport(int idx);
extern type_sockadr * db_ret_udpsock(int idx);
extern int db_ret_udpLen(int idx);
extern short db_save_all(void * chrr,void * conns);
extern void db_load_itemList(void * conn);

extern int db_enque_qry(char * qry);

