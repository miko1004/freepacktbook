#ifndef PUBLIC_INCLUDED
#include "publicInc.h"
#endif



#ifndef OBJLIST_INCLUDED
#include "objlist.h"
#endif



#ifndef SESSION_INCLUDED
#include "session.h"
#endif



typedef struct mapsys
{
	type_objlist *	objL;
}
type_map;




extern void map_sec_test();
extern void map_Load();
extern unsigned short retNullUsernoIdx();
extern void mapinit(type_session * c);
extern void map_char_rm(type_session * c);
extern int map_char_one_mv(type_session * c,unsigned short x,unsigned short y);
extern void map_usersend_All(unsigned short mapSizeX, unsigned short mapSizeY,char * retdata,int len,type_session * c);//��ǥ �ݰ����� ������. chr �� ���� �ƴҰ�� �̳��� ���� ������.
extern void * voidlist_get_first(type_objlist const * const * * save,unsigned short i, unsigned short j);
extern void * voidlist_get_next(type_objlist const * const * * save);
extern void map_bk_sectorinfo(type_session * c);//character�� ���� �̵����� ���� ���ο� ���Ϳ� ������ �������ش�..
extern void map_get_sectorinfo(type_session * c);//���������� �޴´�.
extern void map_userDisconn(type_session * c);
extern void map_pData_snd(type_session * c, char *retdata,short dLen);
extern void map_secdata_snd_client(short ax, short ay,type_session * c);
extern void map_secdata_snd(short ax, short ay, char *retdata,short dLen);
extern void map_pData_snd(type_session * c, char *retdata,short dLen);
extern void map_get_sectorinfo_All(type_session * c);
extern short map_isgo(unsigned short x, unsigned short y);
extern void map_chrAction_calc(type_session * c);
extern short map_ret_dist(unsigned short x, unsigned short y, unsigned short xx, unsigned short yy);
extern short map_ret_chrdist(unsigned short x, unsigned short y,unsigned short idx);
extern void * map_ret_Activ_tg(unsigned short npcx, unsigned short npcy,unsigned short sight);
extern type_session * map_ret_chr(unsigned short Ax,unsigned short Ay,unsigned short tidx);
extern void map_party_sendAll(void * chrr,char * data,int len);
extern void map_party_sendAll_EXCEPT(void * chrr,char * data,int len);
