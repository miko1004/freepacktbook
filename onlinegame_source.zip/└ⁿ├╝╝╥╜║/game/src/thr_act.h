#ifndef PUBLIC_INCLUDED
#include "publicInc.h"
#endif



extern int main_act(char * dat,short pLen, type_session * c, void * conn,int udpsock);
extern int thr_beforeAuth(char * dat, type_session * c,void * conn,int udpsock);
extern int game_act(char * dat,short pLen, type_session * c, void * conn,int udpsock);



extern void thr_reset_gameroominfo(type_session * c,int idx);
extern void thr_party_discon(type_session * chr,char flag);
extern void thr_party_info(type_session * c);
extern void thr_map_move_key_ok(char * dat,void * conn);

