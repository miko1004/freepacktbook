#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char *argv[]) {

	FILE *fp,*fp2;
	char msg[4096];
	char tmpname[128];
	char *tmp=".c";
	int i=1;


	if(argc != 2) {
		printf("���� : %s filename\n", argv[0]);
		exit(0);
	}
	sprintf(tmpname, "%s%s",argv[1],tmp);

	if ((fp = fopen(argv[1], "r")) == NULL)
	{
		printf ("file Open error 1\n");
		exit(1);
	}
	fp2 = fopen (tmpname, "a+");
	if (fp2 == NULL){
		printf ("file Open error 2\n");
		exit(1);
	}
	memset(msg,0,4096);
	while((fgets(msg,4096,fp))){
		fprintf (fp2, "%d %s",i,msg);
		memset(msg,0,4096);
		i++;
	}
	fclose (fp);
	fclose (fp2);
}
