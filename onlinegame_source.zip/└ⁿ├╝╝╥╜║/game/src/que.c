#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "que.h"


extern type_packet * queue_pull_packet(type_queue * * queue)
{
	type_queue *  temp;
	type_packet * packet;

	if (!queue)
		return NULL;
	if (!*queue)
		return NULL;
	temp = *queue;
	*queue = (*queue)->next;
	packet = temp->packet;
	free(temp);

	if (!packet)
		return NULL;
	return packet;
}








extern void queue_push_packet(type_queue * * queue, type_packet * packet)
{
	type_queue * temp;
	short pLen;
	unsigned short	nEnd = PEND;

	if (!queue)
		return;
	if (!packet)
		return;

	pLen = packet->size + 4;
	if(pLen>MAX_PACKET_SIZE) return;
	memmove(&packet->data[2],&packet->data[0],pLen-4);
	memcpy(&packet->data[0],&pLen,2);
	memcpy(&packet->data[pLen-2],&nEnd,2);
	packet->size = pLen;

	temp = *queue;

	if (!temp)
	{
		if (!(temp = malloc(sizeof(type_queue))))
			return;
		temp->next = NULL;
		*queue = temp;
	}
	else
	{
		for (; temp->next; temp=temp->next);
		temp->next = malloc(sizeof(type_queue));
		temp->next->next = NULL;
		temp = temp->next;
	}

	temp->packet = packet;
}








extern void queue_push_packet_raw(type_queue * * queue, type_packet * packet)
{
	type_queue * temp;

	if (!queue)
		return;
	if (!packet)
		return;
	temp = *queue;

	if (!temp)
	{
		if (!(temp = malloc(sizeof(type_queue))))
			return;
		temp->next = NULL;
		*queue = temp;
	}
	else
	{
		for (; temp->next; temp=temp->next);
		temp->next = malloc(sizeof(type_queue));
		temp->next->next = NULL;
		temp = temp->next;
	}
	temp->packet = packet;
}









extern int queue_get_length(type_queue const * const * queue)
{
	type_queue const * temp;
	int             count;

	if (!queue)
		return 0;
	for (temp=*queue,count=0; temp; temp=temp->next,count++);
	return count;
}
