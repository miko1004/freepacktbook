#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/select.h>
#include <sys/poll.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/errno.h>
#include <pthread.h>


#ifndef _LINUXOS
	#include <sys/devpoll.h>
#endif


#ifndef PUBLIC_INCLUDED
	#include "publicInc.h"
#endif




#include <poll.h>
#define _REENTRANT



#ifdef SESSION_NEED_ONLY_MUTEX
	extern pthread_mutex_t 		sendQuelock;
	extern pthread_cond_t		sendQuecond;
	extern pthread_mutex_t 		synclock;
	extern pthread_cond_t		synccond;
	extern pthread_mutex_t 		AuthChkLock;
	extern pthread_mutex_t 		itemlock;
	extern pthread_mutex_t 		npclock;
	extern pthread_mutex_t 		keyLock;
	extern pthread_mutex_t 		dbQuelock;
	extern pthread_cond_t		dbQuecond;

#else
	extern pthread_mutex_t 		sendQuelock;
	extern pthread_cond_t		sendQuecond;
	extern pthread_mutex_t 		synclock;
	extern pthread_cond_t		synccond;
	extern pthread_mutex_t 		AuthChkLock;
	extern pthread_mutex_t 		itemlock;
	extern pthread_mutex_t 		npclock;
	extern pthread_mutex_t 		keyLock;
	extern pthread_mutex_t 		dbQuelock;
	extern pthread_cond_t		dbQuecond;



	#include "que.h"
	#ifndef NPC_INCLUDED
		#include "npc.h"
	#endif



	#ifndef SKILL_INCLUDED
		#include "skill.h"
	#endif



	#ifdef MAP_INTERNAL_ACCESS
		extern type_queue  * send_que;
	#else
		extern int sendQuedone;
		#include "session.h"
		extern int svr_ret_tot();
		void * Thread_sendpack(void *arg);
		void * Thread_recvpack(void *arg);
		void * Thread_udpserv(void *arg);
		void * Thread_sync(void *arg);
		void * Thread_item_sync(void *arg);
		void * Thread_npc_sync(void *arg);
		void * Thread_db(void *arg);
		void LogToFile (char *, char *);
		void ERROR_SO_DISCONNECT(int uSock);
	#endif



#endif
