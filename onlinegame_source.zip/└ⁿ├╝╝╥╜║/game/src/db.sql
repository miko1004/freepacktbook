create table USERINFO
(
    USERID      VARCHAR(20)            not null,	--�������̵�
    PASSWD      VARCHAR(20)            not null,	--�������̵�
    NAME        VARCHAR(20)            not null,	--���� �̸�
    EMAIL       VARCHAR2(100)          not null,	--�̸���
    primary key (USERID)
);


create table characters
(
    USERID      VARCHAR(20)            not null,
    NAME        VARCHAR(20)            not null,
    RACE        TINYINT                not null,	--����
    SEX         TINYINT                not null,	--����
    NATION      INT                    not null,	--����
    STR         INT                    not null,	--��
    DEX         INT                    not null,	--��ø
    INTEL       INT                    not null,	--����
    MANA        INT                    not null,	--����
    HP          INT                    not null,	--ü��
    EXP         INT                    not null,	--����ġ
    LV          INT                    not null,	--����
    PT          INT                    not null,	--����Ʈ
    SKEXP     	 INT                    not null,	--��ų����ġ
    JOB         TINYINT                not null,	--����
    CLASS       TINYINT                not null,	--Ŭ����
    CLASSLV     TINYINT                not null,	--Ŭ�������
    LOC_SVR     INT                    not null,	--���� ����
    LOCX        SMALLINT               not null,	--��ġ x
    LOCZ        SMALLINT               not null,	--��ġ z
    I_HEAD      INT                    not null,	--���
    I_L_HAND    INT                    not null,	--�޼�
    I_R_HAND    INT                    not null,	--������
    I_BODY      INT                    not null,	--����
    I_LEG       INT                    not null,	--����
    I_NECKLACE  INT                    not null,	--�����
    I_RING	    INT                    not null,	--����
    COIN        INT                    not null,	--��
    primary key (USERID, NAME)
);


create table useritem
(
    USERID     VARCHAR(20)            not null,
    NAME      VARCHAR(20)            not null,
    IDX_0       INT UNSIGNED           not null,	--�κ��丮 �ε��� 0
    Q_0         TINYINT                not null,	--����
    IDX_1       INT UNSIGNED           not null,	--�κ��丮 �ε��� 1
    Q_1         TINYINT                not null,
    IDX_2       INT UNSIGNED           not null,
    Q_2         TINYINT                not null,
    IDX_3       INT UNSIGNED           not null,
    Q_3         TINYINT                not null,
 primary key (USERID, NAME)
);


create table skill
(
    USERID      VARCHAR(20)            not null,
    HERO_NAME   VARCHAR(20)            not null,
    IDX0        TINYINT                not null,	--���� ��ų �ε���0
    LV0         TINYINT                not null,	--���� ��ų �ε���0 �� ����
    IDX1        TINYINT                not null,	--���� ��ų �ε���1
    LV1         TINYINT                not null,	--���� ��ų �ε���1 �� ����
    IDX2        TINYINT                not null,	--���� ��ų �ε���2
    LV2         TINYINT                not null,	--���� ��ų �ε���2 �� ����
    IDX3        TINYINT                not null,
    LV3         TINYINT                not null,
 primary key (USERID, HERO_NAME)
);


create table warehouse
(
    USERID      VARCHAR(20)            not null,
    IDX_0       INT UNSIGNED           not null,	--������ �ε���0
    Q_0         TINYINT                not null,	--������ �ε���0 �� ����
    IDX_1       INT UNSIGNED           not null,	--������ �ε���1
    Q_1         TINYINT                not null,	--������ �ε���1�� ����
    IDX_2       INT UNSIGNED           not null,
    Q_2         TINYINT                not null,
    IDX_3       INT UNSIGNED           not null,
    Q_3         TINYINT                not null,
    IDX_4       INT UNSIGNED           not null,
    Q_4         TINYINT                not null,
    IDX_5       INT UNSIGNED           not null,
    Q_5         TINYINT                not null,
    IDX_6       INT UNSIGNED           not null,
    Q_6         TINYINT                not null,
    IDX_7       INT UNSIGNED           not null,
    Q_7         TINYINT                not null,
 primary key (USERID)
);


create table npc
(
	DIV     TINYINT(1)     not null,
	NO      INT(2)         not null,
	GTYPE   TINYINT(1)     not null,
	LEVEL   TINYINT(1)     not null,
	SPEED   TINYINT(1)     not null,
	ITM0	  INT(4)         not null,
	ITM1	  INT(4)         not null,
	ITM2	  INT(4)         not null,
	ITM3	  INT(4)         not null,
	ITM4	  INT(4)         not null,
	ITM5	  INT(4)         not null,
	ITM6	  INT(4)         not null,
	ITM7	  INT(4)         not null,
	ITM8	  INT(4)         not null,
	ITM9	  INT(4)         not null,
	ITM10	  INT(4)         not null,
	ITM11	  INT(4)         not null,
	rate0   TINYINT(1)     not null,
	rate1   TINYINT(1)     not null,
	rate2   TINYINT(1)     not null,
	rate3   TINYINT(1)     not null,
	rate4   TINYINT(1)     not null,
	rate5   TINYINT(1)     not null,
	rate6   TINYINT(1)     not null,
	rate7   TINYINT(1)     not null,
	rate8   TINYINT(1)     not null,
	rate9   TINYINT(1)     not null,
	rate10  TINYINT(1)     not null,
	rate11  TINYINT(1)     not null,
	primary key (DIV, NO)
);


create table item
(
    IDXTYPE     SMALLINT(1)            not null,	--������ ����
    IDX         INT(4)                 not null,	--������ȣ 1���ͽ���
    EQUIP       SMALLINT(1)            not null,	--������ġ
    TYPE        SMALLINT(1)            not null,	--����Ÿ��
    REQ         INT(2)                 not null,	--�䱸����
    MAXATTACK   INT(2)                 not null,	--�ִ���ݷ�,���� ����
    RANGE       SMALLINT(1)            not null,	--���ݰŸ�
    CLASS       SMALLINT(1)            not null,	--���迭
    AMOUNT      INT(2)                 not null,	--����
    COST        INT(4)                 not null,	--����
    primary key (IDXTYPE, IDX)
);


create table expp
(
    lv		         INT(2)            not null,	--����
    expp   	      INT(4)               not null,	--����ġ
    primary key (LEVEL)
);

create table skilldef
(
    types				SMALLINT(1)			not null,
    idxs					SMALLINT(1)			not null,
    coin					INT(4)				not null,
    lvpwr				VARCHAR(100)		not null,
    lvcoin				VARCHAR(100)		not null,
    primary key (idxs)
);

create table SVRLIST(
	MAP_IDX 		INT(4) 		not null,
	SVR_TCP_IP1 SMALLINT(1) not null,
	SVR_TCP_IP2 SMALLINT(1)	not null,
	SVR_TCP_IP3 SMALLINT(1)	not null,
	SVR_TCP_IP4 SMALLINT(1)	not null,
	SVR_TCPPORT INT(4) 		not null,
	SVR_UDP_IP  VARCHAR(15) not null,
	SVR_UDPPORT INT(4) 		not null,
	primary key(MAP_IDX)
);


insert into SVRLIST values('0','192','168','1','210','9901','172.16.0.1','8801');
insert into SVRLIST values('1','192','168','1','210','9902','172.16.0.1','8802');
insert into SVRLIST values('2','192','168','1','210','9903','172.16.0.1','8803');
insert into SVRLIST values('3','192','168','1','210','9904','172.16.0.1','8804');


mysql> select * from expp;
+----+------+
| lv | expp |
+----+------+
|  1 |  100 |
|  2 |  150 |
|  3 |  200 |
|  4 |  250 |
|  5 |  300 |
|  6 |  350 |
|  7 |  400 |
|  8 |  450 |
|  9 |  500 |
| 10 |  550 |
+----+------+




insert into npc values('1','0','0','1','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','1','1','2','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','2','2','3','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','3','3','1','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','4','0','2','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','5','1','3','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','6','2','1','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','7','3','2','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','8','0','3','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','9','1','1','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','10','2','2','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','11','3','3','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','12','0','1','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','13','1','2','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','14','2','3','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','15','3','1','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','16','0','2','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','17','1','3','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','18','2','1','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','19','3','2','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');
insert into npc values('1','20','0','3','2','1','2','3','4','5','6','7','8','9','10','1','2','10','20','30','10','20','30','10','20','30','10','20','30');










IDXTYPE   | smallint(1) |      | PRI | 0       |       |
| IDX       | int(4)      |      | PRI | 0       |       |
| EQUIP     | smallint(1)//0:�Ӹ� 1:�Ѽ�(������) 2:��� 3:���� 4:�� 5:����� 6:����
| TYPE      | smallint(1) |      |     | 0       |       |
| REQ       | int(2)      |      |     | 0       |       |
| MAXATTACK | int(2)      |      |     | 0       |       |
| RANGE     | smallint(1) |      |     | 0       |       |
| CLASS     | smallint(1) |      |     | 0       |       |
| AMOUNT    | int(2)      |      |     | 0       |       |
| COST      | int(4)      |

insert into item values('0','1','0','0','1','10','2','0','1','100');
insert into item values('0','2','1','0','1','10','2','0','1','100');
insert into item values('0','3','2','0','1','10','2','0','1','100');
insert into item values('0','4','3','0','1','10','2','0','1','100');
insert into item values('0','5','4','0','1','10','2','0','1','100');
insert into item values('0','6','5','0','1','10','2','0','1','100');
insert into item values('0','7','6','0','1','10','2','0','1','100');
insert into item values('0','8','0','0','1','10','2','0','1','100');
insert into item values('0','9','1','0','1','10','2','0','1','100');
insert into item values('0','10','2','0','1','10','2','0','1','100');



