#define PUBLIC_INCLUDED
/*db setting*/
#define _DBSERV		"localhost"
#define _DBID			"mitierra"
#define _DBPASS		"boaboa"
#define _DBDB			"boa"

//#define _DB_QUERY_ENQUEUE	//0:immediate save 1:enqueue query

/*port*/
#define _G_TCP_PORT 9901
#define _G_UDP_PORT 8801




/*frame base*/
#define GAME_FRAME 	0x0F
#define HALF_SEC		0x07
#define D_HALF_SEC	0x03
#define REGEN		 	0x0F*30



/*server number settiong*/
#define MX_SVR_NO 	0x069



/*map size*/
#define M_SIZE_X  	512	//���� �ʺ�
#define S_WIDTH  		32		//���� ���� �ʺ�
#define S_UNITSIZE	16		//������ �ʺ�



/*max user*/
#define MAXUSERNUM 	0x1000
#define MAXUSERLEVEL 0x0A



/*max item No.*/
#define _MAX_ITEM_IDX 0x0FF6




/*map file*/
#define MAP_FILE "/export/home/mitierra/ga1/src/svrmap1.dat"



/*NPC setting*/
#define _MAX_MONSTER_NO 21
#define _NPC_TGT_SIG 	8			//��������
#define MAX_MON 			512		//�ִ�npc��
enum {T_ACTIVE, T_PASSIVE ,T_GROUP};		//battle type
#define NPC_MV_FRAME		0x0D



/*item setting*/
#define _MAX_DEFAULT_ITEM 100
#define _MAX_ITEM_DUP 10
#define _ITEM_DUP_NO_RANGE 50
enum {_HEAD,_L_HAND,_R_HAND,_BODY,_LEG,_NECKLACE,_RING1};//������ġ




/*packet header definition*/
enum {//TCP
		PK_USER_AUTH,
		PK_USER_CHAT=10, PK_INVEN_INFO,

		PK_REQ_LOC=20, PK_PT_REQ, PK_PT_PERMIT, PK_PT_LEAVE, PK_PT_BREAK, PK_PT_BAN,
		PK_PT_CHAT, PK_PT_INFO,

		PK_CMD_MV=30, PK_ATTACK, PK_LEVELUP, PK_SKILL_USE, PK_SKILL_GET, PK_SKILL_LVUP,
		PK_SKILL_INFO,

		PK_OBJ_ADD=40, PK_OBJ_UPDATE_ACT, PK_OBJ_UPDATE_EQUI,PK_OBJ_REMOVE,

		PK_ITEM_BUY=50, PK_ITEM_SELL, PK_ITEM_PICK, PK_ITEM_DROP, PK_ITEM_POS, PK_ITEM_WEAR,

		PK_TRADE_REQ=60, PK_TRADE_REQ_OK, PK_TRADE_LIST, PK_TRADE_OK,	PK_TRADE_CANCEL, PK_TRADE_SUCC,
		PK_WARE_INFO, PK_WARE_POS, PK_WARE_DEPOS,

		PK_MAP_MOVE_REQ=70, PK_MAP_MOVE_AUTH
};



enum {//UDP
		PKU_MAP_KEY=10, PKU_MAP_KEY_OK
};




/*return value settings*/
typedef enum {
	RET_TRUE, RET_FALSE, RET_REDUN, RET_NOID, RET_FULL, RET_NOTENO
}type_tf;




/*max packet size*/
#define MAX_PACKET_SIZE 0x400




/*obj type
0:USER	1:NPC/NONSTER	2:ITEM
*/
enum {T_USER,	T_NPC,	T_ITEM};



/*obj status
0:stand	1:move	2:fight	3:trade
*/
enum {S_STAND,	S_MOVE,	S_FIGHT,	S_TRADE, S_DIE, S_RET, S_REGEN, S_REMOVE};



/*map*/
#define _MAP_IDX 0

#define _MAP_GWAY_0_X 250
#define _MAP_GWAY_0_Y 5
#define _MAP_GWAY_0_TO_SVR 1

#define _MAP_GWAY_1_X 506
#define _MAP_GWAY_1_Y 256
#define _MAP_GWAY_1_TO_SVR 2

#define _MAP_GWAY_2_X 0
#define _MAP_GWAY_2_Y 0
#define _MAP_GWAY_2_TO_SVR 0

#define _MAP_GWAY_3_X 0
#define _MAP_GWAY_3_Y 0
#define _MAP_GWAY_3_TO_SVR _MAP_IDX//_MAP_GWAY_3_TO_SVR �� _MAP_IDX�� ������ ���� gateway

#define _MAP_GWAY_4_X 0
#define _MAP_GWAY_4_Y 0
#define _MAP_GWAY_4_TO_SVR _MAP_IDX

#define _MAP_GWAY_5_X 0
#define _MAP_GWAY_5_Y 0
#define _MAP_GWAY_5_TO_SVR _MAP_IDX

#define _MAP_GWAY_6_X 0
#define _MAP_GWAY_6_Y 0
#define _MAP_GWAY_6_TO_SVR _MAP_IDX

#define _MAP_GWAY_7_X 0
#define _MAP_GWAY_7_Y 0
#define _MAP_GWAY_7_TO_SVR _MAP_IDX





/************************************************************************************
*	- Warnning -																							*
*						Don't touch below!!																*
************************************************************************************/
/*standard output*/
#define STDINFD 0
#define STDOUTFD 1
#define STDERRFD 2

/*listen queue size*/
#define LISTEN_QUEUE 0x0A

/* frame setting*/
#define REGEN_TIME GAME_FRAME*2
#define AFRAME	900000/GAME_FRAME
#define _ONE_SEC	GAME_FRAME
#define _TWO_SEC	GAME_FRAME*2
#define _THREE_SEC	GAME_FRAME*3
#define _FOUR_SEC	GAME_FRAME*4
#define _FIVE_SEC	GAME_FRAME*5
#define _TWO_MIN	GAME_FRAME*120

/*packet end marker*/
#define PEND 0xC8D1

void LogToFile (char *, char *);
void LogFile (char *msg, FILE *fp);
#define	SA	struct sockaddr

