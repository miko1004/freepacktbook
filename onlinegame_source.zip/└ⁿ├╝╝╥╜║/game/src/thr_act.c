#include <time.h>
#include <mysql.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include "svr.h"
#ifndef OBJLIST_INCLUDED
#include "objlist.h"
#endif
#include "thr_act.h"
#include "map.h"
#include "db.h"
#include "item.h"

static short mvAction_set(type_session * c,short Dx, short Dy, short dirL);
static void thr_party_request(type_session * c, unsigned short tgidx);
static void thr_party_permit(type_session * c,unsigned short ptMain, short flag);
static void thr_party_set(type_session *c);
static void thr_party_bann(type_session * c,char * dat);
static void thr_party_chat(type_session * c,char * dat);
static void thr_map_move_req(type_session * c, char * dat, int udpsock);
static void thr_inveninfo(type_session * c);
static void thr_skillinfo(type_session * c);


void * Thread_sync(void *arg){//syncronizer thread for user's character

	struct timeval start,stop;
	long	tmp,utmp;
	short regenTime,Half_sec;
	int maxNo;
	type_session * c;

	sleep(3);
	regenTime = _ONE_SEC*30;
	Half_sec = _ONE_SEC/2;
	for(;;){
		gettimeofday(&start,NULL);
		pthread_mutex_lock(&synclock);
		maxNo = svr_ret_tot();
		for(c=ret_session_first(maxNo);c;c=ret_session_next(maxNo))
		{
			if(c->state==conn_state_empty||c->state==conn_state_destroy) continue;
			if(c->userStat == S_MOVE){//�����δ�.
				if(c->Cx == c->Dx&& c->Cy==c->Dy){//������ ����
					printf("��ǥ������ �����ؼ� ����\n");
					c->userStat = S_STAND;//������ ����
				}else{
					map_chrAction_calc(c);
				}
			}

			if(c->attack_F_cnt>-1){
				c->attack_F_cnt+=1;
				if(c->attack_F_cnt>Half_sec) c->attack_F_cnt=-1;
			}

			if(c->party.flag==1&&c->party.ison1==2){//master
				if(c->party.infoFcnt>_TWO_MIN){
					c->party.infoFcnt=0;
					thr_party_info(c);
				}else c->party.infoFcnt++;
			}
			c->dbSaveCnt++;
			/*
			if(c->dbSaveCnt>�ð���){
				db_save_data(c,conn);
				c->dbSaveCnt=0;
			}
			*/




			/*���� ���*/



		}
		pthread_cond_signal(&synccond);
		pthread_mutex_unlock(&synclock);

		gettimeofday(&stop,NULL);
		tmp = stop.tv_sec - start.tv_sec;
		utmp = stop.tv_usec - start.tv_usec;

		if(tmp>1){//1frame 0.033�� 33000/

		}else if(tmp==1){
			utmp = 1000000 + utmp;//�ɸ��ð�
			if(utmp<AFRAME){
				stop.tv_sec=0;
				stop.tv_usec=AFRAME-utmp;
				select(0, NULL, NULL, NULL, &stop);
			}
		}else{
			if(utmp<AFRAME){
				stop.tv_sec=0;
				stop.tv_usec=AFRAME-utmp;
				select(0, NULL, NULL, NULL, &stop);
			}
		}
	}//for loop end
}






extern int thr_beforeAuth(char * dat, type_session * c,void * conn,int udpsock){//dat�� ���̿� 			packet, c,

	char name[32],pass[32];
	char mesg[MAX_PACKET_SIZE];
	short res;
	unsigned short	nEnd = PEND;
	int pLen=2,clen,idx,ulen;
	unsigned int headercd,keycode;
	type_session * usr;
	type_npc * npc;

	memcpy(&res,&dat[0],2);//���� packet �� ����
	res-=2;
	headercd = dat[pLen];
	if(c->userStat==0){//�κ������ ��Ŷó��
		switch(headercd){

			case PK_USER_AUTH:
				idx=3;
				ulen=dat[idx];//name len
				idx+=1;
				if(res<ulen+idx||ulen>31) return 0;//error
				memcpy(&name[0],&dat[idx],ulen);
				name[ulen]='\0';
				idx+=ulen;
				clen=dat[idx];//pass len
				idx+=1;
				if(res<clen+idx||clen>31) return 0;//error
				memcpy(&pass[0],&dat[idx],clen);
				pass[clen]='\0';
				res = db_user_auth(name, pass,clen,conn,c);
				printf("�������� ��� :%d %s \n",res,name);

				if(res==1){
					pthread_mutex_lock(&synclock);
					session_set_userid(c,name,ulen);
					mapinit(c);
					c->state=conn_state_authed;
					pthread_mutex_unlock(&synclock);
					mesg[pLen]=PK_USER_AUTH;
					pLen+=1;
					mesg[pLen]=svr_ret_tot();
					pLen+=1;
					mesg[pLen]=c->uLen;
					pLen+=1;
					memcpy(&mesg[pLen],&c->userid[0],c->uLen);
					pLen+=c->uLen;
					memcpy(&mesg[pLen],&c->userNo,2);
					pLen+=2;
					memcpy(&mesg[pLen],&nEnd,2);
					pLen+=2;
					memcpy(&mesg[0],&pLen,2);
					map_pData_snd(c,mesg,pLen);

					//propa my info
					pLen=2;
					mesg[pLen]=PK_OBJ_ADD;
					pLen+=1;
					mesg[pLen]=0;//obj_type 0:user 1:npc 2:item
					pLen+=1;

					mesg[pLen]=1;//cnt
					pLen+=1;
					memcpy(&mesg[pLen],&c->userNo,2);//���⼭���� cnt��ŭ ����
					pLen+=2;
					mesg[pLen] = c->nLen;
					pLen+=1;
					memcpy(&mesg[pLen],&c->char_name[0],c->nLen);
					pLen+=c->nLen;
					mesg[pLen]=c->race;
					pLen+=1;
					mesg[pLen]=c->sex;
					pLen+=1;
					mesg[pLen]=c->nation;
					pLen+=1;

					memcpy(&mesg[pLen],&c->str,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->dex,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->intel,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->hp_c,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->mana_c,2);
					pLen+=2;

					memcpy(&mesg[pLen],&c->exp,4);
					pLen+=4;
					memcpy(&mesg[pLen],&c->level,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->lvpoint,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->skexp,4);
					pLen+=4;
					mesg[pLen]=c->jobno;
					pLen+=1;
					mesg[pLen]=c->classno;
					pLen+=1;
					mesg[pLen]=c->classlevel;
					pLen+=1;

					memcpy(&mesg[pLen],&c->eq[0],2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->eq[1],2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->eq[2],2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->eq[3],2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->eq[4],2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->coin,4);
					pLen+=4;

					mesg[pLen]=c->userStat;
					pLen+=1;
					if(c->userStat==S_STAND){//stand
						mesg[pLen]=c->Dir;
						pLen+=1;
						memcpy(&mesg[pLen],&c->Ax,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Ay,2);
						pLen+=2;
					}else if(c->userStat==S_MOVE){//move
						mesg[pLen]=c->Dir;
						pLen+=1;
						mesg[pLen]=c->moveLevel;
						pLen+=1;
						memcpy(&mesg[pLen],&c->Cx,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Cy,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Dx,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Dy,2);
						pLen+=2;
					}else if(c->userStat==S_FIGHT){//fight
						mesg[pLen]=c->Dir;
						pLen+=1;
						mesg[pLen]=c->tgtype;//Ÿ��Ÿ��
						pLen+=1;
						if(c->tgtype==0){//pk
							usr=(type_session *)c->target;
							memcpy(&mesg[pLen],&usr->userNo,2);
							pLen+=2;
						}else{//mon
							npc=(type_npc *)c->target;
							memcpy(&mesg[pLen],&npc->npc_id,2);
							pLen+=2;
						}
						memcpy(&mesg[pLen],&c->Ax,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Ay,2);
						pLen+=2;
					}else{//trade
						mesg[pLen]=c->Dir;
						pLen+=1;
						memcpy(&mesg[pLen],&c->Ax,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Ay,2);
						pLen+=2;
					}
					memcpy(&mesg[pLen],&nEnd,2);
					pLen+=2;
					memcpy(&mesg[0],&pLen,2);
					map_usersend_All(c->Ax,c->Ay,mesg,pLen,NULL);

					thr_inveninfo(c);//�÷��� �ϳ� ���� Ŭ���̾�Ʈ�� ��û�Ҷ� �����ְ� �Ҽ��� �ִ�...
					thr_skillinfo(c);

					map_get_sectorinfo_All(c);//����� ���� �޾ƿ���
					npc_3x3_secterinfo(c);//�ʵ��� npc,monster ���� �޾ƿ���
					item_3x3_secterinfo(c);//�ʵ��� item ���� �޾ƿ���
				}else{
					return 0;
				}
			break;
			case PK_MAP_MOVE_AUTH:
				idx=3;
				ulen=dat[idx];//name len
				idx+=1;
				if(res<ulen+idx||ulen>31) return 0;//error
				memcpy(&name[0],&dat[idx],ulen);
				name[ulen]='\0';
				idx+=ulen;
				memcpy(&keycode,&dat[idx],4);
				pthread_mutex_lock(&keyLock);
				res=session_key_cmp(name,ulen,keycode);
				pthread_mutex_unlock(&keyLock);
				if(res>=0){
					pthread_mutex_lock(&synclock);
					session_set_userid(c,name,ulen);
					mapinit(c);
					c->state=conn_state_authed;
					pthread_mutex_lock(&synclock);
					mesg[pLen]=PK_MAP_MOVE_AUTH;
					pLen+=1;
					mesg[pLen]=0;//res
					pLen+=1;
					memcpy(&mesg[pLen],&nEnd,2);
					pLen+=2;
					memcpy(&mesg[0],&pLen,2);
					map_pData_snd(c,mesg,pLen);

					//propa my info
					pLen=2;
					mesg[pLen]=PK_OBJ_ADD;
					pLen+=1;
					mesg[pLen]=0;//obj_type 0:user 1:npc 2:item
					pLen+=1;

					mesg[pLen]=1;//cnt
					pLen+=1;
					memcpy(&mesg[pLen],&c->userNo,2);//���⼭���� cnt��ŭ ����
					pLen+=2;
					mesg[pLen] = c->nLen;
					pLen+=1;
					memcpy(&mesg[pLen],&c->char_name[0],c->nLen);
					pLen+=c->nLen;
					mesg[pLen]=c->race;
					pLen+=1;
					mesg[pLen]=c->sex;
					pLen+=1;
					mesg[pLen]=c->nation;
					pLen+=1;

					memcpy(&mesg[pLen],&c->str,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->dex,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->intel,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->hp_c,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->mana_c,2);
					pLen+=2;

					memcpy(&mesg[pLen],&c->exp,4);
					pLen+=4;
					memcpy(&mesg[pLen],&c->level,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->lvpoint,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->skexp,4);
					pLen+=4;
					mesg[pLen]=c->jobno;
					pLen+=1;
					mesg[pLen]=c->classno;
					pLen+=1;
					mesg[pLen]=c->classlevel;
					pLen+=1;

					memcpy(&mesg[pLen],&c->eq[0],2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->eq[1],2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->eq[2],2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->eq[3],2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->eq[4],2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->coin,4);
					pLen+=4;

					mesg[pLen]=c->userStat;
					pLen+=1;
					if(c->userStat==S_STAND){//stand
						mesg[pLen]=c->Dir;
						pLen+=1;
						memcpy(&mesg[pLen],&c->Ax,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Ay,2);
						pLen+=2;
					}else if(c->userStat==S_MOVE){//move
						mesg[pLen]=c->Dir;
						pLen+=1;
						mesg[pLen]=c->moveLevel;
						pLen+=1;
						memcpy(&mesg[pLen],&c->Cx,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Cy,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Dx,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Dy,2);
						pLen+=2;
					}else if(c->userStat==S_FIGHT){//fight
						mesg[pLen]=c->Dir;
						pLen+=1;
						mesg[pLen]=c->tgtype;//Ÿ��Ÿ��
						pLen+=1;
						if(c->tgtype==0){//pk
							usr=(type_session *)c->target;
							memcpy(&mesg[pLen],&usr->userNo,2);
							pLen+=2;
						}else{//mon
							npc=(type_npc *)c->target;
							memcpy(&mesg[pLen],&npc->npc_id,2);
							pLen+=2;
						}
						memcpy(&mesg[pLen],&c->Ax,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Ay,2);
						pLen+=2;
					}else{//trade
						mesg[pLen]=c->Dir;
						pLen+=1;
						memcpy(&mesg[pLen],&c->Ax,2);
						pLen+=2;
						memcpy(&mesg[pLen],&c->Ay,2);
						pLen+=2;
					}
					memcpy(&mesg[pLen],&nEnd,2);
					pLen+=2;
					memcpy(&mesg[0],&pLen,2);
					map_usersend_All(c->Ax,c->Ay,mesg,pLen,NULL);

					thr_inveninfo(c);
					thr_skillinfo(c);

					map_get_sectorinfo_All(c);//����� ���� �޾ƿ���
					npc_3x3_secterinfo(c);//�ʵ��� npc,monster ���� �޾ƿ���
					item_3x3_secterinfo(c);//�ʵ��� item ���� �޾ƿ���
				}else{
					return 0;
				}
			break;
		}
	}
	return 1;
}







extern int main_act(char * dat,short pLen, type_session * c, void * conn,int udpsock){//dat�� ���̿� 			packet, c,

	int rLen=2,res,range;
	char mesg[MAX_PACKET_SIZE];
	unsigned short	nEnd = PEND;
	unsigned short headercd,Tx,Ty,idx;
	short cLen;
	unsigned char DIR;

	headercd=dat[2];
	switch(headercd){
		case PK_USER_CHAT:
			memcpy(&cLen,&dat[3],2);
			if(cLen>pLen-4) return 0;

			mesg[rLen]=PK_USER_CHAT;
			rLen+=1;
			mesg[rLen]=c->uLen;
			rLen+=1;
			memcpy(&mesg[rLen],&c->userid[0],c->uLen);
			rLen+=c->uLen;
			memcpy(&mesg[rLen],&cLen,2);
			rLen+=2;
			memcpy(&mesg[rLen],&dat[5],cLen);
			rLen+=cLen;
			memcpy(&mesg[rLen],&nEnd,2);
			rLen+=2;
			memcpy(&mesg[0],&rLen,2);
			map_usersend_All(c->Ax,c->Ay,mesg,rLen,NULL);
			printf("PK_USER_CHAT:ok\n");
		break;
		case PK_REQ_LOC:
			mesg[rLen]=PK_REQ_LOC;
			rLen+=1;
			mesg[rLen]=c->Ax;
			rLen+=1;
			mesg[rLen]=c->Ay;
			rLen+=1;
			memcpy(&mesg[rLen],&nEnd,2);
			rLen+=2;
			memcpy(&mesg[0],&rLen,2);
			map_pData_snd(c,mesg,rLen);
			printf("PK_REQ_LOC:ok\n");
		break;
		case PK_CMD_MV:
			memcpy(&Tx,&dat[3],2);
			memcpy(&Ty,&dat[5],2);
			DIR=dat[7];
			if(Tx>=M_SIZE_X||Ty>=M_SIZE_X||DIR>=8){
				res=0;
			}else{
				if(c->Cx==Tx&&c->Cy==Ty) res=0;
				else{
					pthread_mutex_lock(&synclock);
					res=mvAction_set(c,Tx,Ty,DIR);
					pthread_mutex_unlock(&synclock);
				}
			}
			printf("before:%d,%d after:%d,%d res:%d stat:%d\n",c->Cx,c->Cy,Tx,Ty,res,c->userStat);

			mesg[rLen] = PK_OBJ_UPDATE_ACT;//2
			rLen+=1;
			mesg[rLen] = T_USER;//obj_type:0 - user
			rLen+=1;
			mesg[rLen] = 1;//count
			rLen+=1;
			memcpy(&mesg[rLen],&c->userNo,2);//8
			rLen+=2;
			mesg[rLen]=S_MOVE;
			rLen+=1;
			mesg[rLen]=c->Dir;
			rLen+=1;
			mesg[rLen]=c->moveLevel;
			rLen+=1;
			memcpy(&mesg[rLen],&c->Cx,2);
			rLen+=2;
			memcpy(&mesg[rLen],&c->Cy,2);
			rLen+=2;
			memcpy(&mesg[rLen],&c->Dx,2);
			rLen+=2;
			memcpy(&mesg[rLen],&c->Dy,2);
			rLen+=2;

			memcpy(&mesg[rLen],&nEnd,2);
			rLen+=2;
			memcpy(&mesg[0],&rLen,2);

			if(res==1){
				map_usersend_All(c->Ax,c->Ay,mesg,rLen,NULL);
			}
		break;
		case PK_ATTACK:
			if(c->userStat==S_DIE) return 0;

			if(c->eq[2]==0) range =1;//������� �����ո� üũ. �޼��� ������ ���ݰŸ� 1
			else range= item_get_range(c->eq[2]);//���� ����

			if(dat[3]==0){//user
				memcpy(&idx,&dat[4],2);
				res = map_ret_chrdist(c->Cx, c->Cy, idx);
				if(range<res||res==-1) return res;
			}else{
				memcpy(&idx,&dat[4],2);
				if(idx>=_MAX_MONSTER_NO) return 0;
				res = npc_ret_dist(c->Cx, c->Cy, idx);
			}

			if(range>=res&&c->attack_F_cnt==-1){//���ݰ���
				if(dat[3]==0){//user
					res=session_attack_chr(c,idx,conn);
				}else{
					res=npc_chr_attack_npc(c,idx,conn);
				}
				return res;
			}else return 0;
		break;
		case PK_ITEM_BUY:
			if(pLen!=8) return 0;
			item_buy(dat,c);
			return 1;
		break;
		case PK_ITEM_SELL:
			res=6+dat[3]*2;
			if(pLen!=res||dat[3]==0) return 0;
			item_sell(dat,c);
			return 1;
		break;
		case PK_ITEM_PICK:
			if(pLen!=7) return 0;
			item_pick(dat,c);
			return 1;
		break;
		case PK_ITEM_DROP:
			if(pLen!=7) return 0;
			item_drop(c,dat);
			return 1;
		break;
		case PK_ITEM_POS:
			if(pLen!=9) return 0;
			item_pos(c,dat);
			return 1;
		break;
		case PK_ITEM_WEAR:
			if(pLen!=7) return 0;
			item_wear(c,dat);
			return 1;
		break;
		case PK_TRADE_REQ:
			if(pLen!=8) return 0;
			item_trade_req(c,dat);
			return 1;
		break;
		case PK_TRADE_REQ_OK:
			if(pLen!=8) return 0;
			item_trade_req(c,dat);
			return 1;
		break;
		case PK_TRADE_LIST:
			item_trade_list(c,dat);
			return 1;
		break;
		case PK_TRADE_OK:
			if(pLen!=5) return 0;
			item_trade_ok(c,dat);
			return 1;
		break;
		case PK_TRADE_CANCEL:
			if(pLen!=5) return 0;
			item_trade_cancel(c,dat);
			return 1;
		break;
		case PK_WARE_INFO:
			if(pLen!=5) return 0;
			item_ware_info(c);
			return 1;
		break;
		case PK_WARE_POS:
			if(pLen!=8) return 0;
			item_ware_pos(c,dat);
			return 1;
		break;
		case PK_WARE_DEPOS:
			if(pLen!=7) return 0;
			item_ware_depos(c,dat);
			return 1;
		break;
		case PK_SKILL_GET:
			skill_get(c,dat);
			return 1;
		break;
		case PK_SKILL_LVUP:
			skill_lvup(c,dat);
			return 1;
		break;
		case PK_SKILL_USE:
			skill_use(c,dat,conn);
			return 1;
		break;
		case PK_PT_REQ:
			if(pLen!=7) return 0;
			memcpy(&idx,&dat[3],2);
			thr_party_request(c,idx);
			return 1;
		break;
		case PK_PT_PERMIT:
			if(pLen!=8) return 0;
			memcpy(&idx,&dat[4],2);
			thr_party_permit(c,idx,dat[3]);
			return 1;
		break;
		case PK_PT_LEAVE:
			if(pLen!=5||c->party.flag!=1) return 0;
			thr_party_discon(c,0);//Ż��
			return 1;
		break;
		case PK_PT_BAN:
			if(pLen!=7||c->party.flag!=1) return 0;
			thr_party_bann(c,dat);
			return 1;
		break;
		case PK_PT_CHAT:
			if(c->party.flag!=1) return 0;
			thr_party_chat(c,dat);
			return 1;
		break;
		case PK_MAP_MOVE_REQ:
			thr_map_move_req(c,dat,udpsock);
			return 1;
		break;



		default:
			return 0;
	}
	return 1;
}







static short mvAction_set(type_session * c,short Dx, short Dy, short dirL){//������ ����

	if (!c) return 0;
	c->Dir		= dirL;
	c->userStat	= 1;
	if((map_isgo(Dx,Dy))==1) return 0;
	c->Dx 	= Dx;//dest set
	c->Dy 	= Dy;
	return 1;
}






static void thr_party_set(type_session *c){
	c->party.flag=0;
	c->party.ison1=0;
	c->party.cnt=0;
	c->party.memidx=0;
	c->party.infoFcnt=0;
	c->party.waitfor=NULL;
	c->party.master=NULL;
	c->party.ison1=0;
	c->party.mem2=NULL;
	c->party.ison2=0;
	c->party.mem3=NULL;
	c->party.ison3=0;
}







static void thr_party_request(type_session * c, unsigned short tgidx){

	type_session *	tc;
	unsigned short	nEnd = PEND;
	short	pLen=2,lvpt;
	char	msg[128];

	msg[pLen] = PK_PT_REQ;
	pLen+=1;

	if(c->level<4){//4���� ������ ��Ƽ�� ����
		msg[pLen] = 1;//error 1
		pLen += 1;
		memcpy(&msg[pLen], &nEnd, 2);
		pLen += 2;
		memcpy(&msg[0], &pLen, 2);
		map_pData_snd(c, msg, pLen);
		return;
	}

	if(c->party.flag==1){
		if(c->party.cnt==3||c->party.ison1!=2){//mem exceed or not master
			msg[pLen] = 2;//error 2
			pLen += 1;
			memcpy(&msg[pLen], &nEnd, 2);
			pLen += 2;
			memcpy(&msg[0], &pLen, 2);
			map_pData_snd(c, msg, pLen);
			return;
		}
	}

	tc=map_ret_chr(c->Ax,c->Ay,tgidx);//�Ÿ�üũ ����..
	if(tc==NULL){
		msg[pLen] = 3;//error 3
		pLen += 1;
		memcpy(&msg[pLen], &nEnd, 2);
		pLen += 2;
		memcpy(&msg[0], &pLen, 2);
		map_pData_snd(c, msg, pLen);
		return;
	}
	if(tc->party.flag==1){//�̹���Ƽ��
		msg[pLen] = 4;//error 4
		pLen += 1;
		memcpy(&msg[pLen], &nEnd, 2);
		pLen += 2;
		memcpy(&msg[0], &pLen, 2);
		map_pData_snd(c, msg, pLen);
		return;
	}
	if(tc->level>=c->level)
		lvpt = tc->level-c->level;
	else
		lvpt = c->level-tc->level;
	if(lvpt>5){//level���̷� ��Ƽ�ȵ�
		msg[pLen] = 5;//error 5
		pLen += 1;
		memcpy(&msg[pLen], &nEnd, 2);
		pLen += 2;
		memcpy(&msg[0], &pLen, 2);
		map_pData_snd(c, msg, pLen);
		return;
	}

	msg[pLen] = RET_TRUE;
	pLen += 1;
	memcpy(&msg[pLen],&c->userNo,2);
	pLen += 2;
	memcpy(&msg[pLen], &nEnd, 2);
	pLen += 2;
	memcpy(&msg[0], &pLen, 2);

	pthread_mutex_lock(&synclock);
	c->party.waitfor=tc;
	tc->party.waitfor=c;
	pthread_mutex_unlock(&synclock);

	map_pData_snd(tc, msg, pLen);

}






static void thr_party_permit(type_session * c,unsigned short ptMain, short flag){//ptMain: ��Ƽ��  		flag 0:���  1:����   2:�ٸ��۾���

	type_session 			* 	tc=NULL;//��Ƽ ��û��
	type_session 			* 	cc=NULL;//��Ƽ���� ������ �ִ� �����
	type_session 			* 	mc=NULL;//��Ƽ���
	unsigned short	nEnd = PEND;
	short	pLen=2,tNo=0,Len;
	int newFlag=0;
	char	msg[512],msg2[512];

	msg[pLen] = PK_PT_PERMIT;
	pLen+=1;

	if(c->party.flag==1){//����Ŷ�� ��Ƽ����ڰ� �������̴�.. �̹� ��Ƽ��..
		msg[pLen] = 3;
		pLen += 1;
		memcpy(&msg[pLen], &c->userNo, 2);
		pLen += 2;
		memcpy(&msg[pLen], &nEnd, 2);
		pLen += 2;
		memcpy(&msg[0], &pLen, 2);
		map_pData_snd(c, msg, pLen);
		return;
	}

	tc=(type_session *)c->party.waitfor;//��Ƽ��
	if(tc!=NULL){
		cc=(type_session *)tc->party.waitfor;//��Ƽ���� ������ �ִ� ��Ƽ �����
		if(cc==NULL){
			msg[pLen] = 4;
			pLen += 1;
			memcpy(&msg[pLen], &c->userNo, 2);
			pLen += 2;
			memcpy(&msg[pLen], &nEnd, 2);
			pLen += 2;
			memcpy(&msg[0], &pLen, 2);
			map_pData_snd(c, msg, pLen);
			//map_pData_snd(tc, msg, pLen);
			return;
		}

		if(flag!=0){
			msg[pLen] = 1;//����
			pLen += 1;
			memcpy(&msg[pLen], &c->userNo, 2);
			pLen += 2;
			memcpy(&msg[pLen], &nEnd, 2);
			pLen += 2;
			memcpy(&msg[0], &pLen, 2);
			map_pData_snd(tc, msg, pLen);//��Ƽ�忡�Ը�..
			return;
		}

		if(tc->userNo==ptMain&&cc->userNo==c->userNo){//��Ƽ��ã��
			if(tc->party.flag==1){//�̹� ��Ƽ���ϰ��
				if(tc->party.ison1!=2){//��Ƽ���̾ƴ�
					msg[pLen] = 5;
					pLen += 1;
					memcpy(&msg[pLen], &c->userNo, 2);
					pLen += 2;
					memcpy(&msg[pLen], &nEnd, 2);
					pLen += 2;
					memcpy(&msg[0], &pLen, 2);
					map_pData_snd(c, msg, pLen);
					return;
				}
			}

			pthread_mutex_lock(&synclock);
			if(tc->party.flag==0){//ù ��Ƽ �Ἲ�϶�
				newFlag=1;
				tc->party.flag=1;
				tc->party.cnt=2;

				tc->party.memidx=1;	//pt main
				tc->party.master=NULL;
				tc->party.ison1=2;	//ptmain
				tc->party.mem2=c;
				tc->party.ison2=1;

				c->party.flag=1;
				c->party.master=tc;
				c->party.ison1=1;		//ptmain
				c->party.ison2=2;

				tNo=2;//���γ� �ε���

			}else{//�̹� ������..
				if(tc->party.cnt==3){
					pthread_mutex_unlock(&synclock);
					msg[pLen] = 6;
					pLen += 1;
					memcpy(&msg[pLen], &c->userNo, 2);
					pLen += 2;
					memcpy(&msg[pLen], &nEnd, 2);
					pLen += 2;
					memcpy(&msg[0], &pLen, 2);
					map_pData_snd(c, msg, pLen);
					map_pData_snd(tc, msg, pLen);
					return;
				}

				newFlag=0;
				tc->party.cnt=3;
				c->party.flag=1;
				c->party.master=tc;
				c->party.ison1=1;//ptmain

				if(tc->party.ison2==0){//�ι�°ĭ �������� 2��° ����� ����..
					tNo=2;//���γ� �ε���
					mc=(type_session *)tc->party.mem3;
					if(mc==NULL) tNo=0;
					else{
						tc->party.mem2=c;
						tc->party.ison2=1;
						c->party.mem2=c;
						c->party.ison2=2;
						c->party.memidx=2;//2
						mc->party.mem3=c;
						mc->party.ison3=1;
					}
				}else if(tc->party.ison3==0){//����°ĭ ��������
					tNo=3;//���γ� �ε���
					mc=(type_session *)tc->party.mem2;
					if(mc==NULL) tNo=0;
					else{
						tc->party.mem3=c;
						tc->party.ison3=1;
						c->party.mem3=c;
						c->party.ison3=2;
						c->party.memidx=3;//2
						mc->party.mem2=c;
						mc->party.ison2=1;
					}
				}
				if(tNo==0){//����...
					//tc��c �� party breakó��..
					pthread_mutex_unlock(&synclock);//mutex unlock
					msg[pLen] = 7;
					pLen += 1;
					memcpy(&msg[pLen], &c->userNo, 2);
					pLen += 2;
					memcpy(&msg[pLen], &nEnd, 2);
					pLen += 2;
					memcpy(&msg[0], &pLen, 2);
					map_pData_snd(c, msg, pLen);
					map_pData_snd(tc, msg, pLen);
					return;
				}
			}
			pthread_mutex_unlock(&synclock);//mutex unlock

			msg[pLen] = RET_TRUE;
			pLen += 1;
			msg[pLen] = 2;//cnt
			pLen += 1;
			memcpy(&msg[pLen], &c->userNo, 2);
			pLen += 2;
			memcpy(&msg[pLen], &nEnd, 2);
			pLen += 2;
			memcpy(&msg[0], &pLen, 2);

			Len=2;
			msg2[Len] = PK_PT_INFO;
			Len += 1;
			msg2[Len] = 2;//cnt
			Len += 1;
			memcpy(&msg2[Len], &c->userNo, 2);
			Len += 2;
			memcpy(&msg2[Len], &c->hp_c, 2);
			Len += 2;
			memcpy(&msg2[Len], &c->Cx, 2);
			Len += 2;
			memcpy(&msg2[Len], &c->Cy, 2);
			Len += 2;
			memcpy(&msg2[Len], &tc->userNo, 2);
			Len += 2;
			memcpy(&msg2[Len], &tc->hp_m, 2);
			Len += 2;
			memcpy(&msg2[Len], &tc->hp_c, 2);
			Len += 2;
			memcpy(&msg2[Len], &tc->Cx, 2);
			Len += 2;
			memcpy(&msg2[Len], &tc->Cy, 2);
			Len += 2;
			memcpy(&msg2[Len], &nEnd, 2);
			Len += 2;
			memcpy(&msg2[0], &Len, 2);

			if(newFlag==1){
				map_pData_snd(tc, msg, pLen);//master ����
				map_pData_snd(c, msg2, Len);//new member ����
			}else{
				map_pData_snd(tc, msg, pLen);//master ����
				map_pData_snd(mc, msg, pLen);//member ����
				map_pData_snd(c, msg2, Len);//new member ����
			}
			return;
		}else{//error
			msg[pLen] = 7;//��Ƽ�� ������ Ʋ��..
			pLen += 1;
			memcpy(&msg[pLen], &c->userNo, 2);
			pLen += 2;
			memcpy(&msg[pLen], &nEnd, 2);
			pLen += 2;
			memcpy(&msg[0], &pLen, 2);
			map_pData_snd(c, msg, pLen);
			return;
		}
	}else{
		msg[pLen] = 8;//��Ƽ�� ������ Ʋ��..
		pLen += 1;
		memcpy(&msg[pLen], &c->userNo, 2);
		pLen += 2;
		memcpy(&msg[pLen], &nEnd, 2);
		pLen += 2;
		memcpy(&msg[0], &pLen, 2);
		map_pData_snd(c, msg, pLen);
	}
}








extern void thr_party_discon(type_session * c,char flag){//flag 0:Ż�� 1:disconnect

	type_session 			* 	tc=NULL;
	type_session 			* 	mc1=NULL;
	type_session 			* 	mc2=NULL;

	unsigned short	nEnd = PEND;
	short	pLen=2;
	char	msg[128];

	if(c==NULL) return;
	if(c->party.flag==0) return;

	if(c->party.ison1==2){//��Ƽ���ϰ�� party break
		msg[pLen] = PK_PT_BREAK;
		pLen+=1;
		memcpy(&msg[pLen],&c->userNo,2);
		pLen += 2;
		memcpy(&msg[pLen], &nEnd, 2);
		pLen += 2;
		memcpy(&msg[0], &pLen, 2);

		if(flag==0){//Ż��
			pthread_mutex_lock(&synclock);
			if(c->party.ison2==1){
				mc1=(type_session *)c->party.mem2;
				if(mc1!=NULL){
					thr_party_set(mc1);
				}
			}
			if(c->party.ison3==1){
				mc2=(type_session *)c->party.mem3;
				if(mc2!=NULL){
					thr_party_set(mc2);
				}
			}
			thr_party_set(c);
			pthread_mutex_unlock(&synclock);

			map_pData_snd(c, msg, pLen);

		}else{//disconn
			if(c->party.ison2==1){
				mc1=(type_session *)c->party.mem2;
				if(mc1!=NULL){
					thr_party_set(mc1);
				}
			}
			if(c->party.ison3==1){
				mc2=(type_session *)c->party.mem3;
				if(mc2!=NULL){
					thr_party_set(mc2);
				}
			}
		}
		if(mc1) map_pData_snd(mc1, msg, pLen);//��Ƽ ������ �˸�..
		if(mc2) map_pData_snd(mc2, msg, pLen);

	}else{//��Ƽ���ϰ��

		tc=(type_session *)c->party.master;
		if(tc!=NULL){
			if(tc->party.cnt==2){//party break

				msg[pLen] = PK_PT_BREAK;
				pLen+=1;
				memcpy(&msg[pLen],&tc->userNo,2);
				pLen += 2;
				memcpy(&msg[pLen], &nEnd, 2);
				pLen += 2;
				memcpy(&msg[0], &pLen, 2);

				if(flag==0){//Ż��
					pthread_mutex_lock(&synclock);
					if(tc->party.ison2==1){
						mc1=(type_session *)tc->party.mem2;
						if(mc1!=NULL){
							thr_party_set(mc1);
						}
					}
					if(tc->party.ison3==1){
						mc2=(type_session *)tc->party.mem3;
						if(mc2!=NULL){
							thr_party_set(mc2);
						}
					}
					thr_party_set(tc);
					pthread_mutex_unlock(&synclock);

				}else{//disconn

					if(tc->party.ison2==1){
						mc1=(type_session *)tc->party.mem2;
						if(mc1!=NULL){
							thr_party_set(mc1);
						}
					}
					if(tc->party.ison3==1){
						mc2=(type_session *)tc->party.mem3;
						if(mc2!=NULL){
							thr_party_set(mc2);
						}
					}
					thr_party_set(tc);
				}
				map_pData_snd(tc, msg, pLen);
				if(mc1) map_pData_snd(mc1, msg, pLen);//��Ƽ ������ �˸�..
				if(mc2) map_pData_snd(mc2, msg, pLen);
			}else{//��Ƽ���� Ż��...
				msg[pLen] = PK_PT_LEAVE;
				pLen+=1;
				msg[pLen] = 0;
				pLen+=1;
				memcpy(&msg[pLen],&c->userNo,2);
				pLen += 2;
				memcpy(&msg[pLen], &nEnd, 2);
				pLen += 2;
				memcpy(&msg[0], &pLen, 2);

				tc=(type_session *)c->party.master;
				if(tc==NULL) return;

				if(flag==0){//Ż��
					pthread_mutex_lock(&synclock);
					if(tc->party.ison2==1){
						mc1=(type_session *)tc->party.mem2;
						if(mc1==c){
							thr_party_set(mc1);
							tc->party.ison1=0;
							tc->party.cnt=2;
							tc->party.mem2=NULL;
							tc->party.ison2=0;
						}else{//error
							thr_party_set(c);
							pthread_mutex_unlock(&synclock);
							return;
						}
					}else{
						mc2=(type_session *)tc->party.mem3;
						if(mc2==c){
							thr_party_set(mc2);
							tc->party.ison1=0;
							tc->party.cnt=2;
							tc->party.mem2=NULL;
							tc->party.ison2=0;
						}else{
							thr_party_set(c);
							pthread_mutex_unlock(&synclock);
							return;
						}
					}
					pthread_mutex_unlock(&synclock);
					if(mc1) map_pData_snd(mc1, msg, pLen);//��Ƽ ������ �˸�..
					if(mc2) map_pData_snd(mc2, msg, pLen);
					map_pData_snd(tc, msg, pLen);
				}else{//disconn
					if(tc->party.ison2==1){
						mc1=(type_session *)tc->party.mem2;
						if(mc1==c){
							thr_party_set(mc1);
							tc->party.ison1=0;
							tc->party.cnt=2;
							tc->party.mem2=NULL;
							tc->party.ison2=0;
						}else{//error
							thr_party_set(c);
							pthread_mutex_unlock(&synclock);
							return;
						}
					}else{
						mc2=(type_session *)tc->party.mem3;
						if(mc2==c){
							thr_party_set(mc2);
							tc->party.ison1=0;
							tc->party.cnt=2;
							tc->party.mem2=NULL;
							tc->party.ison2=0;
						}else{
							thr_party_set(c);
							pthread_mutex_unlock(&synclock);
							return;
						}
					}
				}
				if(mc1&&mc1!=c) map_pData_snd(mc1, msg, pLen);//bk pt break..
				if(mc2&&mc2!=c) map_pData_snd(mc2, msg, pLen);
				map_pData_snd(tc, msg, pLen);
			}
		}//tc==NULL
	}//pt member
}







static void thr_party_bann(type_session * c,char * dat){

	type_session 			* 	mc1=NULL;
	type_session 			* 	mc2=NULL;

	unsigned short	nEnd = PEND;
	short	pLen=2;
	unsigned short idx;
	char	msg[128];

	if(c==NULL) return;
	if(c->party.flag==0||c->party.ison1!=2) return;
	memcpy(&idx,&dat[3],2);

	if(c->party.cnt==2){//party break
		if(c->party.ison2==1) mc1=(type_session *)c->party.mem2;
		if(mc1!=NULL){
			pthread_mutex_lock(&synclock);
			thr_party_set(mc1);
			thr_party_set(c);
			pthread_mutex_unlock(&synclock);
			msg[pLen] = PK_PT_BAN;
			pLen+=1;
			msg[pLen] = 1;
			pLen+=1;
			memcpy(&msg[pLen],&idx,2);
			pLen += 2;
			memcpy(&msg[pLen], &nEnd, 2);
			pLen += 2;
			memcpy(&msg[0], &pLen, 2);
			map_pData_snd(mc1, msg, pLen);
			map_pData_snd(c, msg, pLen);
			return;
		}
		if(c->party.ison3==1) mc1=(type_session *)c->party.mem3;
		if(mc1!=NULL){
			pthread_mutex_lock(&synclock);
			thr_party_set(mc1);
			thr_party_set(c);
			pthread_mutex_unlock(&synclock);
			msg[pLen] = PK_PT_BAN;
			pLen+=1;
			msg[pLen] = 1;
			pLen+=1;
			memcpy(&msg[pLen],&idx,2);
			pLen += 2;
			memcpy(&msg[pLen], &nEnd, 2);
			pLen += 2;
			memcpy(&msg[0], &pLen, 2);
			map_pData_snd(mc1, msg, pLen);
			map_pData_snd(c, msg, pLen);
			return;
		}
	}else{//bann
		if(c->party.ison2==1) mc1=(type_session *)c->party.mem2;
		if(mc1!=NULL){
			if(mc1->userNo==idx){
				pthread_mutex_lock(&synclock);
				thr_party_set(mc1);
				c->party.cnt=2;
				c->party.ison2=0;
				c->party.mem2=NULL;
				if(c->party.ison3==1) mc2=(type_session *)c->party.mem3;
				if(mc2!=NULL){
					mc2->party.ison2=0;
					mc2->party.mem2=NULL;
				}
				pthread_mutex_unlock(&synclock);
				msg[pLen] = PK_PT_BAN;
				pLen+=1;
				msg[pLen] = 1;
				pLen+=1;
				memcpy(&msg[pLen],&idx,2);
				pLen += 2;
				memcpy(&msg[pLen], &nEnd, 2);
				pLen += 2;
				memcpy(&msg[0], &pLen, 2);
				map_pData_snd(mc1, msg, pLen);
				map_pData_snd(mc2, msg, pLen);
				map_pData_snd(c, msg, pLen);
				return;
			}
		}
		if(c->party.ison3==1) mc1=(type_session *)c->party.mem3;
		if(mc1!=NULL){
			if(mc1->userNo==idx){
				pthread_mutex_lock(&synclock);
				thr_party_set(mc1);
				c->party.cnt=2;
				c->party.ison3=0;
				c->party.mem3=NULL;
				if(c->party.ison2==1) mc2=(type_session *)c->party.mem2;
				if(mc2!=NULL){
					mc2->party.ison3=0;
					mc2->party.mem3=NULL;
				}
				pthread_mutex_unlock(&synclock);
				msg[pLen] = PK_PT_BAN;
				pLen+=1;
				msg[pLen] = 1;
				pLen+=1;
				memcpy(&msg[pLen],&idx,2);
				pLen += 2;
				memcpy(&msg[pLen], &nEnd, 2);
				pLen += 2;
				memcpy(&msg[0], &pLen, 2);
				map_pData_snd(mc1, msg, pLen);
				map_pData_snd(mc2, msg, pLen);
				map_pData_snd(c, msg, pLen);
				return;
			}
		}
	}
	msg[pLen] = PK_PT_BAN;
	pLen+=1;
	msg[pLen] = 1;
	pLen+=1;
	memcpy(&msg[pLen],&idx,2);
	pLen += 2;
	memcpy(&msg[pLen], &nEnd, 2);
	pLen += 2;
	memcpy(&msg[0], &pLen, 2);
	map_pData_snd(c, msg, pLen);
}








static void thr_party_chat(type_session * c,char * dat){

	unsigned short	nEnd = PEND;
	short	pLen=2,msgLen;
	char	msg[MAX_PACKET_SIZE];

	msgLen=dat[3];
	if(msgLen>900) return;
	if(c->party.flag==0) return;

	msg[pLen] = PK_PT_CHAT;
	pLen+=1;
	msg[pLen] = RET_TRUE;
	pLen+=1;
	memcpy(&msg[pLen],&c->userNo,2);
	pLen+=2;
	msg[pLen] = msgLen;
	pLen+=1;
	memcpy(&msg[pLen],&dat[4],msgLen);
	pLen+=msgLen;
	memcpy(&msg[pLen], &nEnd, 2);
	pLen += 2;
	memcpy(&msg[0], &pLen, 2);
	map_party_sendAll(c,msg,pLen);
}







extern void thr_party_info(type_session * c){

	type_session * mc=NULL;

	unsigned short	nEnd = PEND;
	short	pLen=2,res=0;
	char	msg[MAX_PACKET_SIZE];

	msg[pLen] = PK_PT_INFO;
	pLen+=1;
	msg[pLen] = res;
	pLen+=1;
	msg[pLen] = c->party.cnt;
	pLen+=1;
	if(c->party.cnt==3){
		mc=(type_session *)c->party.mem2;
		if(mc!=NULL){
			memcpy(&msg[pLen],&mc->userNo,2);
			pLen+=2;
			memcpy(&msg[pLen],&mc->hp_m,2);
			pLen+=2;
			memcpy(&msg[pLen],&mc->hp_c,2);
			pLen+=2;
			memcpy(&msg[pLen],&mc->Cx,2);
			pLen+=2;
			memcpy(&msg[pLen],&mc->Cy,2);
			pLen+=2;
		}else res=1;
		mc=(type_session *)c->party.mem3;
		if(mc!=NULL){
			memcpy(&msg[pLen],&mc->userNo,2);
			pLen+=2;
			memcpy(&msg[pLen],&mc->hp_m,2);
			pLen+=2;
			memcpy(&msg[pLen],&mc->hp_c,2);
			pLen+=2;
			memcpy(&msg[pLen],&mc->Cx,2);
			pLen+=2;
			memcpy(&msg[pLen],&mc->Cy,2);
			pLen+=2;
		}else res=2;

	}else if(c->party.cnt==2){
		mc=(type_session *)c->party.mem2;
		if(mc!=NULL){
			memcpy(&msg[pLen],&mc->userNo,2);
			pLen+=2;
			memcpy(&msg[pLen],&mc->hp_m,2);
			pLen+=2;
			memcpy(&msg[pLen],&mc->hp_c,2);
			pLen+=2;
			memcpy(&msg[pLen],&mc->Cx,2);
			pLen+=2;
			memcpy(&msg[pLen],&mc->Cy,2);
			pLen+=2;
		}else{
			mc=(type_session *)c->party.mem3;
			if(mc==NULL){
				res=3;
			}else{
				memcpy(&msg[pLen],&mc->userNo,2);
				pLen+=2;
				memcpy(&msg[pLen],&mc->hp_m,2);
				pLen+=2;
				memcpy(&msg[pLen],&mc->hp_c,2);
				pLen+=2;
				memcpy(&msg[pLen],&mc->Cx,2);
				pLen+=2;
				memcpy(&msg[pLen],&mc->Cy,2);
				pLen+=2;
			}
		}
	}else	res=4;

	if(res==0){
		memcpy(&msg[pLen],&c->userNo,2);
		pLen+=2;
		memcpy(&msg[pLen],&c->hp_m,2);
		pLen+=2;
		memcpy(&msg[pLen],&c->hp_c,2);
		pLen+=2;
		memcpy(&msg[pLen],&c->Cx,2);
		pLen+=2;
		memcpy(&msg[pLen],&c->Cy,2);
		pLen+=2;

		memcpy(&msg[pLen], &nEnd, 2);
		pLen += 2;
		memcpy(&msg[0], &pLen, 2);
		map_party_sendAll(c,msg,pLen);
	}else{//�����϶� ��Ƽ ��ü �Ҽ��� �ְ�..
		msg[3]=res;
		memcpy(&msg[4], &nEnd, 2);
		pLen=6;
		memcpy(&msg[0], &pLen, 2);
		map_party_sendAll(c,msg,pLen);
	}
}








static void thr_map_move_req(type_session * c, char * dat, int udpsock){

	unsigned char gidx=0,res=0;
	int dist=0,udlen=0;
	unsigned int sKey=0,svrIdx;
	type_sockadr*	udsock;
	short	Len=2;
	char	msg[64];
	unsigned short	nEnd = PEND;

	gidx=dat[3];

	if(gidx>7||gidx==_MAP_IDX) res=1;//gidx(gateway index�� _MAP_IDX������ ���� gateway�̴�.
	else{
		switch(gidx){
			case 0://�Ÿ�üũ �Ÿ� 10�̻��̸� ����
				dist=map_ret_dist(c->Cx,c->Cy,_MAP_GWAY_0_X,_MAP_GWAY_0_Y);
				if(dist>10) res=2;
				else{
					svrIdx=_MAP_GWAY_0_TO_SVR;
					udsock=db_ret_udpsock(_MAP_GWAY_0_TO_SVR);
					udlen=db_ret_udpLen(_MAP_GWAY_0_TO_SVR);
				}
			break;
			case 1:
				dist=map_ret_dist(c->Cx,c->Cy,_MAP_GWAY_1_X,_MAP_GWAY_1_Y);
				if(dist>10) res=2;
				else{
					svrIdx=_MAP_GWAY_1_TO_SVR;
					udsock=db_ret_udpsock(_MAP_GWAY_1_TO_SVR);
					udlen=db_ret_udpLen(_MAP_GWAY_1_TO_SVR);
				}
			break;
			case 2:
				dist=map_ret_dist(c->Cx,c->Cy,_MAP_GWAY_2_X,_MAP_GWAY_2_Y);
				if(dist>10) res=2;
				else{
					svrIdx=_MAP_GWAY_2_TO_SVR;
					udsock=db_ret_udpsock(_MAP_GWAY_2_TO_SVR);
					udlen=db_ret_udpLen(_MAP_GWAY_2_TO_SVR);
				}
			break;
			case 3:
				dist=map_ret_dist(c->Cx,c->Cy,_MAP_GWAY_3_X,_MAP_GWAY_3_Y);
				if(dist>10) res=2;
				else{
					svrIdx=_MAP_GWAY_3_TO_SVR;
					udsock=db_ret_udpsock(_MAP_GWAY_3_TO_SVR);
					udlen=db_ret_udpLen(_MAP_GWAY_3_TO_SVR);
				}
			break;
			case 4://�Ÿ�üũ �Ÿ� 10�̻��̸� ����
				dist=map_ret_dist(c->Cx,c->Cy,_MAP_GWAY_4_X,_MAP_GWAY_4_Y);
				if(dist>10) res=2;
				else{
					svrIdx=_MAP_GWAY_0_TO_SVR;
					udsock=db_ret_udpsock(_MAP_GWAY_4_TO_SVR);
					udlen=db_ret_udpLen(_MAP_GWAY_4_TO_SVR);
				}
			break;
			case 5:
				dist=map_ret_dist(c->Cx,c->Cy,_MAP_GWAY_5_X,_MAP_GWAY_5_Y);
				if(dist>10) res=2;
				else{
					svrIdx=_MAP_GWAY_1_TO_SVR;
					udsock=db_ret_udpsock(_MAP_GWAY_5_TO_SVR);
					udlen=db_ret_udpLen(_MAP_GWAY_5_TO_SVR);
				}
			break;
			case 6:
				dist=map_ret_dist(c->Cx,c->Cy,_MAP_GWAY_6_X,_MAP_GWAY_6_Y);
				if(dist>10) res=2;
				else{
					svrIdx=_MAP_GWAY_2_TO_SVR;
					udsock=db_ret_udpsock(_MAP_GWAY_6_TO_SVR);
					udlen=db_ret_udpLen(_MAP_GWAY_6_TO_SVR);
				}
			break;
			case 7:
				dist=map_ret_dist(c->Cx,c->Cy,_MAP_GWAY_7_X,_MAP_GWAY_7_Y);
				if(dist>10) res=2;
				else{
					svrIdx=_MAP_GWAY_3_TO_SVR;
					udsock=db_ret_udpsock(_MAP_GWAY_7_TO_SVR);
					udlen=db_ret_udpLen(_MAP_GWAY_7_TO_SVR);
				}
			break;
		}
	}

	//Ÿ svr�� ���� udp��....
	if(res==0){
		sKey = ((unsigned int)rand())^((unsigned int)time(NULL));
		msg[Len]=PKU_MAP_KEY;
		Len+=1;
		msg[Len]=_MAP_IDX;//������ �ε���
		Len+=1;
		memcpy(&msg[Len],&c->userNo,2);
		Len+=2;
		memcpy(&msg[Len],&sKey,4);
		Len+=4;
		msg[Len]=c->uLen;
		Len+=1;
		memcpy(&msg[Len],&c->userid[0],c->uLen);
		Len+=c->uLen;
		memcpy(&msg[Len], &nEnd, 2);
		Len += 2;
		memcpy(&msg[0], &Len, 2);
		sendto(udpsock, msg, Len, 0, (SA *)udsock, udlen);
	}else{//error
		msg[Len]=PK_MAP_MOVE_REQ;
		Len+=1;
		msg[Len]=res;
		Len+=1;
		memcpy(&msg[Len], &nEnd, 2);
		Len+=2;
		memcpy(&msg[0], &Len, 2);
		map_pData_snd(c,msg,Len);
	}
}







extern void thr_map_move_key_ok(char * dat, void * conn){//�ű� �����κ��� ok��Ŷ�� �޾�����...

	unsigned char gidx=0,res=0;
	type_session * c;
	char svrip[4];
	short	Len=2,svrport;
	char	msg[MAX_PACKET_SIZE];
	unsigned short	userNo;
	unsigned short	nEnd = PEND;

	gidx=dat[3];
	memcpy(&userNo,&dat[4],2);
	c=session_ret_session(userNo);
	if(c==NULL) return;
	else if(c->userNo!=userNo) res=3;
	else{
		memcpy(svrip, db_ret_tcpip(gidx),4);
		svrport=db_ret_tcpport(gidx);
		if(svrport==-1) res=4;
	}

	msg[Len]=PK_MAP_MOVE_REQ;
	Len+=1;
	msg[Len]=res;
	Len+=1;

	if(res==0){
		res=db_save_all(c,conn);//���� ĳ���� ���� ����
		c->dbLoaded=0;//�ߺ� ������ ���� ����
		c->state=conn_state_empty;
		//���� ���� ���·� ����.-> ���̻� �������� ���� ��Ŷ �۽� �Ұ�

		memcpy(&msg[Len],&dat[6],4);
		Len+=4;
		memcpy(&msg[Len],&svrip[0],4);
		Len+=4;
		memcpy(&msg[Len],&svrport,2);
		Len+=2;
		msg[Len]=gidx;
		Len+=1;
	}else if(res==3) return;
	memcpy(&msg[Len], &nEnd, 2);
	Len += 2;
	memcpy(&msg[0], &Len, 2);
	map_pData_snd(c,msg,Len);
}






static void thr_inveninfo(type_session * c){

	char msg[128];
	short Len=2;
	int i,cnt=0;
	unsigned short	nEnd = PEND;

	if(c==NULL) return;

	msg[Len]=PK_INVEN_INFO;
	Len+=2;

	for(i=0;i<4;i++){
		if(c->inven[i]>0){
			msg[Len]=i;
			Len+=1;
			memcpy(&msg[Len],&c->inven[i],2);
			Len+=2;
			msg[Len]=c->ware_cnt[i];
			Len+=1;
			cnt+=1;
		}
	}
	msg[3]=cnt;
	memcpy(&msg[Len],&nEnd,2);
	Len+=2;
	memcpy(&msg[0],&Len,2);
	map_pData_snd(c,msg,Len);

}








static void thr_skillinfo(type_session * c){

	char msg[128];
	short Len=2;
	int i,cnt=0;
	unsigned short	nEnd = PEND;

	if(c==NULL) return;

	msg[Len]=PK_SKILL_INFO;
	Len+=2;

	for(i=0;i<4;i++){
		if(c->skill[i]>0){
			msg[Len]=i;
			Len+=1;
			memcpy(&msg[Len],&c->skill[i],2);
			Len+=2;
			msg[Len]=c->skill_lv[i];
			Len+=1;
			cnt+=1;
		}
	}
	msg[3]=cnt;
	memcpy(&msg[Len],&nEnd,2);
	Len+=2;
	memcpy(&msg[0],&Len,2);
	map_pData_snd(c,msg,Len);

}
