#ifndef PUBLIC_INCLUDED
#include "publicInc.h"
#endif

typedef enum
{
    packet_class_normal,
    packet_class_chrinit
} type_packet_class;

typedef struct packet
#ifdef PACKET_INTERNAL_ACCESS
{
	int					cli_sock;
	int					size;
	char              	data[MAX_PACKET_SIZE];
	void *				session;
}
#endif
#ifdef NEED_PACKET_INTERNAL_ACCESS
{
	int					cli_sock;
	int					size;
	char              	data[MAX_PACKET_SIZE];
	void *				session;
}
#endif
type_packet;



extern type_packet * packet_create();
extern void packet_destroy(type_packet const * packet);

//extern void packet_del_ref(type_packet * packet);
/*
extern type_packet * packet_add_ref(type_packet * packet);
extern void const * packet_get_raw_data_const(type_packet const * packet, unsigned int offset);
extern type_packet_class packet_get_class(type_packet const * packet);
extern void * packet_get_raw_data_build(type_packet * packet, unsigned int offset);
extern unsigned short packet_get_size(type_packet const * packet);//from struct
extern int packet_set_size(type_packet * packet, unsigned short size);
extern int packet_set_size_pt(type_packet ** packet, unsigned short size);
*/

