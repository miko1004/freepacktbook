#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "predef.h"

typedef enum { conf_type_int, conf_type_char } conf_type_t;
typedef struct
{
    char const * directive;
    conf_type_t  type;
    char const * defcharval;
    unsigned int defintval;
} preconf_t;

static preconf_t conf_table[] =
{
    { "logfile",        conf_type_char,    "fidex.log",                   0   },
    { "adfile",         conf_type_char,    "fidex.gif",	                 0   },
    { "adlink",         conf_type_char,    "http://www.boagame.net/",	  0   },
    { "gameport",       conf_type_int,     NULL,                          9901},
    { "udpport",        conf_type_int,     NULL,                          8801},
    { "version",      	conf_type_char,    "1.00",                           0}
};

#define DEF_LEN 64
#define INC_LEN 16

extern char * file_get_line(FILE * fp)
{
	char *       line;
	unsigned int len=DEF_LEN;
	unsigned int pos=0;
	int          temp;

	if (!(line = malloc(DEF_LEN)))
		return NULL;

	while ((temp=fgetc(fp))!=EOF)
	{
		if (((char)temp)=='\n')
			break;
		line[pos++] = (char)temp;
		if ((pos+1)>=len)
		{
			char * newline;

			len += INC_LEN;
			if (!(newline = realloc(line,len)))
			{
				free(line);
				return NULL;
			}
			line = newline;
		}
	}

	if (temp==EOF && pos<1)
	{
		free(line);
		return NULL;
	}
	line[pos] = '\0';
	return line;
}

static int checkIntVal(char const * str)
{
	char const * cp;

	for (cp=str; *cp; cp++)
		if (!isdigit((int)*cp))
			return -1;
	return 0;
}

static int processDirective(char const * directive, char const * value, unsigned int curLine)
{
	unsigned int i;

	if (!directive || !value)
	{
		printf("ERROR NULL string found in processdirective\n");
		return -1;
	}

	for (i=0; conf_table[i].directive; i++)
		if (strcasecmp(conf_table[i].directive,directive) == 0)
		{
			switch (conf_table[i].type)
			{
				case conf_type_char:
					if (!(conf_table[i].defcharval = strdup(value)))
						printf("ERROR in parsing conf \n");
					break;

				case conf_type_int:
					if (checkIntVal(value) == 0)
						conf_table[i].defintval = (unsigned int)strtoul(value,NULL,10);
					else
						printf("Invalid integer value in conf file\n");
					break;

				default:
					printf("ERROR in processdirectives\n");
			}
			return 0;
		}

	printf("Unknown element found in processdirectives\n");
	return -1;
}

extern int conf_load(char const * filename)
{
	/* load file */
	if (filename)
	{
		FILE *       fp;
		char *       buff;
		char *       cp;
		unsigned int currline;
		char const * directive;
		char const * value;

		if (!(fp = fopen(filename,"r")))
		{
			printf("ERROR in open file\n");
			return -1;
		}

		/* Read the configuration file */
		for (currline=1; (buff = file_get_line(fp)); currline++)
		{
			cp = buff;

			while (*cp=='\t' || *cp==' ') cp++;
			if (*cp=='\0' || *cp=='#')
			{
				free(buff);
				continue;
			}

			directive = strtok(cp," \t=");
			value = strtok(NULL," \t=");

			processDirective(directive,value,currline);

			free(buff);
		}
	}
	return 0;
}

static char const * get_char_conf(char const * directive)
{
	unsigned int i;

	for (i=0; conf_table[i].directive; i++)
		if (conf_table[i].type==conf_type_char && strcasecmp(conf_table[i].directive,directive)==0)
			return conf_table[i].defcharval;

	return NULL;
}


static unsigned int get_int_conf(char const * directive)
{
	unsigned int i;

	for (i=0; conf_table[i].directive; i++)
		if (conf_table[i].type==conf_type_int && strcasecmp(conf_table[i].directive,directive)==0)
			return conf_table[i].defintval;

	return 0;
}






/*******************************************************************************/
/*							config���Ͽ� ������ �ܾ� �Լ��� �߰��ؾߵ� 					 */
/*******************************************************************************/




extern char const * predef_logfile(void)
{
    return get_char_conf("logfile");
}

extern char const * predef_adfile(void)
{
    return get_char_conf("adfile");
}

extern char const * predef_adlink(void)
{
    return get_char_conf("adlink");
}

extern unsigned int predef_gameport(void)
{
    return get_int_conf("gameport");
}

extern unsigned int predef_udpport(void)
{
    return get_int_conf("udpport");
}

extern char const * predef_version(void)
{
    return get_char_conf("version");
}
