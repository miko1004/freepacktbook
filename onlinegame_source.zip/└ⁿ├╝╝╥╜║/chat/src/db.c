#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <strings.h>
#include <mysql.h>
#include "predef.h"
#include "db.h"

#define NEED_ONLY_MUTEX_VAR
#include "svr.h"
#undef NEED_ONLY_MUTEX_VAR

extern int db_user_auth(char * userid, char *passwd, int passlen, void * conn)
{
	int	state,len;
	MYSQL_RES *result;
	MYSQL_ROW row;
	char query[256];

	memset(query,0,256);
	sprintf(query,"select passwd from userinfo where userid='%s'",userid);

	state = mysql_query((MYSQL *)conn, query);
	if( state == -1 ) {
		printf("testXX%s\n",mysql_error((MYSQL *)conn));
		return 0;
	}
	result = mysql_store_result((MYSQL *)conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
//		printf("mysql fail return value 0 \n");
		mysql_free_result(result);
		return 1;
	}
	row = mysql_fetch_row(result);
	mysql_free_result(result);

	len = strlen(row[0]);
	if(passlen==len){
		if(!strncmp(row[0],passwd,len)){
			return 1;
		}else{
			return 0;
		}
	}else{
		return 0;
	}
}
























/*
extern char * db_ret_realip(int idx){
	if(idx >=MX_SVR_NO)
		return NULL;
	return worldinfo[idx].ip;
}
extern short db_ret_realport(int idx){
	if(idx >=MX_SVR_NO)
		return -1;
	return worldinfo[idx].tport;
}
extern type_sockadr * db_ret_udpsock(int idx){
	if(idx >=MX_SVR_NO)
		return NULL;
	return worldinfo[idx].udpSvr;
}
extern int db_ret_udpLen(int idx){
	if(idx >=MX_SVR_NO)
		return -1;
	return worldinfo[idx].udpLen;
}
extern int db_ret_mapindex(int idx){
	if(idx >=MX_SVR_NO)
		return -1;
	return worldinfo[idx].g_map_idx;
}
extern type_sockadr * db_ret_chatsock(){
	return chatSvr.udpSvr;
}
extern int db_ret_chatLen(){
	return chatSvr.udpLen;
}

extern int db_LOAD_SERVERLIST(){

	MYSQL mysql;
	MYSQL_RES *result;
	char query[128];
	int state,idx;
	MYSQL *connection;
	MYSQL_ROW row;

	connection = (MYSQL *)mysql_connect(&mysql, _DBSERV, _DBID, _DBPASS);
	if( connection == NULL ) {
		printf(mysql_error(&mysql));
		return 0;
	}

	state = mysql_select_db(connection,_DBDB);
	if( state == -1 ) {
		printf("a %s\n",mysql_error(connection));
		mysql_close(connection);
		return 0;
	}
	memset(query,0,128);
	sprintf(query,"select SVR_IDX, SVR_IP1, SVR_IP2, SVR_IP3, SVR_IP4, SVR_RPORT, SVR_VIP, SVR_VPORT,SVR_G_MAP from SERVER_LIST");
	state = mysql_query(connection, query);
	if( state == -1 ) {
		return 0;
	}

	result = mysql_store_result(connection);
	state = mysql_num_rows(result);

	if( state == 0 ) {
		mysql_free_result(result);
		return 0;
	}else{

		while((row = mysql_fetch_row(result))!= NULL){
			idx = atoi(row[0]);
			//worldinfo[idx].udpSvr = malloc(sizeof(type_sockadr));
			worldinfo[idx].ip[0] = atoi(row[1]);
			worldinfo[idx].ip[1] = atoi(row[2]);
			worldinfo[idx].ip[2] = atoi(row[3]);
			worldinfo[idx].ip[3] = atoi(row[4]);
			worldinfo[idx].tport = atoi(row[5]);
			worldinfo[idx].g_map_idx = atoi(row[8]);

			bzero(&worldinfo[idx].udpSvr[0], sizeof(worldinfo[idx].udpSvr[0]));
			worldinfo[idx].udpSvr[0].sin_family = AF_INET;
			worldinfo[idx].udpSvr[0].sin_port = htons(atoi(row[7]));
			inet_pton(AF_INET, row[6], &worldinfo[idx].udpSvr[0].sin_addr);
			worldinfo[idx].udpLen = sizeof(worldinfo[idx].udpSvr[0]);
		}
	}
	mysql_free_result(result);

	//init chat udp sock addr
	bzero(&chatSvr.udpSvr[0], sizeof(chatSvr.udpSvr[0]));
	chatSvr.udpSvr[0].sin_family = AF_INET;
	chatSvr.udpSvr[0].sin_port = htons(9904);
	inet_pton(AF_INET,_CHATSERVER, &chatSvr.udpSvr[0].sin_addr);
	chatSvr.udpLen = sizeof(chatSvr.udpSvr[0]);

	return 1;
}

extern void db_test(void * conn)
{
	int	state;

	MYSQL_RES *result;
	MYSQL_ROW row;
	char query[256];

	memset(query,0,256);
	sprintf(query,"select sysdate()");

	state = mysql_query((MYSQL *)conn, query);
	if( state == -1 ) {
		printf("testXX%s\n",mysql_error((MYSQL *)conn));
		return ;
	}
	result = mysql_store_result((MYSQL *)conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("mysql fail return value 0 \n");
		mysql_free_result(result);
		return ;
	}
	row = mysql_fetch_row(result);
	printf("res: %s\n",row[0]);
	mysql_free_result(result);
}


extern void db_load_npcList(void * con)
{
	int	state;
	MYSQL	*	conn;
	MYSQL_RES *result;
	MYSQL_ROW row;
	char query[512];
	unsigned short npc_type,lv, no,gtype,speed,itm1,itm2,itm3,itm4,itm5,itm6,itm7,itm8,itm9,itm10,itm1R,itm2R,itm3R,itm4R,itm5R,itm6R,itm7R,itm8R,itm9R,itm10R;

	conn =(MYSQL *)con;
	memset(query,0,512);
	sprintf(query,"select NPC_NO,NPC_GTYPE,NPC_LEVEL,NPC_SPEED,NPC_ITM1,NPC_ITM2,NPC_ITM3,NPC_ITM4,NPC_ITM5,NPC_ITM6,NPC_ITM7,NPC_ITM8,NPC_ITM9,NPC_ITM10,NPC_ITM1_RATE,NPC_ITM2_RATE,NPC_ITM3_RATE,NPC_ITM4_RATE,NPC_ITM5_RATE,NPC_ITM6_RATE,NPC_ITM7_RATE,NPC_ITM8_RATE,NPC_ITM9_RATE,NPC_ITM10_RATE,NPC_TYPE from TB_NPC");

	state = mysql_query(conn, query);
	if( state == -1 ) {
		printf("load npc list XX%s\n",mysql_error(conn));
		return ;
	}
	result = mysql_store_result(conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("���Ǿ������� ����..\n");
		mysql_free_result(result);
		return ;
	}

	while((row = mysql_fetch_row(result))!= NULL){

		no = atoi(row[0]);
		gtype = atoi(row[1]);
		lv = atoi(row[2]);
		speed = atoi(row[3]);

		itm1= atoi(row[4]);
		itm2= atoi(row[5]);
		itm3= atoi(row[6]);
		itm4= atoi(row[7]);
		itm5= atoi(row[8]);
		itm6= atoi(row[9]);
		itm7= atoi(row[10]);
		itm8= atoi(row[11]);
		itm9= atoi(row[12]);
		itm10= atoi(row[13]);

		itm1R= atoi(row[14]);
		itm2R= atoi(row[15]);
		itm3R= atoi(row[16]);
		itm4R= atoi(row[17]);
		itm5R= atoi(row[18]);
		itm6R= atoi(row[19]);
		itm7R= atoi(row[20]);
		itm8R= atoi(row[21]);
		itm9R= atoi(row[22]);
		itm10R= atoi(row[23]);

		npc_type = atoi(row[24]);
//if(npc_type==2){
//printf("no:%d, gtype:%d lv:%d \n",no,gtype,lv);
//}
		npc_add_mondef_arr(no-1,gtype,lv,speed,itm1,itm2,itm3,itm4,itm5,itm6,itm7,itm8,itm9,itm10,itm1R,itm2R,itm3R,itm4R,itm5R,itm6R,itm7R,itm8R,itm9R,itm10R,npc_type);
		//npc_add_mondef_arr(no,gtype,lv,speed);
	}

	mysql_free_result(result);
}

extern void db_load_itemList(void * con)
{
	int	state,cnt=0;
	MYSQL	*	conn;
	MYSQL_RES *result;
	MYSQL_ROW row;
	char query[256];

	conn =(MYSQL *)con;
	init_type_item();
	memset(query,0,256);
	sprintf(query,"select * from TB_ITEM");

	state = mysql_query(conn, query);
	if( state == -1 ) {
		printf("db_load_itemListXX%s\n",mysql_error(conn));
		return ;
	}
	result = mysql_store_result(conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("db no item list found0 \n");
		mysql_free_result(result);
		return ;
	}

	while((row = mysql_fetch_row(result))!= NULL){
		cnt++;
		add_list_item(row);//row ������ ����Ʈ�� �߰�..
	}
printf("������ �� %d �� �ε��\n",cnt);
	mysql_free_result(result);

}

extern void db_load_expTable(void * con)
{
	int	state;
	MYSQL	*	conn;
	MYSQL_RES *result;
	MYSQL_ROW row;
	char query[256];
	unsigned int lv,exp;


	conn =(MYSQL *)con;

	memset(query,0,256);
	sprintf(query,"select * from TB_EXP order by level asc");

	state = mysql_query(conn, query);
	if( state == -1 ) {
		printf("db_load_expTable XX%s\n",mysql_error(conn));
		return ;
	}
	result = mysql_store_result(conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("mysql fail return value 0 \n");
		mysql_free_result(result);
		return ;
	}

	while((row = mysql_fetch_row(result))!= NULL){
		lv = atoi(row[0]);
		exp = atoi(row[1]);
		chr_add_exptb(lv,exp);
	}

	mysql_free_result(result);

}

extern short db_load_charInfo(void * con,void * data,char * userid,short flag,short Tx,short Tz)//���߿� ret ������ �ٲ㼭 �ùٸ��� �ҷ������� üũ�ؾ��Ѵ�..
{
	int	state,i;
	MYSQL	*	conn;
	MYSQL_RES *result;
	MYSQL_ROW row;
	char query[256];
	int tmp,a5;
	short a1,a2,a3,a4;
	type_character * chr;
	chr = (type_character *)data;
	conn =(MYSQL *)con;
printf("db_load_charInfo\n");
	memset(query,0,256);
	sprintf(query,"select * from TB_HERO a,TB_SKILL b where a.userid='%s' and a.HERO_NAME='%s' and a.userid=b.userid and a.HERO_NAME=b.HERO_NAME",userid,chr->name);
	//sprintf(query,"select * from TB_HERO where HERO_NAME='%s' and USERID='%s'",chr->name,userid);

	state = mysql_query(conn, query);
	if( state == -1 ) {
		printf("db_load_charInfoXX%s\n",mysql_error(conn));
		return 0;
	}
	result = mysql_store_result(conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("in db_load_charinfo select 0 row \n");
		mysql_free_result(result);
		return 0;
	}
	row = mysql_fetch_row(result);

	chr->race			=	atoi(row[2]);
	chr->sex				=	atoi(row[3]);
	chr->fame			=	atoi(row[4]);
	chr->kill			=	atoi(row[5]);
	chr->nation			=	atoi(row[6]);
	//chr->title			=	row[7];
	chr->strength		=	atoi(row[8]);
	chr->dex				=	atoi(row[9]);
	chr->intel			=	atoi(row[10]);
	chr->cond			=	atoi(row[11]);
	chr->hp_c			=	atoi(row[12]);
	chr->exp				=	atoi(row[13]);
	chr->level			=	atoi(row[14]);
	chr->lvpoint		=	atoi(row[15]);
	chr->skilexp		=	atoi(row[16]);
//	chr->skillpoint	=	atoi(row[17]);
	chr->jobno			=	atoi(row[17]);
	chr->classno		=	atoi(row[18]);
	chr->classlevel	=	atoi(row[19]);

	chr->statuscd		=	stat_stand;//atoi(row[30]);

	chr->statusremain	=	atoi(row[21]);
	//chr->worldmap		=	atoi(row[22]);
	chr->worldmap		=MAP_IDX;
	if(flag==0){//new~~~
		chr->Cx				=	atoi(row[23]);
		chr->Cz				=	atoi(row[24]);
	}else{//map move
		chr->Cx				=	Tx;
		chr->Cz				=	Tz;
	}
	chr->eq[t_equip_head]		=	atoi(row[25]);
	chr->eq_s[t_equip_head]		=	atoi(row[26]);
	chr->eq[t_equip_body]		=	atoi(row[27]);
	chr->eq_s[t_equip_body]		=	atoi(row[28]);
	chr->eq[t_equip_weapon]		=	atoi(row[29]);
	chr->eq_s[t_equip_weapon]	=	atoi(row[30]);
	chr->eq[t_equip_shield]		=	atoi(row[31]);
	chr->eq_s[t_equip_shield]	=	atoi(row[32]);
	chr->eq[t_equip_glove]		=	atoi(row[33]);
	chr->eq_s[t_equip_glove]	=	atoi(row[34]);
	chr->eq[t_equip_boots]		=	atoi(row[35]);
	chr->eq_s[t_equip_boots]	=	atoi(row[36]);
	chr->eq[t_equip_armlet1]	=	atoi(row[37]);
	chr->eq_s[t_equip_armlet1]	=	atoi(row[38]);
	chr->eq[t_equip_armlet2]	=	atoi(row[39]);
	chr->eq_s[t_equip_armlet2]	=	atoi(row[40]);
	chr->eq[t_equip_ring1]		=	atoi(row[41]);
	chr->eq_s[t_equip_ring1]	=	atoi(row[42]);
	chr->eq[t_equip_ring2]		=	atoi(row[43]);
	chr->eq_s[t_equip_ring2]	=	atoi(row[44]);
	chr->eq[t_equip_ring3]		=	atoi(row[45]);
	chr->eq_s[t_equip_ring3]	=	atoi(row[46]);
	chr->eq[t_equip_ring4]		=	atoi(row[47]);
	chr->eq_s[t_equip_ring4]	=	atoi(row[48]);

	chr->zule			=	atoi(row[49]);
	chr->coin        	=	atoi(row[50]);
//51 id
//52 char name
	chr->skill[0]					=atoi(row[53]);
	chr->skill_lv[0]				=atoi(row[54]);
	chr->skill[1]					=atoi(row[55]);
	chr->skill_lv[1]				=atoi(row[56]);
	chr->skill[2]					=atoi(row[57]);
	chr->skill_lv[2]				=atoi(row[58]);
	chr->skill[3]					=atoi(row[59]);
	chr->skill_lv[3]				=atoi(row[60]);
	chr->skill[4]					=atoi(row[61]);
	chr->skill_lv[4]				=atoi(row[62]);
	chr->skill[5]					=atoi(row[63]);
	chr->skill_lv[5]				=atoi(row[64]);
	chr->skill[6]					=atoi(row[65]);
	chr->skill_lv[6]				=atoi(row[66]);
	chr->skill[7]					=atoi(row[67]);
	chr->skill_lv[7]				=atoi(row[68]);

	chr->gskill1					=atoi(row[69]);
	chr->gskill2					=atoi(row[70]);
//printf("��񿡼� ����ų:%d,%d\n",chr->gskill1,chr->gskill2);
//	unsigned short	skill_inv[15];
//	unsigned char	skill_lv_inv[15];

	chr->skill_inv[0]				=atoi(row[71]);
	chr->skill_lv_inv[0]			=atoi(row[72]);
	chr->skill_inv[1]				=atoi(row[73]);
	chr->skill_lv_inv[1]			=atoi(row[74]);
	chr->skill_inv[2]				=atoi(row[75]);
	chr->skill_lv_inv[2]			=atoi(row[76]);
	chr->skill_inv[3]				=atoi(row[77]);
	chr->skill_lv_inv[3]			=atoi(row[78]);
	chr->skill_inv[4]				=atoi(row[79]);
	chr->skill_lv_inv[4]			=atoi(row[80]);
	chr->skill_inv[5]				=atoi(row[81]);
	chr->skill_lv_inv[5]			=atoi(row[82]);
	chr->skill_inv[6]				=atoi(row[83]);
	chr->skill_lv_inv[6]			=atoi(row[84]);
	chr->skill_inv[7]				=atoi(row[85]);
	chr->skill_lv_inv[7]			=atoi(row[86]);
	chr->skill_inv[8]				=atoi(row[87]);
	chr->skill_lv_inv[8]			=atoi(row[88]);
	chr->skill_inv[9]				=atoi(row[89]);
	chr->skill_lv_inv[9]			=atoi(row[90]);
	chr->skill_inv[10]			=atoi(row[91]);
	chr->skill_lv_inv[10]		=atoi(row[92]);
	chr->skill_inv[11]			=atoi(row[93]);
	chr->skill_lv_inv[11]		=atoi(row[94]);
	chr->skill_inv[12]			=atoi(row[95]);
	chr->skill_lv_inv[12]		=atoi(row[96]);
	chr->skill_inv[13]			=atoi(row[97]);
	chr->skill_lv_inv[13]		=atoi(row[98]);
	chr->skill_inv[14]			=atoi(row[99]);
	chr->skill_lv_inv[14]		=atoi(row[100]);

	chr->abil=0;
	chr->abil1=0;
	chr->abil2=0;
	for(i=0;i<8;i++){
		if(chr->skill[i]==201){
			chr->abil=1;
		}else	if(chr->skill[i]==202){
			chr->abil1=1;
		}else	if(chr->skill[i]==215){
			chr->abil2=1;
		}else	if(chr->skill[i]==216){
			chr->abil3=1;
		}
	}

	chr->userNo			=	-1;
	chr->moti			=0;
	chr->mode			=0;
	chr->hit_cnt		=0;
	chr->damage=0;

	chr->mv_speed = 0;//���� �����ϼ� �ִ��� ���γ� ���ǵ�...

	if(chr->race==0){//�޸�
		if(chr->sex==0){//����
			if(chr->jobno==0){//����
				chr->moveLevel= 3;
			}else if(chr->jobno==1){//������
				chr->moveLevel= 4;
			}else{//����
				chr->moveLevel= 2;
			}
		}else{//�޸� ����
			if(chr->jobno==0){//������
				chr->moveLevel= 3;
			}else if(chr->jobno==1){//������
				chr->moveLevel= 4;
			}else{//������
				chr->moveLevel= 2;
			}
		}
	}else{//����
		if(chr->sex==0){//����
			if(chr->jobno==0){//��
				chr->moveLevel= 3;
			}else if(chr->jobno==1){//��
				chr->moveLevel= 4;
			}else{//��
				chr->moveLevel= 2;
			}
		}else{//���� ����
			if(chr->jobno==0){//��
				chr->moveLevel= 3;
			}else if(chr->jobno==1){//��
				chr->moveLevel= 4;
			}else{//��
				chr->moveLevel= 2;
			}
		}
	}

	chr->Dx=chr->Cx;
	chr->Dz=chr->Cz;

	chr->Bstr=0;//�߰��ɷ� ��������Ʈ
	chr->Bdex=0;
	chr->Bint=0;
	chr->Bcon=0;

	chr->Bact=0;
	chr->Bap=0;
	chr->Bdp=0;

	chr->Bfire=0;
	chr->Bwater=0;
	chr->Bearth=0;
	chr->Bwind=0;

	chr->summon=NULL;
//��꿡 ���ؼ� ������ �͵�....

//////////////////////////////////
	char_get_Bonus_ability(chr);//���ʽ��� ���ϰ� ���ʽ��� ������ ��Ų��...���..str �������� �߰�ġ����..chr->strength ���� ���� �����Ȱ���.(��ȭ����)
///////////////////////////////////

	chr->hp_m			=	chr->Bcon*5 + chr->level*20+100;
	chr->hp_c			=	chr->hp_m;

	chr->act_m			=	20+chr->level+chr->Bint+chr->classlevel*10;
	chr->act_c			=	chr->act_m;

	if(chr->eq[t_equip_weapon]==0){
		//chr->AP = chr->Bstr + chr->Bint/2;
		chr->AP = chr->Bdex+chr->Bcon/5+chr->level+50;
		chr->AP_m=50;
	}else{
		chr->AP = item_ret_AP(chr->eq[t_equip_weapon],chr->Bstr,chr->Bdex, chr->Bint)/3+chr->level+50;
		chr->AP_m = item_ret_minimumAP(chr->eq[t_equip_weapon],chr->Bstr,chr->Bdex, chr->Bint)/3+chr->level+50;
	}
	a1=item_ret_helmetDP(chr->eq[t_equip_head]);
	a2=item_ret_bodyDP(chr->eq[t_equip_body]);
	a3=item_ret_legDP(chr->eq[t_equip_boots]);
	a4=item_ret_armDP(chr->eq[t_equip_glove]);
	a5=item_ret_avoid(chr->eq[t_equip_shield]);
//printf("�ɸ��ε� helmet:%d, body:%d, leg:%d, arm:%d avoid:%d\n",a1,a2,a3,a4,a5);
	//chr->DP=(chr->Bcon*2 +chr->Bdex)/3 + chr->level +a1+a2+a3+a4;
	chr->DP=chr->Bcon/5 +chr->Bstr/7+chr->Bdex/8 +chr->Bint/10+ chr->level+20;
	chr->DP=chr->DP+(a1+a2*2+a3+a4)*chr->DP/50;

	if(a5==0) chr->AVOID			=	100;
	else chr->AVOID			=	100 / a5;
//mod 0:fire, 1:water, 2:wind, 3:earth
	chr->Efire=itemR_status(chr->eq[t_equip_head],0)+itemR_status(chr->eq[t_equip_body],0)+itemR_status(chr->eq[t_equip_boots],0)+itemR_status(chr->eq[t_equip_glove],0)+itemR_status(chr->eq[t_equip_shield],0);
	chr->Ewater=itemR_status(chr->eq[t_equip_head],1)+itemR_status(chr->eq[t_equip_body],1)+itemR_status(chr->eq[t_equip_boots],1)+itemR_status(chr->eq[t_equip_glove],1)+itemR_status(chr->eq[t_equip_shield],1);
	chr->Eearth=itemR_status(chr->eq[t_equip_head],3)+itemR_status(chr->eq[t_equip_body],3)+itemR_status(chr->eq[t_equip_boots],3)+itemR_status(chr->eq[t_equip_glove],3)+itemR_status(chr->eq[t_equip_shield],3);
	chr->Ewind=itemR_status(chr->eq[t_equip_head],2)+itemR_status(chr->eq[t_equip_body],2)+itemR_status(chr->eq[t_equip_boots],2)+itemR_status(chr->eq[t_equip_glove],2)+itemR_status(chr->eq[t_equip_shield],2);
	chr->Ptid		=1;//in sessiong

///////////////////////////////////////////////////
	char_get_Bonus_stat(chr);//AP������...���⿡�� ��ų�� ���� �����Ƽ�� �ɷ�ġ�� ����ؼ� ������ �ش�.
///////////////////////////////////////////////////

	chr->sk_node.invisi[0]=0;
	chr->sk_node.refl_magic[0]=0;
	chr->sk_node.becum[0]=0;
	chr->sk_node.divin[0]=0;
	chr->sk_node.accel[0]=0;
	chr->sk_node.shadow[0]=0;
	chr->sk_node.aura=0;
	chr->sk_node.aura_own=0;

	chr->sk_node.poison[0]=0;//�ߵ�
	chr->sk_node.stun[0]=0;//����
	chr->sk_node.sleep[0]=0;//��

	chr->pf.m_iCost = 0;
	chr->pf.m_pOpen = chr->pf.m_pClosed =chr->pf.m_pBest = NULL;
	//chr->pf.m_pStack = NULL;
	chr->pf.m_iSNum = chr->pf.m_iDNum =0;

	chr->sql			=conn;

//		####	party system	####
	//		flag -->  0:party off	1:party on		2:party main
	chr->party.flag=0;
	chr->party.no=0;
	chr->party.cnt=0;

	chr->party.x=0;
	chr->party.y=0;
	chr->party.z=0;
	chr->party.infoFcnt=0;

	chr->party.waitfor=NULL;		//��ٸ��� �ִ³� ������ȣ
	chr->party.master=NULL;		//��ٸ��� �ִ³� ������ȣ

	//ison# 				0:NULL 	1:linked		2:myself(member#==NULL)
	chr->party.ison1=0;

	chr->party.member2=NULL;
	chr->party.ison2=0;

	chr->party.member3=NULL;
	chr->party.ison3=0;

	chr->party.member4=NULL;
	chr->party.ison4=0;

	chr->trade.flag=0;

//printf("in db_load_charinfo %d,%d\n",chr->sk_node.invisi[0],chr->sk_node.refl_magic[0]);
//�ǳ��� ���ϱ�......

//printf("db load �ɸ��� mhp:%d, chp:%d ,AP:%d, DP:%d ��ġ:%d,%d, bonus:%d\n",chr->hp_m,atoi(row[12]),chr->AP,chr->DP,chr->Cx,chr->Cz,chr->lvpoint);

	mysql_free_result(result);

	if(chr->hp_c==0) chr->hp_c=chr->hp_m;
	chr->regen_F_cnt	=0;
	chr->attack_F_cnt	=0;
	chr->recov_F_cnt 	=0;
	chr->acp_F_cnt		=0;
	chr->dbflag			=0;
	chr->dbSaveCnt		=0;
	memset(query,0,256);
	sprintf(query,"select * from TB_USERITEM where HERO_NAME='%s' and USERID='%s' order by item_cnt asc",chr->name,userid);

	state = mysql_query(conn, query);
	if( state == -1 ) {
		printf(" db_load_charInfo XX%s\n",mysql_error(conn));
		mysql_free_result(result);
		return 0;
	}
	result = mysql_store_result(conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("mysql fail return value 0 \n");
		mysql_free_result(result);
		return 0;
	}

	state =0;
	while((row = mysql_fetch_row(result))!= NULL){

		for(i=0;i<16;i++){

			tmp = atoi(row[3+i*3]);
			memcpy(&chr->inven[state*16+i],&tmp,2);//index
			tmp = atoi(row[4+i*3]);
			memcpy(&chr->serial[state*16+i],&tmp,4);//index
			chr->inven_cnt[state*16+i]=atoi(row[5+i*3]);//count
//printf("db_chr_info invenidx:%d itemindex:%d se:%d, cnt:%d\n",state*16+i,chr->inven[state*16+i],chr->serial[state*16+i],chr->inven_cnt[state*16+i]);
		}
		state+=1;
		if(state==3) break;
	}

	mysql_free_result(result);

	if(state!=3) return 0;
	return 1;

}





extern short db_char_lvup(void * chrr,void * conns)
{
	int	state;

	char query[256];
	type_character * chr;
	MYSQL *st_conn;

	st_conn = (MYSQL *)conns;
	chr = (type_character *)chrr;
printf("db_char_lvup\n");
	memset(query,0,256);

	if(chr->race==0){//�޸�
		if(chr->sex==0){//����
			if(chr->jobno==0){//����
				sprintf(query,"update TB_HERO set HERO_LEVEL= HERO_LEVEL+1,HERO_STRENGTH=HERO_STRENGTH+2,HERO_DEX=HERO_DEX+1,HERO_CONDI=HERO_CONDI+1,HERO_LVPOINT = HERO_LVPOINT+2,HERO_EXP=%d where HERO_NAME='%s'",chr->exp,chr->name);//�޸�
			}else if(chr->jobno==1){//������
				sprintf(query,"update TB_HERO set HERO_LEVEL= HERO_LEVEL+1,HERO_DEX=HERO_DEX+1,HERO_INTEL=HERO_INTEL+2,HERO_CONDI=HERO_CONDI+1, HERO_LVPOINT = HERO_LVPOINT+2,HERO_EXP=%d where HERO_NAME='%s'",chr->exp,chr->name);//�޸�
			}else{//����
				sprintf(query,"update TB_HERO set HERO_LEVEL= HERO_LEVEL+1, HERO_STRENGTH=HERO_STRENGTH+1,HERO_DEX=HERO_DEX+2,HERO_CONDI=HERO_CONDI+1,HERO_LVPOINT = HERO_LVPOINT+2,HERO_EXP=%d where HERO_NAME='%s'",chr->exp,chr->name);//�޸�
			}
		}else{//�޸� ����
			if(chr->jobno==0){//������
				sprintf(query,"update TB_HERO set HERO_LEVEL= HERO_LEVEL+1,HERO_STRENGTH=HERO_STRENGTH+2,HERO_DEX=HERO_DEX+1,HERO_CONDI=HERO_CONDI+1,HERO_LVPOINT = HERO_LVPOINT+2,HERO_EXP=%d where HERO_NAME='%s'",chr->exp,chr->name);//�޸�
			}else if(chr->jobno==1){//������
				sprintf(query,"update TB_HERO set HERO_LEVEL= HERO_LEVEL+1,HERO_STRENGTH=HERO_STRENGTH+1,HERO_INTEL=HERO_INTEL+2,HERO_CONDI=HERO_CONDI+1, HERO_LVPOINT = HERO_LVPOINT+2,HERO_EXP=%d where HERO_NAME='%s'",chr->exp,chr->name);//�޸�
			}else{//������
				sprintf(query,"update TB_HERO set HERO_LEVEL= HERO_LEVEL+1,HERO_DEX=HERO_DEX+2,HERO_INTEL=HERO_INTEL+1,HERO_CONDI=HERO_CONDI+1,HERO_LVPOINT = HERO_LVPOINT+2,HERO_EXP=%d where HERO_NAME='%s'",chr->exp,chr->name);//�޸�
			}
		}
	}else{//����
		if(chr->sex==0){//����
			if(chr->jobno==0){//��
				sprintf(query,"update TB_HERO set HERO_LEVEL= HERO_LEVEL+1,HERO_STRENGTH=HERO_STRENGTH+2,HERO_DEX=HERO_DEX+1,HERO_LVPOINT = HERO_LVPOINT+1,HERO_EXP=%d where HERO_NAME='%s'",chr->exp,chr->name);//����
			}else if(chr->jobno==1){//��
				sprintf(query,"update TB_HERO set HERO_LEVEL= HERO_LEVEL+1,HERO_INTEL=HERO_INTEL+2,HERO_CONDI=HERO_CONDI+1, HERO_LVPOINT = HERO_LVPOINT+1,HERO_EXP=%d where HERO_NAME='%s'",chr->exp,chr->name);//����
			}else{//��
				sprintf(query,"update TB_HERO set HERO_LEVEL= HERO_LEVEL+1,HERO_STRENGTH=HERO_STRENGTH+2,HERO_INTEL=HERO_INTEL+1, HERO_LVPOINT = HERO_LVPOINT+1,HERO_EXP=%d where HERO_NAME='%s'",chr->exp,chr->name);//����
			}
		}else{//���� ����
			if(chr->jobno==0){//��
				sprintf(query,"update TB_HERO set HERO_LEVEL= HERO_LEVEL+1, HERO_STRENGTH=HERO_STRENGTH+1,HERO_CONDI=HERO_CONDI+2,HERO_LVPOINT = HERO_LVPOINT+1,HERO_EXP=%d where HERO_NAME='%s'",chr->exp,chr->name);//����
			}else if(chr->jobno==1){//��
				sprintf(query,"update TB_HERO set HERO_LEVEL= HERO_LEVEL+1,HERO_DEX=HERO_DEX+2,HERO_CONDI=HERO_CONDI+1, HERO_LVPOINT = HERO_LVPOINT+1,HERO_EXP=%d where HERO_NAME='%s'",chr->exp,chr->name);//����
			}else{//��
				sprintf(query,"update TB_HERO set HERO_LEVEL= HERO_LEVEL+1,HERO_DEX=HERO_DEX+2,HERO_INTEL=HERO_INTEL+1, HERO_LVPOINT = HERO_LVPOINT+1,HERO_EXP=%d where HERO_NAME='%s'",chr->exp,chr->name);//����
			}
		}
	}
	state = mysql_query(st_conn, query);
	if( state == -1 ) {
		printf("db_char_lvupXX%s\n",mysql_error(st_conn));
		return 0;
	}
	return 1;
}

extern short db_lvpoint_use(void * chrr,short dat,void *conns){

	int	state;
	char query[256];
	type_character * chr;
	MYSQL *conn;
	unsigned short point;
	MYSQL_RES *result;
	MYSQL_ROW row;

	conn = (MYSQL *)conns;
	chr = (type_character *)chrr;
printf("db_lvpoint_use\n");

	memset(query,0,256);
	sprintf(query,"select HERO_LVPOINT from TB_HERO where HERO_NAME='%s'",chr->name);

	state = mysql_query(conn, query);
	if( state == -1 ) {
		printf("use lvpoint %s\n",mysql_error(conn));
		return -1;
	}
	result = mysql_store_result(conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("��������Ʈ ���µ� ���� ������ ����..\n");
		mysql_free_result(result);
		return -1;
	}

	row = mysql_fetch_row(result);
	point = atoi(row[0]);

	if(point==0){
		mysql_free_result(result);
		return -1;
	}
	memset(query,0,256);

	point-=1;
	if(chr->race==0){//�޸�
		switch(dat){
			case 0://str
				sprintf(query,"update TB_HERO set HERO_LVPOINT=HERO_LVPOINT-1, HERO_STRENGTH=HERO_STRENGTH+1 where HERO_NAME='%s'",chr->name);
			break;
			case 1://dex
				sprintf(query,"update TB_HERO set HERO_LVPOINT=HERO_LVPOINT-1, HERO_DEX=HERO_DEX+1 where HERO_NAME='%s'",chr->name);
			break;
			case 2://int
				sprintf(query,"update TB_HERO set HERO_LVPOINT=HERO_LVPOINT-1, HERO_INTEL=HERO_INTEL+1 where HERO_NAME='%s'",chr->name);
			break;
			case 3://con
				sprintf(query,"update TB_HERO set HERO_LVPOINT=HERO_LVPOINT-1, HERO_CONDI=HERO_CONDI+1 where HERO_NAME='%s'",chr->name);
			break;
			default:
				mysql_free_result(result);
				return -1;
		}
	}else{
		switch(dat){
			case 4://��strong
				sprintf(query,"update TB_HERO set HERO_LVPOINT=HERO_LVPOINT-1, HERO_STRENGTH=HERO_STRENGTH+2,HERO_DEX=HERO_DEX+1 where HERO_NAME='%s'",chr->name);
			break;
			case 5://��muscle
				sprintf(query,"update TB_HERO set HERO_LVPOINT=HERO_LVPOINT-1, HERO_STRENGTH=HERO_STRENGTH+1,HERO_CONDI=HERO_CONDI+2 where HERO_NAME='%s'",chr->name);
			break;
			case 6://��Application
				sprintf(query,"update TB_HERO set HERO_LVPOINT=HERO_LVPOINT-1, HERO_STRENGTH=HERO_STRENGTH+2,HERO_INTEL=HERO_INTEL+1 where HERO_NAME='%s'",chr->name);
			break;
			case 7://��wisdom
				sprintf(query,"update TB_HERO set HERO_LVPOINT=HERO_LVPOINT-1, HERO_CONDI=HERO_CONDI+1,HERO_INTEL=HERO_INTEL+2 where HERO_NAME='%s'",chr->name);
			break;
			case 8://��endurance
				sprintf(query,"update TB_HERO set HERO_LVPOINT=HERO_LVPOINT-1, HERO_CONDI=HERO_CONDI+1,HERO_DEX=HERO_DEX+2 where HERO_NAME='%s'",chr->name);
			break;
			case 9://��courage
				sprintf(query,"update TB_HERO set HERO_LVPOINT=HERO_LVPOINT-1, HERO_DEX=HERO_DEX+2,HERO_INTEL=HERO_INTEL+1 where HERO_NAME='%s'",chr->name);
			break;
			default:
				mysql_free_result(result);
				return -1;
		}
	}

	state = mysql_query(conn, query);
	if( state == -1 ) {
		printf("db_char_lvupXX%s\n",mysql_error(conn));
		mysql_free_result(result);
		return -1;
	}

	if(chr->race==0){//�޸�
		switch(dat){
			case 0://str
				chr->strength+=1;
			break;
			case 1://dex
				chr->dex+=1;
			break;
			case 2://int
				chr->intel+=1;
			break;
			case 3://con
				chr->cond+=1;
			break;
		}
	}else{
		switch(dat){
			case 4://��strong
				chr->strength+=2;
				chr->dex+=1;
			break;
			case 5://��muscle
				chr->strength+=1;
				chr->cond+=2;
			break;
			case 6://��Application
				chr->strength+=2;
				chr->intel+=1;
			break;
			case 7://��wisdom
				chr->intel+=2;
				chr->cond+=1;
			break;
			case 8://��endurance
				chr->dex+=2;
				chr->cond+=1;
			break;
			case 9://��courage
				chr->dex+=2;
				chr->intel+=1;
			break;
		}
	}

	//���� str���� ���ʽ��� ����Ȱ� ���ϰ� �װ����� AP���� ���Ѵ����� AP���� �ΰ�ġ�� �ش�..
	char_get_Bonus_ability(chr);
	char_lvup_recal(chr);

	chr->lvpoint = point;
	mysql_free_result(result);
	return point;
}

extern void db_item_setnotuse(void * itm,void * conns){

	int  state;
	char query[256];
	int  idxtype;
	MYSQL *st_conn;
	type_itemLst_field * item;

	st_conn = (MYSQL *)conns;
	item = (type_itemLst_field *)itm;
printf("db_item_setnotuse\n");

	if(item->se1!=0&&item->S1!=0){
		idxtype = item->S1/10000;
		memset(query,0,256);//'ITEM_IDX=17336,ITEM_SERIAL=8'
		sprintf(query,"update TB_ITEM_SERIAL set ITEM_USE=0 where ITEM_IDXTYPE=%d and ITEM_IDX=%d and ITEM_SERIAL=%d",idxtype,item->S1,item->se1);
		state = mysql_query(st_conn, query);
		if( state == -1 ) {
			printf("db_item_setnotuse %s\n",mysql_error(st_conn));
			return;
		}
	}
	if(item->se2!=0&&item->S2!=0){
		idxtype = item->S2/10000;
		memset(query,0,256);
		sprintf(query,"update TB_ITEM_SERIAL set ITEM_USE=0 where ITEM_IDXTYPE=%d and ITEM_IDX=%d and ITEM_SERIAL=%d",idxtype,item->S2,item->se2);
		state = mysql_query(st_conn, query);
		if( state == -1 ) {
			printf("db_item_setnotuse %s\n",mysql_error(st_conn));
			return;
		}
	}
	if(item->se3!=0&&item->S3!=0){
		idxtype = item->S3/10000;
		memset(query,0,256);
		sprintf(query,"update TB_ITEM_SERIAL set ITEM_USE=0 where ITEM_IDXTYPE=%d and ITEM_IDX=%d and ITEM_SERIAL=%d",idxtype,item->S3,item->se3);
		state = mysql_query(st_conn, query);
		if( state == -1 ) {
			printf("db_item_setnotuse %s\n",mysql_error(st_conn));
			return;
		}
	}
	if(item->se4!=0&&item->S4!=0){
		idxtype = item->S4/10000;
		memset(query,0,256);
		sprintf(query,"update TB_ITEM_SERIAL set ITEM_USE=0 where ITEM_IDXTYPE=%d and ITEM_IDX=%d and ITEM_SERIAL=%d",idxtype,item->S4,item->se4);
		state = mysql_query(st_conn, query);
		if( state == -1 ) {
			printf("db_item_setnotuse %s\n",mysql_error(st_conn));
			return;
		}
	}
}


extern short db_class_change(void * chrr,int sp,int zule, void * conn,short addcnt, short *addsk,char * invidx,short tg_job,short tg_class)
{//��ų�κ��� ��ų�� �߰����ְ�,���Կ� �������ش�.
	int					state;
	char					query[512];
	type_character *	chr;
	MYSQL 			*	st_conn;

	st_conn = (MYSQL *)conn;
	chr = (type_character *)chrr;

	memset(query,0,512);
	sprintf(query,"update TB_HERO set HERO_CLASSLEVEL=1,HERO_JOB=%d,HERO_CLASS=%d where HERO_NAME='%s'",tg_job,tg_class,chr->name);
	state = mysql_query(st_conn, query);
	if( state == -1 ) {
		printf("db_class_change %s\n",mysql_error(st_conn));
		return -1;
	}
	memset(query,0,512);
	sprintf(query,"replace into TB_HERO_CLASSLOG values('%s','%d','%d','%d','%d');",chr->name,chr->race,chr->sex,tg_job,tg_class);
	state = mysql_query(st_conn, query);
	if( state == -1 ) {
		printf("db_class_lvup insert %s\n",mysql_error(st_conn));
		memset(query,0,512);
		sprintf(query, "rollback");
		state = mysql_query(st_conn, query);
		return -1;
	}
	return 1;
}


extern short db_class_change_demon(void * chrr,int sp,int zule, void * conn,short addcnt, short *addsk,char * invidx,short tg_job,short tg_class)
{//��ų�κ��� ��ų�� �߰����ְ�,���Կ� �������ش�.

	int					cnt,state,i,j,ckflag=-1,qrflag=-1;
	char					query[512],msg_rm[256],msg_add[256];
	char					chktmp[2][2];
	int		tSP,tZULE;
	type_character *	chr;
	MYSQL 			*	st_conn;
	MYSQL_RES *result;
	MYSQL_ROW row;

	st_conn = (MYSQL *)conn;
	chr = (type_character *)chrr;
printf("db_class_change_demon\n");
	memset(query,0,512);
	memset(msg_rm,0,256);
	memset(msg_add,0,256);
	tSP = chr->skilexp-sp;
	tZULE = chr->zule -zule;
	if(tSP<0||tZULE<0) return -1;
//SK_INV0, SK_INV0_LV     >>����

//SK_IDX1, SK_LV1				>�κ�


	switch(tg_job){
		case 0:
			switch(tg_class){
				case 0:
					if((chr->jobno==2&&chr->classno==1)||(chr->jobno==tg_job&&chr->classno>0&&chr->classno<4)) ckflag=1;
				break;
				case 1:
					if((chr->jobno==1&&chr->classno==0)||(chr->jobno==1&&chr->classno==2)||(chr->jobno==0&&chr->classno==3)||(chr->jobno==0&&chr->classno==0)) ckflag=1;
				break;
				case 2:
					if((chr->jobno==2&&chr->classno==1)||(chr->jobno==0&&chr->classno==0)||(chr->jobno==0&&chr->classno==3)||(chr->jobno==0&&chr->classno==4)){qrflag=1;ckflag=1;
						chktmp[0][0]=2;chktmp[0][1]=1;chktmp[1][0]=0;chktmp[1][1]=0;//�ʱ⿡ ���� �Ѱ�.
					}
				break;
				case 3:
					if((chr->jobno==0&&chr->classno==0)||(chr->jobno==0&&chr->classno==2)||(chr->jobno==0&&chr->classno==4)||(chr->jobno==0&&chr->classno==1)){qrflag=1;ckflag=1;
						chktmp[0][0]=0;chktmp[0][1]=1;chktmp[1][0]=0;chktmp[1][1]=0;
					}
				break;
				case 4:
					if((chr->jobno==0&&chr->classno==2)||(chr->jobno==0&&chr->classno==3)){qrflag=1;ckflag=1;
						chktmp[0][0]=0;chktmp[0][1]=2;chktmp[1][0]=0;chktmp[1][1]=3;
					}
				break;
			}
		break;
		case 1:
			switch(tg_class){
				case 0:
					if((chr->jobno==0&&chr->classno==1)||(chr->jobno==tg_job&&chr->classno>0&&chr->classno<4)) ckflag=1;
				break;
				case 1:
					if((chr->jobno==1&&chr->classno==0)||(chr->jobno==1&&chr->classno==3)||(chr->jobno==2&&chr->classno==2)||(chr->jobno==2&&chr->classno==0)) ckflag=1;
				break;
				case 2:
					if((chr->jobno==0&&chr->classno==1)||(chr->jobno==1&&chr->classno==0)||(chr->jobno==1&&chr->classno==3)||(chr->jobno==1&&chr->classno==4)){qrflag=1;ckflag=1;
						chktmp[0][0]=0;chktmp[0][1]=1;chktmp[1][0]=1;chktmp[1][1]=0;
					}
				break;
				case 3:
					if((chr->jobno==1&&chr->classno==0)||(chr->jobno==1&&chr->classno==2)||(chr->jobno==1&&chr->classno==4)||(chr->jobno==1&&chr->classno==1)){qrflag=1;ckflag=1;
						chktmp[0][0]=1;chktmp[0][1]=0;chktmp[1][0]=1;chktmp[1][1]=1;
					}
				break;
				case 4:
					if((chr->jobno==1&&chr->classno==2)||(chr->jobno==1&&chr->classno==3)){qrflag=1;ckflag=1;
						chktmp[0][0]=1;chktmp[0][1]=3;chktmp[1][0]=1;chktmp[1][1]=2;
					}
				break;
			}
		break;
		case 2:
			switch(tg_class){
				case 0:
					if((chr->jobno==1&&chr->classno==1)||(chr->jobno==tg_job&&chr->classno>0&&chr->classno<4)) ckflag=1;
				break;
				case 1:
					if((chr->jobno==2&&chr->classno==0)||(chr->jobno==2&&chr->classno==3)||(chr->jobno==0&&chr->classno==2)||(chr->jobno==0&&chr->classno==0)) ckflag=1;
				break;
				case 2:
					if((chr->jobno==1&&chr->classno==1)||(chr->jobno==2&&chr->classno==0)||(chr->jobno==2&&chr->classno==3)||(chr->jobno==2&&chr->classno==4)){qrflag=1;ckflag=1;
						chktmp[0][0]=2;chktmp[0][1]=0;chktmp[1][0]=1;chktmp[1][1]=1;
					}
				break;
				case 3:
					if((chr->jobno==2&&chr->classno==0)||(chr->jobno==2&&chr->classno==2)||(chr->jobno==2&&chr->classno==4)||(chr->jobno==2&&chr->classno==1)){qrflag=1;ckflag=1;
						chktmp[0][0]=2;chktmp[0][1]=1;chktmp[1][0]=2;chktmp[1][1]=0;
					}
				break;
				case 4:
					if((chr->jobno==2&&chr->classno==2)||(chr->jobno==2&&chr->classno==3)){qrflag=1;ckflag=1;
						chktmp[0][0]=2;chktmp[0][1]=3;chktmp[1][0]=2;chktmp[1][1]=2;
					}
				break;
			}
		break;
	}
//printf("�������� ������:%d, ����Ŭ����:%d Ÿ����:%d, Ÿ��Ŭ����:%d\n",chr->classno,chr->jobno,tg_job,tg_class);
//ckflag=-1,qrflag=-1
//ck�� �ùٸ� ��������..
//qr�� ������ �˾ƺ��� �ϴ���...
	if(ckflag==-1){
//printf("�����߿� �ڽ��� Ŭ���������� ������ Ŭ������ ������ �Ұ����ϴ�.\n");
		return -1;
	}

	if(qrflag==1){//������ �������� �ȴ�..

		sprintf(query,"select count(*) from TB_HERO_CLASSLOG where HERO_NAME='%s' and ((HERO_JOB=%d and HERO_CLASS=%d) or(HERO_JOB=%d and HERO_CLASS=%d))",chr->name,chktmp[0][0],chktmp[0][1],chktmp[1][0],chktmp[1][1]);
		state = mysql_query(st_conn, query);
		if( state == -1 ) {
			printf("db_class_lvup %s\n",mysql_error(st_conn));
			return -1;
		}
//printf("%s\n",query);
		result = mysql_store_result(st_conn);
		state = mysql_num_rows(result);
		if( state == 0 ) {
			printf("err in select count\n");
			mysql_free_result(result);
			return -1;
		}

		row = mysql_fetch_row(result);
		cnt = atoi(row[0]);
		mysql_free_result(result);

		if(cnt!=2){
			printf("�����ߴ� �αװ� ����.\n");
			return -1;
		}
	}

	memset(query,0,512);
	sprintf(query,"update TB_HERO set HERO_CLASSLEVEL=1,HERO_SKILEXP=%d,HERO_ZULE=%d,HERO_JOB=%d,HERO_CLASS=%d where HERO_NAME='%s'",tSP,tZULE,tg_job,tg_class,chr->name);
	state = mysql_query(st_conn, query);
	if( state == -1 ) {
		printf("db_class_lvup %s\n",mysql_error(st_conn));
		return -1;
	}
	memset(query,0,512);
	sprintf(query,"replace into TB_HERO_CLASSLOG values('%s','%d','%d','%d','%d');",chr->name,chr->race,chr->sex,tg_job,tg_class);
	state = mysql_query(st_conn, query);
	if( state == -1 ) {
		printf("db_class_lvup insert %s\n",mysql_error(st_conn));
		memset(query,0,512);
		sprintf(query, "rollback");
		state = mysql_query(st_conn, query);
		return -1;
	}

	pthread_mutex_lock(&synclock);

	for(i=0;i<addcnt;i++){
		j=invidx[i];
		chr->skill_inv[j]=addsk[i];
		if(addsk[i]==0) chr->skill_lv_inv[j]=0;
		else chr->skill_lv_inv[j]=1;
	}
	chr->jobno=tg_job;
	chr->classno=tg_class;
	chr->skilexp=tSP;
	chr->zule=tZULE;
	chr->classlevel=1;
	char_get_Bonus_ability(chr);
	char_lvup_recal(chr);
	pthread_mutex_unlock(&synclock);
	return 1;
}


extern void db_jobhistory(void * chrr,char * dat,void * con)//���������丮
{
	int	state,cnt=0,len=1;
	MYSQL	*	conn;
	MYSQL_RES *result;
	MYSQL_ROW row;
	type_character * chr;
	char query[256];

	chr = (type_character *)chrr;
	conn =(MYSQL *)con;
printf("db_jobhistory\n");

	memset(query,0,256);
	sprintf(query,"select HERO_JOB,HERO_CLASS from TB_HERO_CLASSLOG where HERO_NAME='%s'",chr->name);

	state = mysql_query(conn, query);
	if( state == -1 ) {
		printf("db_jobhistory%s\n",mysql_error(conn));
		return ;
	}
	result = mysql_store_result(conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("db jobhistory\n");
		mysql_free_result(result);
		return ;
	}

	while((row = mysql_fetch_row(result))!= NULL){
		cnt++;
		dat[len]=atoi(row[0]);
		len+=1;
		dat[len]=atoi(row[1]);
		len+=1;
	}
	mysql_free_result(result);
	dat[0]=cnt;
}



extern short db_save_all(void * chrr,char * userid,void * conns)
{
	int	state;

	char query[1024];
	type_character * chr;
	MYSQL *st_conn;

	st_conn = (MYSQL *)conns;
	chr = (type_character *)chrr;

	memset(query,0,1024);
	sprintf(query,"update TB_HERO set HERO_EXP='%d',HERO_LEVEL='%d',HERO_CLASSLEVEL=%d,HERO_SKILEXP='%d',HERO_LOC_WORLD='%d',HERO_LOCX='%d',HERO_LOCZ='%d',HERO_EQ0=%d,HERO_EQ0_S=%d,HERO_EQ1=%d,HERO_EQ1_S=%d,HERO_EQ2=%d,HERO_EQ2_S=%d,HERO_EQ3=%d,HERO_EQ3_S=%d,HERO_EQ4=%d,HERO_EQ4_S=%d,HERO_EQ5=%d,HERO_EQ5_S=%d,HERO_EQ6=%d,HERO_EQ6_S=%d,HERO_EQ7=%d,HERO_EQ7_S=%d,HERO_EQ8=%d,HERO_EQ8_S=%d,HERO_EQ9=%d,HERO_EQ9_S=%d,HERO_EQ10=%d,HERO_EQ10_S=%d,HERO_EQ11=%d,HERO_EQ11_S=%d,HERO_ZULE='%d',HERO_COIN='%d' where HERO_NAME='%s' and userid='%s'",
	chr->exp,chr->level,chr->classlevel,chr->skilexp,chr->worldmap,chr->Cx,chr->Cz,chr->eq[t_equip_head],chr->eq_s[t_equip_head],chr->eq[t_equip_body],chr->eq_s[t_equip_body],chr->eq[t_equip_weapon],chr->eq_s[t_equip_weapon],chr->eq[t_equip_shield],chr->eq_s[t_equip_shield],chr->eq[t_equip_glove],chr->eq_s[t_equip_glove],chr->eq[t_equip_boots],chr->eq_s[t_equip_boots],chr->eq[t_equip_armlet1],chr->eq_s[t_equip_armlet1],chr->eq[t_equip_armlet2],chr->eq_s[t_equip_armlet2],chr->eq[t_equip_ring1],chr->eq_s[t_equip_ring1],chr->eq[t_equip_ring2],chr->eq_s[t_equip_ring2],chr->eq[t_equip_ring3],chr->eq_s[t_equip_ring3],chr->eq[t_equip_ring4],chr->eq_s[t_equip_ring4],chr->zule,chr->coin,chr->name,userid);

	state = mysql_query(st_conn, query);
	if( state == -1 ) {
		printf("db_char_SAVE ALL1%s\n",mysql_error(st_conn));
		return 0;
	}
printf("save query:%s\n",query);

	memset(query,0,1024);
	sprintf(query,"update TB_SKILL set SK_INV0=%d ,SK_INV0_LV=%d,SK_INV1=%d ,SK_INV1_LV=%d,SK_INV2=%d ,SK_INV2_LV=%d,SK_INV3=%d ,SK_INV3_LV=%d,SK_INV4=%d ,SK_INV4_LV=%d,SK_INV5=%d ,SK_INV5_LV=%d,SK_INV6=%d ,SK_INV6_LV=%d,SK_INV7=%d ,SK_INV7_LV=%d,SK_GSKILL0=%d,SK_GSKILL1=%d,SK_IDX0=%d,SK_LV0=%d,SK_IDX1=%d,SK_LV1=%d,SK_IDX2=%d,SK_LV2=%d,SK_IDX3=%d,SK_LV3=%d,SK_IDX4=%d,SK_LV4=%d,SK_IDX5=%d,SK_LV5=%d,SK_IDX6=%d,SK_LV6=%d,SK_IDX7=%d,SK_LV7=%d,SK_IDX8=%d,SK_LV8=%d,SK_IDX9=%d,SK_LV9=%d,SK_IDX10=%d,SK_LV10=%d,SK_IDX11=%d,SK_LV11=%d,SK_IDX12=%d,SK_LV12=%d,SK_IDX13=%d,SK_LV13=%d,SK_IDX14=%d,SK_LV14=%d where HERO_NAME='%s' and USERID='%s'",
		chr->skill[0],chr->skill_lv[0],chr->skill[1],chr->skill_lv[1],chr->skill[2],chr->skill_lv[2],chr->skill[3],chr->skill_lv[3],chr->skill[4],chr->skill_lv[4],chr->skill[5],chr->skill_lv[5],chr->skill[6],chr->skill_lv[6],chr->skill[7],chr->skill_lv[7],chr->gskill1,chr->gskill2,chr->skill_inv[0],chr->skill_lv_inv[0],chr->skill_inv[1],chr->skill_lv_inv[1],chr->skill_inv[2],chr->skill_lv_inv[2],chr->skill_inv[3],chr->skill_lv_inv[3],chr->skill_inv[4],chr->skill_lv_inv[4],chr->skill_inv[5],chr->skill_lv_inv[5],chr->skill_inv[6],chr->skill_lv_inv[6],chr->skill_inv[7],chr->skill_lv_inv[7],chr->skill_inv[8],chr->skill_lv_inv[8],chr->skill_inv[9],chr->skill_lv_inv[9],chr->skill_inv[10],chr->skill_lv_inv[10],chr->skill_inv[11],chr->skill_lv_inv[11],chr->skill_inv[12],chr->skill_lv_inv[12],chr->skill_inv[13],chr->skill_lv_inv[13],chr->skill_inv[14],chr->skill_lv_inv[14],chr->name,userid);

	state = mysql_query(st_conn, query);
	if( state == -1 ) {
		printf("db_char_SAVE ALL2%s\n",mysql_error(st_conn));
		return 0;
	}
printf("save query:%s\n",query);

	memset(query,0,1024);
	sprintf(query,"update TB_USERITEM set ITEM_IDX_0=%d,ITEM_SERIAL_0=%d,ITEM_QUANTITY_0=%d,ITEM_IDX_1=%d,ITEM_SERIAL_1=%d,ITEM_QUANTITY_1=%d,ITEM_IDX_2=%d,ITEM_SERIAL_2=%d,ITEM_QUANTITY_2=%d,ITEM_IDX_3=%d,ITEM_SERIAL_3=%d,ITEM_QUANTITY_3=%d,ITEM_IDX_4=%d,ITEM_SERIAL_4=%d,ITEM_QUANTITY_4=%d,ITEM_IDX_5=%d,ITEM_SERIAL_5=%d,ITEM_QUANTITY_5=%d,ITEM_IDX_6=%d,ITEM_SERIAL_6=%d,ITEM_QUANTITY_6=%d,ITEM_IDX_7=%d,ITEM_SERIAL_7=%d,ITEM_QUANTITY_7=%d,ITEM_IDX_8=%d,ITEM_SERIAL_8=%d,ITEM_QUANTITY_8=%d,ITEM_IDX_9=%d,ITEM_SERIAL_9=%d,ITEM_QUANTITY_9=%d,ITEM_IDX_10=%d,ITEM_SERIAL_10=%d,ITEM_QUANTITY_10=%d,ITEM_IDX_11=%d,ITEM_SERIAL_11=%d,ITEM_QUANTITY_11=%d,ITEM_IDX_12=%d,ITEM_SERIAL_12=%d,ITEM_QUANTITY_12=%d,ITEM_IDX_13=%d,ITEM_SERIAL_13=%d,ITEM_QUANTITY_13=%d,ITEM_IDX_14=%d,ITEM_SERIAL_14=%d,ITEM_QUANTITY_14=%d,ITEM_IDX_15=%d,ITEM_SERIAL_15=%d,ITEM_QUANTITY_15=%d where ITEM_CNT=0 and HERO_NAME='%s' and userid='%s'",
		chr->inven[0],chr->serial[0],chr->inven_cnt[0],chr->inven[1],chr->serial[1],chr->inven_cnt[1],chr->inven[2],chr->serial[2],chr->inven_cnt[2],chr->inven[3],chr->serial[3],chr->inven_cnt[3],chr->inven[4],chr->serial[4],chr->inven_cnt[4],chr->inven[5],chr->serial[5],chr->inven_cnt[5],chr->inven[6],chr->serial[6],chr->inven_cnt[6],chr->inven[7],chr->serial[7],chr->inven_cnt[7],chr->inven[8],chr->serial[8],chr->inven_cnt[8],chr->inven[9],chr->serial[9],chr->inven_cnt[9],chr->inven[10],chr->serial[10],chr->inven_cnt[10],chr->inven[11],chr->serial[11],chr->inven_cnt[11],chr->inven[12],chr->serial[12],chr->inven_cnt[12],chr->inven[13],chr->serial[13],chr->inven_cnt[13],chr->inven[14],chr->serial[14],chr->inven_cnt[14],chr->inven[15],chr->serial[15],chr->inven_cnt[15],chr->name,userid);
	state = mysql_query(st_conn, query);
	if( state == -1 ) {
		printf("db_item_use %s\n",mysql_error(st_conn));
		return -1;
	}
printf("save query:%s\n",query);
	memset(query,0,1024);
	sprintf(query,"update TB_USERITEM set ITEM_IDX_0=%d,ITEM_SERIAL_0=%d,ITEM_QUANTITY_0=%d,ITEM_IDX_1=%d,ITEM_SERIAL_1=%d,ITEM_QUANTITY_1=%d,ITEM_IDX_2=%d,ITEM_SERIAL_2=%d,ITEM_QUANTITY_2=%d,ITEM_IDX_3=%d,ITEM_SERIAL_3=%d,ITEM_QUANTITY_3=%d,ITEM_IDX_4=%d,ITEM_SERIAL_4=%d,ITEM_QUANTITY_4=%d,ITEM_IDX_5=%d,ITEM_SERIAL_5=%d,ITEM_QUANTITY_5=%d,ITEM_IDX_6=%d,ITEM_SERIAL_6=%d,ITEM_QUANTITY_6=%d,ITEM_IDX_7=%d,ITEM_SERIAL_7=%d,ITEM_QUANTITY_7=%d,ITEM_IDX_8=%d,ITEM_SERIAL_8=%d,ITEM_QUANTITY_8=%d,ITEM_IDX_9=%d,ITEM_SERIAL_9=%d,ITEM_QUANTITY_9=%d,ITEM_IDX_10=%d,ITEM_SERIAL_10=%d,ITEM_QUANTITY_10=%d,ITEM_IDX_11=%d,ITEM_SERIAL_11=%d,ITEM_QUANTITY_11=%d,ITEM_IDX_12=%d,ITEM_SERIAL_12=%d,ITEM_QUANTITY_12=%d,ITEM_IDX_13=%d,ITEM_SERIAL_13=%d,ITEM_QUANTITY_13=%d,ITEM_IDX_14=%d,ITEM_SERIAL_14=%d,ITEM_QUANTITY_14=%d,ITEM_IDX_15=%d,ITEM_SERIAL_15=%d,ITEM_QUANTITY_15=%d where ITEM_CNT=1 and HERO_NAME='%s' and userid='%s'",
		chr->inven[16],chr->serial[16],chr->inven_cnt[16],chr->inven[17],chr->serial[17],chr->inven_cnt[17],chr->inven[18],chr->serial[18],chr->inven_cnt[18],chr->inven[19],chr->serial[19],chr->inven_cnt[19],chr->inven[20],chr->serial[20],chr->inven_cnt[20],chr->inven[21],chr->serial[21],chr->inven_cnt[21],chr->inven[22],chr->serial[22],chr->inven_cnt[22],chr->inven[23],chr->serial[23],chr->inven_cnt[23],chr->inven[24],chr->serial[24],chr->inven_cnt[24],chr->inven[25],chr->serial[25],chr->inven_cnt[25],chr->inven[26],chr->serial[26],chr->inven_cnt[26],chr->inven[27],chr->serial[27],chr->inven_cnt[27],chr->inven[28],chr->serial[28],chr->inven_cnt[28],chr->inven[29],chr->serial[29],chr->inven_cnt[29],chr->inven[30],chr->serial[30],chr->inven_cnt[30],chr->inven[31],chr->serial[31],chr->inven_cnt[31],chr->name,userid);
	state = mysql_query(st_conn, query);
	if( state == -1 ) {
		printf("db_item_use %s\n",mysql_error(st_conn));
		return -1;
	}
printf("save query:%s\n",query);
	memset(query,0,1024);
	sprintf(query,"update TB_USERITEM set ITEM_IDX_0=%d,ITEM_SERIAL_0=%d,ITEM_QUANTITY_0=%d,ITEM_IDX_1=%d,ITEM_SERIAL_1=%d,ITEM_QUANTITY_1=%d,ITEM_IDX_2=%d,ITEM_SERIAL_2=%d,ITEM_QUANTITY_2=%d,ITEM_IDX_3=%d,ITEM_SERIAL_3=%d,ITEM_QUANTITY_3=%d,ITEM_IDX_4=%d,ITEM_SERIAL_4=%d,ITEM_QUANTITY_4=%d,ITEM_IDX_5=%d,ITEM_SERIAL_5=%d,ITEM_QUANTITY_5=%d,ITEM_IDX_6=%d,ITEM_SERIAL_6=%d,ITEM_QUANTITY_6=%d,ITEM_IDX_7=%d,ITEM_SERIAL_7=%d,ITEM_QUANTITY_7=%d,ITEM_IDX_8=%d,ITEM_SERIAL_8=%d,ITEM_QUANTITY_8=%d,ITEM_IDX_9=%d,ITEM_SERIAL_9=%d,ITEM_QUANTITY_9=%d,ITEM_IDX_10=%d,ITEM_SERIAL_10=%d,ITEM_QUANTITY_10=%d,ITEM_IDX_11=%d,ITEM_SERIAL_11=%d,ITEM_QUANTITY_11=%d,ITEM_IDX_12=%d,ITEM_SERIAL_12=%d,ITEM_QUANTITY_12=%d,ITEM_IDX_13=%d,ITEM_SERIAL_13=%d,ITEM_QUANTITY_13=%d,ITEM_IDX_14=%d,ITEM_SERIAL_14=%d,ITEM_QUANTITY_14=%d,ITEM_IDX_15=%d,ITEM_SERIAL_15=%d,ITEM_QUANTITY_15=%d where ITEM_CNT=2 and HERO_NAME='%s' and userid='%s'",
		chr->inven[32],chr->serial[32],chr->inven_cnt[32],chr->inven[33],chr->serial[33],chr->inven_cnt[33],chr->inven[34],chr->serial[34],chr->inven_cnt[34],chr->inven[35],chr->serial[35],chr->inven_cnt[35],chr->inven[36],chr->serial[36],chr->inven_cnt[36],chr->inven[37],chr->serial[37],chr->inven_cnt[37],chr->inven[38],chr->serial[38],chr->inven_cnt[38],chr->inven[39],chr->serial[39],chr->inven_cnt[39],chr->inven[40],chr->serial[40],chr->inven_cnt[40],chr->inven[41],chr->serial[41],chr->inven_cnt[41],chr->inven[42],chr->serial[42],chr->inven_cnt[42],chr->inven[43],chr->serial[43],chr->inven_cnt[43],chr->inven[44],chr->serial[44],chr->inven_cnt[44],chr->inven[45],chr->serial[45],chr->inven_cnt[45],chr->inven[46],chr->serial[46],chr->inven_cnt[46],chr->inven[47],chr->serial[47],chr->inven_cnt[47],chr->name,userid);
	state = mysql_query(st_conn, query);
	if( state == -1 ) {
		printf("db_item_use %s\n",mysql_error(st_conn));
		return -1;
	}
printf("save query:%s\n",query);
	return 1;
}
*/
