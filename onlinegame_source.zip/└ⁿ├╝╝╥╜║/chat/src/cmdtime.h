#include <time.h>
#include <sys/time.h>
/*struct timeval {
long    tv_sec;
long    tv_usec;
};
*/
#define TYPE_CMDSEC_DEFINED
typedef struct timeval type_cmdsec;
extern void get_cmd_time(type_cmdsec * cmdsec);
extern void set_cmd_time(type_cmdsec * cmdsec);
extern void set_sec_only_time(type_cmdsec * cmdsec);
