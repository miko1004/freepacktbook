#ifndef PUBLIC_INCLUDED
#include "publicInc.h"
#endif

extern int conf_load(char const * filename);

extern char const * predef_logfile(void);
extern char const * predef_adfile(void);
extern char const * predef_adlink(void);
extern unsigned int predef_udpport(void);
extern unsigned int predef_gameport(void);
extern  char const * predef_version(void);
