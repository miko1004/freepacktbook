#include <time.h>
#include <mysql.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#define THR_ACT_INTERNAL_ACC
#include "svr.h"
#include "objlist.h"
#include "thr_act.h"
#include "map.h"
#include "db.h"

void * Thread_sync(void *arg){//syncronizer thread for user's character

	struct timeval start,stop;
	long	tmp,utmp;
	short regenTime,Half_sec;
	int i,maxNo;

	sleep(1);

	regenTime = _ONE_SEC*30;
	Half_sec = _ONE_SEC/2;
	for(;;){
		gettimeofday(&start,NULL);
		pthread_mutex_lock(&synclock);
		maxNo = svr_ret_tot();
		for(i=0;i<maxNo;i++)
		{

		}
		pthread_cond_signal(&synccond);
		pthread_mutex_unlock(&synclock);

		gettimeofday(&stop,NULL);
		tmp = stop.tv_sec - start.tv_sec;
		utmp = stop.tv_usec - start.tv_usec;

		if(tmp>1){//1frame 0.033�� 33000/

		}else if(tmp==1){
			utmp = 1000000 + utmp;//�ɸ��ð�
			if(utmp<AFRAME){
				stop.tv_sec=0;
				stop.tv_usec=AFRAME-utmp;
				select(0, NULL, NULL, NULL, &stop);
			}
		}else{
			if(utmp<AFRAME){
				stop.tv_sec=0;
				stop.tv_usec=AFRAME-utmp;
				select(0, NULL, NULL, NULL, &stop);
			}
		}
	}//for loop end
}

extern int thr_beforeAuth(char * dat, type_session * c,void * conn,int udpsock){//dat�� ���̿� 			packet, c,

	int pLen=2,headercd,clen,idx,ulen;
	short res,cnt=1;
	char name[32],pass[32];
	char mesg[MAX_PACKET_SIZE];
	unsigned short	nEnd = PEND;

	memcpy(&res,&dat[0],2);//���� packet �� ����
	res-=2;
	headercd = dat[pLen];
	if(c->userStat==0){//�κ������ ��Ŷó��
		switch(headercd){

			case PK_USER_AUTH:
				idx=3;
				ulen=dat[idx];//name len
				idx+=1;
				if(res<ulen+idx||ulen>31) return 0;//error
				memcpy(&name[0],&dat[idx],ulen);
				name[ulen]='\0';
				idx+=ulen;
				clen=dat[idx];//pass len
				idx+=1;
				if(res<clen+idx||clen>31) return 0;//error
				memcpy(&pass[0],&dat[idx],clen);
				pass[clen]='\0';
				res = db_user_auth(name, pass,clen,conn);res=1;
				printf("�������� ��� :%d %s \n",res,name);
			res=1;
				if(res==1){
					pthread_mutex_lock(&synclock);
					session_set_userid(c,name,ulen);
					mapinit(c);
					c->state=conn_state_authed;
					pthread_mutex_unlock(&synclock);
					//map_sec_test();//test
					mesg[pLen]=PK_USER_AUTH;
					pLen+=1;
					mesg[pLen]=svr_ret_tot();
					pLen+=1;
					mesg[pLen]=c->uLen;
					pLen+=1;
					memcpy(&mesg[pLen],&c->userid[0],c->uLen);
					pLen+=c->uLen;
					memcpy(&mesg[pLen],&c->userNo,2);
					pLen+=2;
					memcpy(&mesg[pLen],&nEnd,2);
					pLen+=2;
					memcpy(&mesg[0],&pLen,2);
					map_pData_snd(c,mesg,pLen);
					map_get_sectorinfo_All(c);
					pLen=2;
					mesg[pLen]=PK_USER_INFO;
					pLen+=1;
					memcpy(&mesg[pLen],&cnt,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->userNo,2);
					pLen+=2;
					mesg[pLen] = c->uLen;
					pLen+=1;
					memcpy(&mesg[pLen],&c->userid[0],c->uLen);
					pLen+=c->uLen;
					mesg[pLen] = c->Ax;
					pLen+=1;
					mesg[pLen] = c->Az;
					pLen+=1;
					memcpy(&mesg[pLen],&nEnd,2);
					pLen+=2;
					memcpy(&mesg[0],&pLen,2);
					map_usersend_All(c->Ax,c->Az,mesg,pLen,NULL);
				}else{
					return 0;
				}

			break;
		}
	}
	return 1;
}


extern int main_act(char * dat,short pLen, type_session * c, void * conn,int udpsock){//dat�� ���̿� 			packet, c,

	int rLen=2,res;
	char mesg[MAX_PACKET_SIZE];
	unsigned short	nEnd = PEND;
	unsigned short Ax,Az,headercd;
	short tx,tz,cLen;

	//if(dat[2]<0) headercd=dat[2]+256;
	headercd=dat[2];
	switch(headercd){
		case PK_USER_CHAT:
			memcpy(&cLen,&dat[3],2);
			if(cLen>pLen-4) return 0;

			mesg[rLen]=PK_USER_CHAT;
			rLen+=1;
			mesg[rLen]=c->uLen;
			rLen+=1;
			memcpy(&mesg[rLen],&c->userid[0],c->uLen);
			rLen+=c->uLen;
			memcpy(&mesg[rLen],&cLen,2);
			rLen+=2;
			memcpy(&mesg[rLen],&dat[5],cLen);
			rLen+=cLen;
			memcpy(&mesg[rLen],&nEnd,2);
			rLen+=2;
			memcpy(&mesg[0],&rLen,2);
			map_usersend_All(c->Ax,c->Az,mesg,rLen,NULL);
			printf("PK_USER_CHAT:ok\n");
		break;
		case PK_REQ_LOC:
			mesg[rLen]=PK_REQ_LOC;
			rLen+=1;
			mesg[rLen]=c->Ax;
			rLen+=1;
			mesg[rLen]=c->Az;
			rLen+=1;
			memcpy(&mesg[rLen],&nEnd,2);
			rLen+=2;
			memcpy(&mesg[0],&rLen,2);
			map_pData_snd(c,mesg,rLen);
			printf("PK_REQ_LOC:ok\n");
		break;
		case PK_CMD_MV:
			Ax=dat[3];
			Az=dat[4];
			if(Ax>=S_WIDTH||Az>=S_WIDTH) return 0;
			tx = c->Ax - Ax;
			tz = c->Az - Az;
			if(tx>1||tx<-1||tz>1||tz<-1||(c->Ax==Ax&&c->Az==Az)) res=0;
			else res=1;
			printf("before:%d,%d after:%d,%d res:%d\n",c->Ax,c->Az,Ax,Az,res);

			if(res==1){
				printf("PK_CMD_MV:TRUE\n");
				mesg[rLen] = PK_USER_MV;//2
				rLen+=1;
				mesg[rLen] = RET_TRUE;//3
				rLen+=1;
				memcpy(&mesg[rLen],&c->userNo,2);//8
				rLen+=2;
				mesg[rLen] = c->uLen;
				rLen+=1;
				memcpy(&mesg[rLen],&c->userid[0],c->uLen);//8
				rLen+=c->uLen;
				mesg[rLen] = Ax;
				rLen+=1;
				mesg[rLen] = Az;
				rLen+=1;
				mesg[rLen] = c->Ax;
				rLen+=1;
				mesg[rLen] = c->Az;
				rLen+=1;
				memcpy(&mesg[rLen],&nEnd,2);
				rLen+=2;
				memcpy(&mesg[0],&rLen,2);
				map_usersend_All(c->Ax,c->Az,mesg,rLen,NULL);

				map_char_one_mv(c,Ax,Az);

				c->Bx=c->Ax;
				c->Bz=c->Az;
			}else{
				mesg[rLen] = PK_USER_MV;//2
				rLen+=1;
				mesg[rLen] = RET_FALSE;//3
				rLen+=1;
				memcpy(&mesg[rLen],&c->userNo,2);//8
				rLen+=2;
				mesg[rLen] = c->uLen;
				rLen+=1;
				memcpy(&mesg[rLen],&c->userid[0],c->uLen);//8
				rLen+=c->uLen;
				mesg[rLen] = c->Ax;
				rLen+=1;
				mesg[rLen] = c->Az;
				rLen+=1;
				mesg[rLen] = Ax;
				rLen+=1;
				mesg[rLen] = Az;
				rLen+=1;
				memcpy(&mesg[rLen],&nEnd,2);
				rLen+=2;
				memcpy(&mesg[0],&rLen,2);
				map_usersend_All(c->Ax,c->Az,mesg,rLen,NULL);
			}

		break;

		default:
			return 0;
	}
	return 1;
}


extern int game_act(char * dat,short pLen, type_session * c, void * conn,int udpsock){//dat�� ���̿� 			packet, c,

	int headercd;

	if(dat[2]<0) headercd=dat[2]+256;
	else headercd=dat[2];
	switch(headercd){

		case 0:

		break;

		case 1:

		break;

		case 2:
		break;

		default:
			return 0;
	}
	return 1;
}
