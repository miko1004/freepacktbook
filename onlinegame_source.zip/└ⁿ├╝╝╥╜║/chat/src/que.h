#ifdef QUE_INTERNAL_ACCESS 
#include "packet.h"
#ifndef PUBLIC_INCLUDED
#include "publicInc.h"
#endif
#endif

#ifdef NEED_QUE_INTERNAL_ACCESS
#include "packet.h"
#endif

typedef struct queues
#ifdef QUE_INTERNAL_ACCESS
{
	type_packet  * packet;
	struct queues * next;
}
#endif
#ifdef NEED_QUE_INTERNAL_ACCESS
{
	type_packet  * packet;
	struct queues * next;
}
#endif
type_queue;

extern type_packet * queue_pull_packet(type_queue * * queue);
//extern type_packet * queue_peek_packet(type_queue const * const * queue);
extern void queue_push_packet(type_queue * * queue, type_packet * packet);
extern int queue_get_length(type_queue const * const * queue);
//extern void setQueue(type_queue * * queue);
extern void queue_push_packet_raw(type_queue * * queue, type_packet * packet);
