#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "cmdtime.h"

extern void get_cmd_time(type_cmdsec * cmdsec){

	gettimeofday(cmdsec,NULL);
	cmdsec->tv_usec = cmdsec->tv_usec / 10000;
}

extern void set_cmd_time(type_cmdsec * cmdsec){

	gettimeofday(cmdsec,NULL);
	cmdsec->tv_usec = cmdsec->tv_usec / 10000;
}

extern void set_sec_only_time(type_cmdsec * cmdsec){

	gettimeofday(cmdsec,NULL);
}
/*set_cmd_time(&(chr->cmd_sec));
printf("time %ld\n",chr->cmd_sec.tv_usec);*/
