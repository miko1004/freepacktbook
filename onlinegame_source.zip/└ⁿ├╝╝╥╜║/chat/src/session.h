#ifndef TYPE_CMDSEC_DEFINED
#include "cmdtime.h"
#endif

#ifdef SESSION_INTERNAL_ACCESS
#define NEED_QUE_INTERNAL_ACCESS
#include "que.h"
#endif

#ifdef NEED_SESSION_INTERNAL_ACCESS
#include "que.h"
#endif

#ifndef PUBLIC_INCLUDED
#include "publicInc.h"
#endif

typedef enum
{
    conn_state_empty,	//not authed
    conn_state_authed,	//lobby status
    conn_state_game,		//status game
    conn_state_destroy	//status exited
} type_conn_state;


typedef struct connection
#ifdef SESSION_INTERNAL_ACCESS
{
	char			  	 	userid[32];
	char			  	 	char_name[32];
	unsigned short  	uLen;
	unsigned short  	nLen;
	unsigned short  	userNo;
	int             	sock;
	unsigned short  	port;
	unsigned int    	addr;
	type_conn_state 	state;
	unsigned int    	sessionkey;
	unsigned int 		clientver;
	int					disco;

	short					frameCnt;//������ ī����
	short					userStat;//�������� 0: �κ� 1:���ӹ����� 2:������ 3:����
	short					roomNo;//default:0

	short					Ax;
	short					Az;
	short					Bx;
	short					Bz;
}
#endif
#ifdef NEED_SESSION_INTERNAL_ACCESS
{
	char			  	 	userid[32];
	char			  	 	char_name[32];
	unsigned short  	uLen;
	unsigned short  	nLen;
	unsigned short  	userNo;
	int             	sock;
	unsigned short  	port;
	unsigned int    	addr;
	type_conn_state 	state;
	unsigned int    	sessionkey;
	unsigned int 		clientver;
	int					disco;

	short					frameCnt;//������ ī����
	short					userStat;//�������� 0: �κ� 1:���ӹ����� 2:������ 3:����
	short					roomNo;//default:0

	short					Ax;
	short					Az;
	short					Bx;
	short					Bz;
}
#endif
type_session;

typedef struct connArray
#ifdef SESSION_INTERNAL_ACCESS
{
	type_session			s;
	int						sockNo;
	char						flag;
}
#endif
#ifdef NEED_SESSION_INTERNAL_ACCESS
{
	type_session			s;
	int						sockNo;
	char						flag;
}
#endif
t_sessionArray;

extern type_session * session_create(int sock, unsigned int addr, unsigned short port);
extern void session_clear(type_session * c);

extern int session_set_userid(type_session * c, char * msg,int len);

extern void init_t_sessionArray();
extern void reset_sessionArray(int idx);

extern type_session * ret_session(int idx);
extern type_session * ret_session_first(unsigned int max);
extern type_session * ret_session_next(unsigned int max);
extern type_session * ret_session_first2(unsigned int max);
extern type_session * ret_session_next2(unsigned int max);
