#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/select.h>
#include <sys/poll.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/errno.h>
#include <pthread.h>

#ifndef _LINUXOS
	#include <sys/devpoll.h>
#endif
#include <poll.h>
#define _REENTRANT


extern pthread_mutex_t 		sendQuelock;
extern pthread_cond_t		sendQuecond;
extern pthread_mutex_t 		synclock;
extern pthread_cond_t		synccond;
extern pthread_mutex_t 		AuthChkLock;


#ifdef MAP_INTERNAL_ACCESS
	 extern type_queue * send_que;
#else
	extern int sendQuedone;

	#ifndef PUBLIC_INCLUDED
		#include "publicInc.h"
	#endif

	#define NEED_PACKET_INTERNAL_ACCESS
	#include "packet.h"
	#define NEED_SESSION_INTERNAL_ACCESS
	#include "session.h"

	#ifdef THR_ACT_INTERNAL_ACC
		 extern type_queue * send_que;
	#endif

	extern int svr_ret_tot();

	#ifdef SVR_INTERNAL_ACCESS
		void * Thread_sendpack(void *arg);//thread3
		void * Thread_recvpack(void *arg);
		void * Thread_udpserv(void *arg);//thread5
		void * Thread_sync(void *arg);//thread4
		void LogToFile (char *, char *);
		void ERROR_SO_DISCONNECT(int uSock);
	#endif
#endif
