#ifndef PUBLIC_INCLUDED
#include "publicInc.h"
#endif
#include <sys/socket.h>

typedef struct sockaddr_in	type_sockadr;

typedef struct svrLst
{
	char 						ip[4];
	unsigned short 		tport;
	type_sockadr			udpSvr[1]; 
	int						udpLen;
	int						g_map_idx;
	//int						udpPort;
} type_svrlst;

extern int db_user_auth(char * userid, char *passwd, int passlen, void * conn);

/*
extern char * db_ret_realip(int idx);
extern short db_ret_realport(int idx);
extern type_sockadr * db_ret_udpsock(int idx);
extern int db_ret_udpLen(int idx);
extern type_sockadr * db_ret_chatsock();
extern int db_ret_chatLen();

extern int db_ret_mapindex(int idx);
extern int db_LOAD_SERVERLIST();
extern void db_test(void *conn);


extern short db_load_charInfo(void * con, void * data,char * userid,short flag,short Tx,short Tz);
extern short db_save_all(void * chrr,char * userid,void * conns);
extern short db_lvpoint_use(void * character,short dat,void *conn);

extern short db_char_lvup(void * chrr,void * conn);

extern void db_item_setnotuse(void * itm,void * conns);
extern int db_item_sell(void * chrr,void * conns,unsigned short idx,unsigned short cnt,unsigned short invidx,unsigned int amount);

extern void db_jobhistory(void * chrr,char * dat,void * con);//���������丮
extern short db_skill_wear(void * chrr,unsigned short sidx, void * conn);
extern short db_skill_lvup(void * chrr,int sp,int zule,unsigned short invidx,short slotidx, void * conn);
extern short db_class_change(void * chrr,int sp,int zule, void * conn,short addcnt, short *addsk,char * invidx,short tg_job,short tg_class);
extern short db_class_change_demon(void * chrr,int sp,int zule, void * conn,short addcnt, short *addsk,char * invidx,short tg_job,short tg_class);
*/
