#include <stdio.h>
#include <stdlib.h>
#define OBJLIST_INTERNAL_ACCESS
#include "objlist.h"

extern int add_node_objlist(type_objlist * * objlist, void *	data)
{
	type_objlist * node;
	if (!objlist)
		return -1;
	if (!(node = malloc(sizeof(type_objlist))))
		return -1;
	node->data = data;
	node->next = *objlist;
	*objlist = node;
	return 0;
}

extern type_objlist * * find_node_objlist(type_objlist * * objlist, void *	data)
{
	type_objlist * * tmps;
	if (!objlist)
		return NULL;
	if (!*objlist)
		return NULL;
	tmps = objlist;
	if ((*tmps)->data==data)
		return tmps;
	while ((*tmps)->next && (*tmps)->next->data!=data)
		tmps = &(*tmps)->next;
	if ((*tmps)->next)
		return &(*tmps)->next;
	return NULL;
}

extern int rm_objlist(type_objlist * * objlist)
{
	type_objlist const * tmps;

	if (!objlist)
		return -1;
	tmps = *objlist;
	if (!tmps)
		return -1;

	*objlist = (*objlist)->next;
	free((void *)tmps);
	return 0;
}

extern void * get_node_objlist(type_objlist const * objlist)
{
	if (!objlist)
		return NULL;
	return objlist->data;
}


extern type_objlist const * const * get_next_node_objlist_const(type_objlist const * objlist)
{
	if (!objlist)
		return NULL;
	return (type_objlist const * const *)&objlist->next;
}

extern type_objlist * pop_data(type_objlist * * objlist)
{
	type_objlist * tmps;
	if (!objlist)
		return NULL;
	tmps = *objlist;
	if (!tmps)
		return NULL;
	*objlist = (*objlist)->next;
	return tmps;
}


extern int insert_node_objlist(type_objlist * * target_objlist, type_objlist * source_objlist)
{

	if (!target_objlist)
		return -1;
	if (!source_objlist)
		return -1;
	source_objlist->next = *target_objlist;
	*target_objlist = source_objlist;
	return 0;
}
