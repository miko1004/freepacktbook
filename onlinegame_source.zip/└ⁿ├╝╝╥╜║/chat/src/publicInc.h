#define PUBLIC_INCLUDED
/*db setting*/
#define _DBSERV		"localhost"
#define _DBID			"mitierra"
#define _DBPASS		"boaboa"
#define _DBDB			"boa"

/*port*/
#define _G_TCP_PORT 9901
#define _G_UDP_PORT 8801


/*frame base*/
#define GAME_FRAME 	0x0F
#define HALF_SEC		0x07
#define D_HALF_SEC	0x03


/*server number settiong*/
#define MX_SVR_NO 	0x069

/*map size*/
#define S_WIDTH  		32


/*max user*/
#define MAXUSERNUM 	0x1000


/*Log file*/
#define _LOG_BUF_SYS_		"~kiki/mlSYS.log" //msg log


/*packet header definition*/
enum {  //	login & character create
		PK_USER_AUTH,
		PK_USER_CHAT=10,PK_USER_INFO,
		PK_REQ_LOC=20,
		PK_CMD_MV=30,PK_USER_MV
};


/*return value settings*/
typedef enum {
	RET_TRUE, RET_FALSE, RET_REDUN, RET_NOID, RET_FULL, RET_NOTENO
}type_tf;


/*max packet size*/
#define MAX_PACKET_SIZE 0x400








/************************************************************************************
*	- Warnning -																							*
*						Don't touch below!!																*
************************************************************************************/
/*standard output*/
#define STDINFD 0
#define STDOUTFD 1
#define STDERRFD 2

/*listen queue size*/
#define LISTEN_QUEUE 0x0A

/* frame setting*/
#define REGEN_TIME GAME_FRAME*2
#define AFRAME	900000/GAME_FRAME
#define _ONE_SEC	GAME_FRAME
#define _TWO_SEC	GAME_FRAME*2
#define _THREE_SEC	GAME_FRAME*3
#define _FOUR_SEC	GAME_FRAME*4
#define _FIVE_SEC	GAME_FRAME*5

/*packet end marker*/
#define PEND 0xC8D1

void LogToFile (char *, char *);
void LogFile (char *msg, FILE *fp);
#define	SA	struct sockaddr

