#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define PACKET_INTERNAL_ACCESS
#include "packet.h"

extern type_packet * packet_create()
{
	type_packet * temp;
	if (!(temp = malloc(sizeof(type_packet)))){
		printf("��Ŷ���� �޸��Ҵ翡��\n");
		return NULL;
	}
	return temp;
}

extern void packet_destroy(type_packet const * packet)
{
	if (packet)
		free((void *)packet);
}

