#include		<stdio.h>
#include		<sys/types.h>	/* basic system data types */
#include 	<strings.h>
#include 	<stdlib.h>
#include 	<math.h>

#define S_UNITSIZE  	16 //��������

#define MAPSIZEX		512
#define MAP_INTERNAL_ACCESS
#include "map.h"


#include "svr.h"

#define USR_MV_LEV 11	//������ �����ӷ��� ������
char logbuf[1024];

static type_map	mapArray[S_WIDTH][S_WIDTH];

extern void * voidlist_get_first(type_objlist const * const * * save,unsigned short i, unsigned short j)
{
	void * conn;

	if (!save)
		return NULL;
	*save = (type_objlist const * const *)&(mapArray[i][j].objL); /* avoid warning */
	if (!**save)
	{
		*save = NULL;
		return NULL;
	}
	conn = get_node_objlist(**save);
	*save = get_next_node_objlist_const(**save);
	return conn;
}

extern void * voidlist_get_next(type_objlist const * const * * save)
{
	void * conn;

	if (!save)
	return NULL;

	if (!*save || !**save)
	{
		*save = NULL;
		return NULL;
	}
	conn = get_node_objlist(**save);
	*save = get_next_node_objlist_const(**save);
	return conn;
}

extern void mapinit(type_session * c){//ĳ������ġ ��Ʈ
	add_node_objlist(&(mapArray[c->Ax][c->Az].objL),c);//direct map address access
}


extern void map_char_rm(type_session * c){

	type_objlist * * pos;
	pos =  find_node_objlist(&(mapArray[c->Ax][c->Az].objL),c);
	if(pos==NULL)
		return;
	rm_objlist(pos);
}


extern int map_char_one_mv(type_session * c,unsigned short x,unsigned short z){//��ĭ�� �̵���Ŵ

	type_objlist * * pos;
	type_objlist * tmp;
	short tx,tz;

	if(x>=S_WIDTH||z>=S_WIDTH){

		 return 0;
	}
	if(x==c->Ax&&z==c->Az){
		return 0;
	}
	tx = c->Ax - x;
	tz = c->Az - z;
	if(tx>1||tx<-1||tz>1||tz<-1){

		return 0;
	}
	if(mapArray[c->Ax][c->Az].objL==NULL){

		return 0;
	}
	pos =  find_node_objlist(&(mapArray[c->Ax][c->Az].objL),c);
	if(pos==NULL){

		return 0;
	}
	tmp = pop_data(pos);
	if(!tmp){

		return 0;
	}
	insert_node_objlist(&(mapArray[x][z].objL), tmp);
	c->Ax=x;
	c->Az=z;
	map_bk_sectorinfo(c);//���ο�ѵ����� ������
	map_get_sectorinfo(c);//���ο� ������ ��� ������ �ޱ�..
	return 1;
}



extern void map_usersend_All(unsigned short mapSizeX, unsigned short mapSizeZ,char * retdata,int len,type_session * c){//��ǥ x,y�� �迭�ּҸ� �޴´�.... chr �� ���ϰ�� ��ο��� ������. chr�� ������� chr�� ���� ������

	int i,j,x,z;
	type_objlist  const * const * tmp_objlist;
	void * tmp_char;	//
	void * ntmp_char;	//
	type_session * tc;
	type_packet	* relaypacket;
	pthread_mutex_lock(&sendQuelock);
	for (i=3;i>0;i--) {
		x = mapSizeX -i+2;
		if(x<0 || x>S_WIDTH-1) continue;

		for(j=3;j>0;j--){
			z = mapSizeZ -j+2;
			if(z<0||z>S_WIDTH-1) continue;

			for(tmp_char=voidlist_get_first(&tmp_objlist,x,z); tmp_char; tmp_char=ntmp_char)
			{
				ntmp_char = voidlist_get_next(&tmp_objlist);
				tc = (type_session *)tmp_char;
				if(tc->state==conn_state_destroy) continue;

				if(c==NULL){
					if (!(relaypacket = packet_create())){
				 		pthread_mutex_unlock(&sendQuelock);
				 		return;
					}
					memset(relaypacket->data,0,MAX_PACKET_SIZE);
					relaypacket->size = len;
					relaypacket->cli_sock = tc->sock;
					relaypacket->session = tc;
					memcpy(&relaypacket->data[0],&retdata[0],len);/////////////////////////////
					queue_push_packet_raw(&send_que,relaypacket);//��Ŷ�� ���̰� �� �ִ�..
				}else{
					if(c!=tc){
						if (!(relaypacket = packet_create())){
					 		pthread_mutex_unlock(&sendQuelock);
					 		return;
						}
						memset(relaypacket->data,0,MAX_PACKET_SIZE);
						relaypacket->size = len;
						relaypacket->cli_sock = tc->sock;
						relaypacket->session = tc;
						memcpy(&relaypacket->data[0],&retdata[0],len);/////////////////////////////
						queue_push_packet_raw(&send_que,relaypacket);//��Ŷ�� ���̰� �� �ִ�..
					}
				}// end if(chr==NULL)
			}
		}//inner for loop
	}//end first for loop
	pthread_cond_signal(&sendQuecond);
	pthread_mutex_unlock(&sendQuelock);
}

extern void map_bk_sectorinfo(type_session * c){//character�� ���� �̵����� ���� ���ο� ���Ϳ� ������ �������ش�..

	int x,z;
	int ax,az,i;
	short dLen=2;
	char udata[128];
	unsigned short	nEnd = PEND;

	memset(udata,0,128);
	udata[dLen] = PK_USER_MV;//2
	dLen+=1;
	udata[dLen] = RET_TRUE;//3
	dLen+=1;
	memcpy(&udata[dLen],&c->userNo,2);//8
	dLen+=2;
	udata[dLen] = c->uLen;
	dLen+=1;
	memcpy(&udata[dLen],&c->userid[0],c->uLen);//8
	dLen+=c->uLen;
	udata[dLen] = c->Ax;
	dLen+=1;
	udata[dLen] = c->Az;
	dLen+=1;
	udata[dLen] = c->Bx;
	dLen+=1;
	udata[dLen] = c->Bz;
	dLen+=1;
	memcpy(&udata[dLen],&nEnd,2);
	dLen+=2;
	memcpy(&udata[0],&dLen,2);

	x = c->Bx - c->Ax;//0
	z = c->Bz - c->Az;//1

	if(x==0 && z<0){// 12�ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az +1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){

				map_secdata_snd(ax, az, udata, dLen);

			}else continue;

		}//end for loop
	}else if(x<0  && z<0){// 1 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az +1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;

		}//end for loop

		for(i=0;i<2;i++){
			ax = c->Ax +1;
			az = c->Az -i;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;
		}//end for loop

	}else if(x<0 && z==0){// 3 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax +1;//28
			az = c->Az -i+2;//14

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az,udata, dLen);
			}else continue;

		}//end for loop
	}else if(x<0  && z>0){// 4 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az -1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;

		}//end for loop

		for(i=0;i<2;i++){
			ax = c->Ax +1;
			az = c->Az +i;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az,udata, dLen);
			}else continue;

		}//end for loop

	}else if(x==0 && z>0){// 6 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az -1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;

		}//end for loop
	}else if(x>0  && z>0){// 7 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az -1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;

		}//end for loop

		for(i=0;i<2;i++){
			ax = c->Ax -1;
			az = c->Az +i;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;

		}//end for loop


	}else if(x>0  && z==0){// 9 �ù���	��

		for(i=3;i>0;i--){

			ax = c->Ax -1;
			az = c->Az -i+2;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;

		}//end for loop
	}else if(x>0  && z<0){// 10�ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az +1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;

		}//end for loop

		for(i=0;i<2;i++){
			ax = c->Ax -1;
			az = c->Az -i;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH){
				map_secdata_snd(ax, az, udata, dLen);
			}else continue;

		}//end for loop

	}
}




extern void map_get_sectorinfo(type_session * c){//character�� ���� �̵����� ���� ���ο� ���Ϳ� ������ �޴´�..

	int x,z,ax,az,i;

	x = c->Bx - c->Ax;
	z = c->Bz - c->Az;
	if(x==0 && z<0){// 12�ù���	��
		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az +1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH)
				map_secdata_snd_client(ax, az,c);
			else continue;
		}//end for loop
	}else if(x<0  && z<0){// 1 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az +1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH)
				map_secdata_snd_client(ax, az,c);
			else continue;
		}//end for loop

		for(i=0;i<2;i++){
			ax = c->Ax +1;
			az = c->Az -i;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH)
				map_secdata_snd_client(ax, az,c);
			else continue;
		}//end for loop

	}else if(x<0 && z==0){// 3 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax +1;
			az = c->Az -i+2;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH)
				map_secdata_snd_client(ax, az,c);
			else continue;
		}//end for loop
	}else if(x<0  && z>0){// 4 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az -1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH)
				map_secdata_snd_client(ax, az,c);
			else continue;
		}//end for loop

		for(i=0;i<2;i++){
			ax = c->Ax +1;
			az = c->Az +i;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH)
				map_secdata_snd_client(ax, az,c);
			else continue;
		}//end for loop

	}else if(x==0 && z>0){// 6 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az -1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH)
				map_secdata_snd_client(ax, az,c);
			else continue;
		}//end for loop
	}else if(x>0  && z>0){// 7 �ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az -1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH)
				map_secdata_snd_client(ax, az,c);
			else continue;
		}//end for loop

		for(i=0;i<2;i++){
			ax = c->Ax -1;
			az = c->Az +i;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH)
				map_secdata_snd_client(ax, az,c);
			else continue;
		}//end for loop


	}else if(x>0  && z==0){// 9 �ù���	��

		for(i=3;i>0;i--){

			ax = c->Ax -1;
			az = c->Az -i+2;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH)
				map_secdata_snd_client(ax, az,c);
			else continue;
		}//end for loop
	}else if(x>0  && z<0){// 10�ù���	��

		for(i=3;i>0;i--){
			ax = c->Ax -i+2;
			az = c->Az +1;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH)
				map_secdata_snd_client(ax, az,c);
			else continue;
		}//end for loop

		for(i=0;i<2;i++){
			ax = c->Ax -1;
			az = c->Az -i;

			if(ax>=0 && ax<S_WIDTH && az>=0 && az<S_WIDTH)
				map_secdata_snd_client(ax, az,c);
			else continue;
		}//end for loop

	}
}

extern void map_userDisconn(type_session * c){

	char data[16];
	short dLen = 2,objcnt=1;
	unsigned short	nEnd = PEND;
printf("map_userDisconn\n");
	data[dLen] = 1;
	dLen+=1;
	data[dLen] =RET_TRUE;
	dLen+=1;
	memcpy(&data[dLen],&objcnt,2);
	dLen+=2;
	data[dLen] =1;
	dLen+=1;
	data[dLen] =1;
	dLen+=1;
	memcpy(&data[dLen],&c->userNo,2);
	dLen+=2;
	data[dLen] =1;
	dLen+=1;
	memcpy(&data[dLen],&nEnd,2);
	dLen+=2;
	memcpy(&data[0],&dLen,2);
printf("��Ŀ��Ʈ ��Ŷ������ ������ �ε���..%d\n",c->userNo);
	map_usersend_All(c->Ax,c->Az,data,dLen,c);
}


extern void map_secdata_snd_client(short ax, short az,type_session * c){//ax,az ������ �ѵ� �����͸� Ŭ���̾�Ʈ�� �޴´�.

	type_objlist  const * const * tmp_objlist;
	void * tmp_char;
	void * ntmp_char;
	type_session * tc;
	short objCnt=0,dLen = 2;
	char  udata[MAX_PACKET_SIZE];
	unsigned short	nEnd = PEND;

	udata[dLen] = PK_USER_INFO;//2
	dLen+=1;
	//memcpy(&udata[dLen],&objCnt,2);//user count �ڿ��� ���Ѵ�..idx:3
	dLen+=2;

	for(tmp_char=voidlist_get_first(&tmp_objlist,ax,az); tmp_char; tmp_char=ntmp_char)
	{
		ntmp_char = voidlist_get_next(&tmp_objlist);
		tc=(type_session *)tmp_char;
		objCnt+=1;
		memcpy(&udata[dLen],&tc->userNo,2);
		dLen+=2;
		udata[dLen] = tc->uLen;
		dLen+=1;
		memcpy(&udata[dLen],&tc->userid[0],tc->uLen);//8
		dLen+=tc->uLen;
		udata[dLen] = tc->Ax;//6
		dLen+=1;
		udata[dLen] = tc->Az;//7
		dLen+=1;
		if(dLen>MAX_PACKET_SIZE-40){
			memcpy(&udata[dLen],&nEnd,2);
			dLen+=2;
			memcpy(&udata[0],&dLen,2);
			memcpy(&udata[3],&objCnt,2);//4
			map_pData_snd(c,udata,dLen);
			objCnt=0;
			dLen=5;
		}
	}//end for loop

	if(objCnt>0){
		memcpy(&udata[dLen],&nEnd,2);
		dLen+=2;
		memcpy(&udata[0],&dLen,2);
		memcpy(&udata[3],&objCnt,2);//4
		map_pData_snd(c,udata,dLen);
	}
}


extern void map_secdata_snd(short ax, short az, char *retdata,short dLen){//ax,az ������ �ѵ����� retdata�� ������.

	type_objlist  const * const * tmp_objlist;
	void * tmp_char;
	void * ntmp_char;
	type_session * tc;
	type_packet	* relaypacket;
//printf("map_secdata_snd\n");
	pthread_mutex_lock(&sendQuelock);
	for(tmp_char=voidlist_get_first(&tmp_objlist,ax,az); tmp_char; tmp_char=ntmp_char)
	{
		ntmp_char = voidlist_get_next(&tmp_objlist);
		tc = (type_session *)tmp_char;

			if (!(relaypacket = packet_create())){
				pthread_mutex_unlock(&sendQuelock);
		 		return;
			}
			memset(relaypacket->data,0,MAX_PACKET_SIZE);
			relaypacket->size = dLen;
			relaypacket->cli_sock = tc->sock;
			relaypacket->session = tc;
			memcpy(&relaypacket->data[0],&retdata[0],dLen);/////////////////////////////


			queue_push_packet_raw(&send_que,relaypacket);//��Ŷ�� ���̰� �� �ִ�..
//			sendQuedone++;//ť�� �Է� �� �������� �������Ѿߵ�...
	}
	pthread_cond_signal(&sendQuecond);
	pthread_mutex_unlock(&sendQuelock);
}


extern void map_pData_snd(type_session * c, char *retdata,short dLen){//���������� ������...

	type_packet	* relaypacket;

	if(c==NULL) return;

	if (!(relaypacket = packet_create())){
 		return;
	}
	memset(relaypacket->data,0,MAX_PACKET_SIZE);
	relaypacket->size = dLen;
	relaypacket->cli_sock = c->sock;
	relaypacket->session = c;
	memcpy(&relaypacket->data[0],&retdata[0],dLen);/////////////////////////////

	pthread_mutex_lock(&sendQuelock);
	queue_push_packet_raw(&send_que,relaypacket);//��Ŷ�� ���̰� �� �ִ�..
	pthread_cond_signal(&sendQuecond);
	pthread_mutex_unlock(&sendQuelock);

}

extern void map_get_sectorinfo_All(type_session * c){

	int i,j,x,z;
	type_objlist  const * const * tmp_objlist;
	void * tmp_char;	//
	void * ntmp_char;	//
	type_session * tc;
	short objCnt=0,dLen = 2;
	char  udata[MAX_PACKET_SIZE];
	unsigned short	nEnd = PEND;

	udata[dLen] = PK_USER_INFO;//2
	dLen+=1;
	//memcpy(&udata[dLen],&objCnt,2);//user count �ڿ��� ���Ѵ�..idx:3
	dLen+=2;

	for (i=3;i>0;i--) {
		x = c->Ax -i+2;
		if(x<0 || x>S_WIDTH-1) continue;

		for(j=3;j>0;j--){
			z = c->Az -j+2;
			if(z<0||z>S_WIDTH-1) continue;

			for(tmp_char=voidlist_get_first(&tmp_objlist,x,z); tmp_char; tmp_char=ntmp_char)
			{
				ntmp_char = voidlist_get_next(&tmp_objlist);
				tc = (type_session *)tmp_char;
				if(tc->userNo==c->userNo) continue;
				objCnt+=1;
				memcpy(&udata[dLen],&tc->userNo,2);
				dLen+=2;
				udata[dLen] = tc->uLen;
				dLen+=1;
				memcpy(&udata[dLen],&tc->userid[0],tc->uLen);//8
				dLen+=tc->uLen;
				udata[dLen] = tc->Ax;//6
				dLen+=1;
				udata[dLen] = tc->Az;//7
				dLen+=1;
				if(dLen>MAX_PACKET_SIZE-40){
					memcpy(&udata[dLen],&nEnd,2);
					dLen+=2;
					memcpy(&udata[0],&dLen,2);
					memcpy(&udata[3],&objCnt,2);//4
					map_pData_snd(c,udata,dLen);
					objCnt=0;
					dLen=5;
				}
			}
		}//inner for loop
	}//end first for loop

	if(objCnt>0){
		memcpy(&udata[dLen],&nEnd,2);
		dLen+=2;
		memcpy(&udata[0],&dLen,2);
		memcpy(&udata[3],&objCnt,2);//4
		map_pData_snd(c,udata,dLen);
	}
}





extern void map_sec_test(){//ax,az ������ �ѵ����� retdata�� ������.

	type_objlist  const * const * tmp_objlist;
	void * tmp,* ntmp;
	type_session * tc;

	printf("sect 0,0 user list:");
	for(tmp=voidlist_get_first(&tmp_objlist,0,0);tmp;tmp=ntmp)
	{
		ntmp = voidlist_get_next(&tmp_objlist);
		tc = (type_session *)tmp;
		printf(" %s ",tc->userid);
	}
	printf("\n");
}


//extern short map_in_ischr(type_session * c){//�ɸ��Ͱ� �ִ� ���̳�?

//	if(c->Ptid==1) return 1;
//	else return 0;
//}

