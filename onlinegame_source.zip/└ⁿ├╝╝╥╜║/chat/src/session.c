#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>

#define SESSION_INTERNAL_ACCESS
#include "session.h"
#undef SESSION_INTERNAL_ACCESS
#include "thr_act.h"

#define NPC_INCLUEDS_MAP
#include "map.h"

static t_sessionArray sess_array[MAXUSERNUM];
static volatile int sockTosess[MAXUSERNUM];
static volatile int ar_idx;
static volatile int ar_idx2;
static volatile int ar_cnt;
static volatile int ar_cnt2;


extern void init_t_sessionArray(){
	int i;

	for(i=0;i<MAXUSERNUM;i++){
		sess_array[i].flag=0;
		//sess_array[i].sockNo=i;
	}
}

extern void reset_sessionArray(int idx){

	if(idx>=MAXUSERNUM || idx<0)
		return;
	sess_array[idx].flag=0;
}

extern type_session * ret_session(int idx){
	if(idx>=MAXUSERNUM || idx<=0) return NULL;
	return &sess_array[sockTosess[idx]].s;
}

extern type_session * ret_session_first(unsigned int max){

	int i;

	if(max==0) return NULL;

	for(i=0;i<MAXUSERNUM;i++){
		if(sess_array[i].flag==1){
			ar_idx=i;
			ar_cnt=1;
			return &sess_array[i].s;
		}
	}
	return NULL;
}

extern type_session * ret_session_next(unsigned int max){
	int i;

	if(max<=ar_cnt) return NULL;

	for(i=ar_idx+1;i<MAXUSERNUM;i++){
		if(sess_array[i].flag==1){
			ar_idx=i;
			ar_cnt+=1;
			return &sess_array[i].s;
		}
	}
	return NULL;
}

extern type_session * ret_session_first2(unsigned int max){

	int i;

	if(max==0) return NULL;

	for(i=0;i<MAXUSERNUM;i++){
		if(sess_array[i].flag==1){
			ar_idx2=i;
			ar_cnt2=1;
			return &sess_array[i].s;
		}
	}
	return NULL;
}

extern type_session * ret_session_next2(unsigned int max){

	int i;

	if(max<=ar_cnt2) return NULL;
	for(i=ar_idx2+1;i<MAXUSERNUM;i++){
		if(sess_array[i].flag==1){
			ar_idx2=i;
			ar_cnt2+=1;
			return &sess_array[i].s;
		}
	}
	return NULL;
}


extern type_session * session_create(int sock, unsigned int addr, unsigned short port)
{
	int i,chk=0;

	if (sock<0) return NULL;
	for(i=0;i<MAXUSERNUM;i++){
		if(sess_array[i].flag==0){
			sess_array[i].flag=1;
			chk=1;
			break;
		}
	}
	if(chk==0) return NULL;

	sess_array[i].s.sock             	= sock;
   sess_array[i].s.port           	 	= port;
   sess_array[i].s.disco					= 0;
   sess_array[i].s.addr             	= addr;
	sess_array[i].s.state            	= conn_state_empty;
   sess_array[i].s.clientver        	= 0;
	sess_array[i].s.frameCnt				= 0;//������ ī����
	sess_array[i].s.userStat				= 0;//�������� 0: �κ� 1:���ӹ����� 2:������ 3:����
	sess_array[i].s.roomNo					= 0;//default:0
	sess_array[i].s.userNo					= i;
	sockTosess[sock]							= i;//���Ͼ�̱��
	sess_array[i].s.Ax						= 0;
	sess_array[i].s.Az						= 0;
	sess_array[i].s.Bx						= 0;
	sess_array[i].s.Bx						= 0;

	return &sess_array[i].s;
}

extern void session_clear(type_session * c)
{
	if (!c)
		return;

	if(c->userStat!=0){
		//thr_reset_gameroominfo(c,c->roomNo);
	}
	reset_sessionArray(c->userNo);
	map_char_rm(c);

	shutdown(c->sock,2);
	close(c->sock);
	//free(c);
}

extern int session_set_userid(type_session * c, char * msg,int len)
{
	if(len>20) return 0;
	memcpy(&c->userid[0],&msg[0],len);
	c->userid[len] = '\0';
	c->uLen = len;
	return 1;
}
