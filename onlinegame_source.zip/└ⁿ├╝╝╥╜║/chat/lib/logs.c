#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void GetTimeNNDDHHMMSS (char *s)
{
    struct tm *newtime;
    time_t long_time;

    time( &long_time );
    newtime = localtime( &long_time );

	sprintf (s, "%02d/%02d %02d:%02d:%02d",
			newtime->tm_mon+1,  newtime->tm_mday,
			newtime->tm_hour,   newtime->tm_min, newtime->tm_sec);
}

void LogToFile (char *msg,char *logfile)
{
	struct tm *newtime;
	time_t long_time;
	FILE *fp;

	time( &long_time );
	newtime = localtime( &long_time );
	fp = fopen (logfile, "a+");
	if (fp == NULL){
		printf("error unable to open fd\n");
		fclose (fp);
		return;
	}
//	fprintf (fp, "%02d/%02d %02d:%02d:%02d %s",newtime->tm_mon+1,  newtime->tm_mday,
//	newtime->tm_hour,   newtime->tm_min, newtime->tm_sec,msg);
	fprintf (fp, "%s",msg);
	fclose(fp);
}


void LogFile (char *msg, FILE *fp)
{
	struct tm *newtime;
	time_t long_time;

	time( &long_time );
	newtime = localtime( &long_time );
	if (fp == NULL){
		fclose (fp);
		return;
	}
	fprintf (fp, "%02d/%02d %02d:%02d:%02d %s",newtime->tm_mon+1,  newtime->tm_mday,
	newtime->tm_hour,   newtime->tm_min, newtime->tm_sec,msg);

}
