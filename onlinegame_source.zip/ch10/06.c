extern int session_key_cmp(char * userid,int uLen, unsigned int key)
{
	int i;
	for(i=0;i<2048;i++){
		if(key_array[i].flag==1){
			if(key_array[i].Len==uLen){
				if(!strncmp(userid, key_array[i].userid, uLen)){
					if(key_array[i].key==key){
						key_array[i].flag=0;
						return key_array[i].svridx;
					}
				}
			}
		}
	}
	return -1;
}