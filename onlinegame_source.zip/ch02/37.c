extern void map_char_rm(type_session * c){

	type_objlist * * pos;
	pos =  find_node_objlist(&(mapArray[c->Ax][c->Az].objL),c);
	if(pos==NULL)
		return;
	rm_objlist(pos);
}