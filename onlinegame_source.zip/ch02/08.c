int main(){

	int 		tcpsock,udpsock,tresult;
	struct 		sockaddr_in	laddr,udservaddr;
	struct 		linger ling = { 1, 0 };
	type_sockpair 	sockPair;
	pthread_t      	thread_id[4];
	pthread_attr_t 	attr;
	const int	val=1;

	if ((tcpsock = socket(PF_INET,SOCK_STREAM,0))<0)
	{
		printf("error in sock \n");
		return -1;
	}

	if ((udpsock = socket(PF_INET,SOCK_DGRAM,0))<0)
	{
		printf("error in udpsock \n");
		return -1;
	}

	if (setsockopt(tcpsock,SOL_SOCKET,SO_REUSEADDR,&val,sizeof(int))<0)
		printf("error in sockopt1 \n");

	if (setsockopt(tcpsock,SOL_SOCKET,SO_KEEPALIVE,&val,sizeof(int))<0)
		printf("error in sockopt3 \n");

	if (setsockopt(tcpsock, SOL_SOCKET, SO_LINGER, (char *) &ling, sizeof(struct linger)) < 0)
		printf("[initialize_communication()] can't setsockopt(SO_LINGER)\n");

	memset(&laddr,0,sizeof(laddr));
	laddr.sin_family = AF_INET;
	laddr.sin_port = htons((unsigned short)_G_TCP_PORT);
	laddr.sin_addr.s_addr =	htonl(INADDR_ANY);

	bzero(&udservaddr, sizeof(udservaddr));
	udservaddr.sin_family      = AF_INET;
	udservaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	udservaddr.sin_port        = htons((unsigned short)_G_UDP_PORT);

	if (bind(udpsock,(struct sockaddr *)&udservaddr, sizeof(udservaddr))<0)
	{
		printf("error in bind udp\n");
		close(tcpsock);
		return -1;
	}

	if (bind(tcpsock,(struct sockaddr *)&laddr,sizeof(laddr))<0)
	{
		printf("error in bind \n");
		close(tcpsock);
		return -1;
	}

	if (fcntl(tcpsock, F_SETFL, O_NONBLOCK) == -1) {
		printf("error in fcntl \n");
		close(tcpsock);
		return -1;
	}

	if (listen(tcpsock,LISTEN_QUEUE)<0)
	{
		printf("error in listen \n");
		close(tcpsock);
		return -1;
	}

	sockPair.tcpSock = tcpsock;
	sockPair.udpSock = udpsock;

	pthread_attr_init(&attr);
	pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM);

	init_t_sessionArray();  // ���� �ε��� �ʱ�ȭ
	setup_signals();//set up signals

	tresult = pthread_create(&thread_id[0], &attr, Thread_sendpack, NULL);
	if(tresult!=0) printf("thread creation failed %d \n",tresult);
	tresult = pthread_create(&thread_id[1], &attr, Thread_sync, NULL);
	if(tresult!=0) printf("thread creation failed %d \n",tresult);
	tresult = pthread_create(&thread_id[2], &attr, Thread_recvpack, &sockPair);
	if(tresult!=0) printf("thread creation failed %d \n",tresult);
	tresult = pthread_create(&thread_id[3], &attr, Thread_udpserv, &udpsock);
	if(tresult!=0) printf("thread creation failed %d \n",tresult);
	for(;;)
	pause();

	close(tcpsock);

	return 0;
}