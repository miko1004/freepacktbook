extern int rm_objlist(type_objlist * * objlist)
{
	type_objlist const * tmps;

	if (!objlist)
		return -1;
	tmps = *objlist;
	if (!tmps)
		return -1;

	*objlist = (*objlist)->next;
	free((void *)tmps);
	return 0;
}
