extern int main_act(char * dat,short pLen, type_session * c, void * conn,int udpsock){//dat�� ���̿� 			packet, c,

	int	headercd,rLen=2,res;
	char	mesg[MAX_PACKET_SIZE];
	unsigned short	nEnd = PEND;
	unsigned short	Ax,Az;
	short	tx,tz,cLen;

	if(dat[2]<0) headercd=dat[2]+256;
	else headercd=dat[2];
	switch(headercd){
		case PK_USER_CHAT:
			memcpy(&cLen,&dat[3],2);
			if(cLen>pLen-4) return 0;

			mesg[rLen]=PK_USER_CHAT;
			rLen+=1;
			mesg[rLen]=c->uLen;
			rLen+=1;
			memcpy(&mesg[rLen],&c->userid[0],c->uLen);
			rLen+=c->uLen;
			memcpy(&mesg[rLen],&cLen,2);
			rLen+=2;
			memcpy(&mesg[rLen],&dat[5],cLen);
			rLen+=cLen;
			memcpy(&mesg[rLen],&nEnd,2);
			rLen+=2;
			memcpy(&mesg[0],&rLen,2);
			map_usersend_All(c->Ax,c->Az,mesg,rLen,NULL);
			printf("PK_USER_CHAT:ok\n");
		break;

		case PK_REQ_LOC:
			mesg[rLen]=PK_REQ_LOC;
			rLen+=1;
			mesg[rLen]=c->Ax;
			rLen+=1;
			mesg[rLen]=c->Az;
			rLen+=1;
			memcpy(&mesg[rLen],&nEnd,2);
			rLen+=2;
			memcpy(&mesg[0],&rLen,2);
			map_pData_snd(c,mesg,rLen);
			printf("PK_REQ_LOC:ok\n");
		break;

		case PK_CMD_MV:
			Ax=dat[3];
			Az=dat[4];
			if(Ax>=S_WIDTH||Az>=S_WIDTH) return 0;
			tx = c->Ax - Ax;
			tz = c->Az - Az;
			if(tx>1||tx<-1||tz>1||tz<-1||(c->Ax==Ax&&c->Az==Az)) res=0;
			else res=1;
			printf("before:%d,%d after:%d,%d res:%d\n",c->Ax,c->Az,Ax,Az,res);

			if(res==1){
				printf("PK_CMD_MV:TRUE\n");
				mesg[rLen] = PK_USER_MV;	// 2
				rLen+=1;
				mesg[rLen] = RET_TRUE;		// 3
				rLen+=1;
				memcpy(&mesg[rLen],&c->userNo,2);	//8
				rLen+=2;
				mesg[rLen] = c->uLen;
				rLen+=1;
				memcpy(&mesg[rLen],&c->userid[0],c->uLen);	//8
				rLen+=c->uLen;
				mesg[rLen] = Ax;
				rLen+=1;
				mesg[rLen] = Az;
				rLen+=1;
				mesg[rLen] = c->Ax;
				rLen+=1;
				mesg[rLen] = c->Az;
				rLen+=1;
				memcpy(&mesg[rLen],&nEnd,2);
				rLen+=2;
				memcpy(&mesg[0],&rLen,2);
				map_usersend_All(c->Ax,c->Az,mesg,rLen,NULL);
				map_char_one_mv(c,Ax,Az);

				c->Bx=c->Ax;
				c->Bz=c->Az;
			}else{
				mesg[rLen] = PK_USER_MV;	// 2
				rLen+=1;
				mesg[rLen] = RET_FALSE;		// 3
				rLen+=1;
				memcpy(&mesg[rLen],&c->userNo,2); // 8
				rLen+=2;
				mesg[rLen] = c->uLen;
				rLen+=1;
				memcpy(&mesg[rLen],&c->userid[0],c->uLen); // 8
				rLen+=c->uLen;
				mesg[rLen] = c->Ax;
				rLen+=1;
				mesg[rLen] = c->Az;
				rLen+=1;
				mesg[rLen] = Ax;
				rLen+=1;
				mesg[rLen] = Az;
				rLen+=1;
				memcpy(&mesg[rLen],&nEnd,2);
				rLen+=2;
				memcpy(&mesg[0],&rLen,2);
				map_usersend_All(c->Ax,c->Az,mesg,rLen,NULL);
			}

		break;

		default:
			return 0;
	}
	return 1;
}
