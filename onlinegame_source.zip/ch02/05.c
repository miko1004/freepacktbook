typedef struct queues{
	type_packet  * packet;
	struct queues * next;
}type_queue;