extern type_session * ret_session_next(unsigned int max){
	int i;

	for(i=ar_idx+1;i<MAXUSERNUM;i++){
		if(sess_array[i].flag==1){
			ar_idx=i;
			ar_cnt+=1;
			return &sess_array[i].s;
		}
		if(max<=ar_cnt) return NULL;
	}
	return NULL;
}