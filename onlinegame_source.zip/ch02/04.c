typedef struct packet {
	int		cli_sock;
	int		size;
	char        	data[MAX_PACKET_SIZE];
	void *		session;
}type_packet;