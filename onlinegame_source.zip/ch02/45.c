extern void map_get_sectorinfo_All(type_session * c){

	int i,j,x,z;
	type_objlist  const * const * tmp_objlist;
	void * tmp_char;
	void * ntmp_char;
	type_session * tc;
	short objCnt=0,dLen = 2;
	char  udata[MAX_PACKET_SIZE];
	unsigned short	nEnd = PEND;

	udata[dLen] = PK_USER_INFO;//2
	dLen+=1;
	//memcpy(&udata[dLen],&objCnt,2);  // ���� ī��Ʈ �ڿ��� ���Ѵ�..idx:3
	dLen+=2;

	for (i=3;i>0;i--) {
		x = c->Ax -i+2;
		if(x<0 || x>S_WIDTH-1) continue;

		for(j=3;j>0;j--){
			z = c->Az -j+2;
			if(z<0||z>S_WIDTH-1) continue;

			for(tmp_char=voidlist_get_first(&tmp_objlist,x,z); tmp_char; tmp_char=ntmp_char)
			{
				ntmp_char = voidlist_get_next(&tmp_objlist);
				tc = (type_session *)tmp_char;
				if(tc->userNo==c->userNo) continue;
				objCnt+=1;
				memcpy(&udata[dLen],&tc->userNo,2);
				dLen+=2;
				udata[dLen] = tc->uLen;
				dLen+=1;
				memcpy(&udata[dLen],&tc->userid[0],tc->uLen);  // 8
				dLen+=tc->uLen;
				udata[dLen] = tc->Ax;  // 6
				dLen+=1;
				udata[dLen] = tc->Az;  // 7
				dLen+=1;
				if(dLen>MAX_PACKET_SIZE-40){
					memcpy(&udata[dLen],&nEnd,2);
					dLen+=2;
					memcpy(&udata[0],&dLen,2);
					memcpy(&udata[3],&objCnt,2);  // 4
					map_pData_snd(c,udata,dLen);
					objCnt=0;
					dLen=5;
				}
			}
		}// �ȱ� for ���� ��
	}// �� ó�� for ���� ��

	if(objCnt>0){
		memcpy(&udata[dLen],&nEnd,2);
		dLen+=2;
		memcpy(&udata[0],&dLen,2);
		memcpy(&udata[3],&objCnt,2);  // 4
		map_pData_snd(c,udata,dLen);
	}
}