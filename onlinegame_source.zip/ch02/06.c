typedef struct objlist{
    struct objlist *	next;
    void  *	data;
} type_objlist;