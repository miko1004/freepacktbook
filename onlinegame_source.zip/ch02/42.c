extern void map_userDisconn(type_session * c){

	char data[16];
	short dLen = 2,objcnt=1;
	unsigned short	nEnd = PEND;
	printf("map_userDisconn\n");
	data[dLen] = PK_USER_DISCON;
	dLen+=1;
	memcpy(&data[dLen],&c->userNo,2);
	dLen+=2;
	memcpy(&data[dLen],&nEnd,2);
	dLen+=2;
	memcpy(&data[0],&dLen,2);
	printf("��Ŀ��Ʈ ��Ŷ���� �� ���� �ε���..%d\n",c->userNo);
	map_usersend_All(c->Ax,c->Az,data,dLen,c);
}
