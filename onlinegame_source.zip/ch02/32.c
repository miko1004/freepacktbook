extern void queue_push_packet_raw(type_queue * * queue, type_packet * packet)
{
	type_queue * temp;

	if (!queue)
		return;
	if (!packet)
		return;
	temp = *queue;

	if (!temp)
	{
		if (!(temp = malloc(sizeof(type_queue))))
			return;
		temp->next = NULL;
		*queue = temp;
	}
	else
	{
		for (; temp->next; temp=temp->next);
		temp->next = malloc(sizeof(type_queue));
		temp->next->next = NULL;
		temp = temp->next;
	}
	temp->packet = packet;
}
