extern int queue_get_length(type_queue const * const * queue)
{
	type_queue const * temp;
	int             count;

	if (!queue)
		return 0;
	for (temp=*queue,count=0; temp; temp=temp->next,count++);
	return count;
}
