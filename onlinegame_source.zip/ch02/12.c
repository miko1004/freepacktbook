extern void reset_sessionArray(int idx){

	if(idx>=MAXUSERNUM || idx<0)
		return;
	sess_array[idx].flag=0;
}