extern void map_secdata_snd_client(short ax, short az,type_session * c){ // ax,az ������ ���� �����͸� Ŭ���̾�Ʈ�� �޴´�.

	type_objlist  const * const * tmp_objlist;
	void * tmp_char;
	void * ntmp_char;
	type_session * tc;
	short objCnt=0,dLen = 2;
	char  udata[MAX_PACKET_SIZE];
	unsigned short	nEnd = PEND;

	udata[dLen] = PK_USER_INFO;  // 2
	dLen+=1;
	//memcpy(&udata[dLen],&objCnt,2);  // user count �ڿ��� ���Ѵ�..idx:3
	dLen+=2;

	for(tmp_char=voidlist_get_first(&tmp_objlist,ax,az); tmp_char; tmp_char=ntmp_char)
	{
		ntmp_char = voidlist_get_next(&tmp_objlist);
		tc=(type_session *)tmp_char;
		objCnt+=1;
		memcpy(&udata[dLen],&tc->userNo,2);
		dLen+=2;
		udata[dLen] = tc->uLen;
		dLen+=1;
		memcpy(&udata[dLen],&tc->userid[0],tc->uLen);  // 8
		dLen+=tc->uLen;
		udata[dLen] = tc->Ax;  // 6
		dLen+=1; 
		udata[dLen] = tc->Az;  // 7
		dLen+=1;
		if(dLen>MAX_PACKET_SIZE-40){
			memcpy(&udata[dLen],&nEnd,2);
			dLen+=2;
			memcpy(&udata[0],&dLen,2);
			memcpy(&udata[3],&objCnt,2);  // 4
			map_pData_snd(c,udata,dLen);
			objCnt=0;
			dLen=5;
		}
	}  // for ���� ��

	if(objCnt>0){
		memcpy(&udata[dLen],&nEnd,2);
		dLen+=2;
		memcpy(&udata[0],&dLen,2);
		memcpy(&udata[3],&objCnt,2);  // 4
		map_pData_snd(c,udata,dLen);
	}
}