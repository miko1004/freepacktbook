extern void init_t_sessionArray(){
	int i;

	for(i=0;i<MAXUSERNUM;i++){
		sess_array[i].flag=0;
		//sess_array[i].sockNo=i;
	}
}