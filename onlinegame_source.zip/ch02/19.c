void * Thread_sync(void *arg){  // ���� ĳ������ ���⸦ ���ߴ� ������

	struct	timeval start,stop;
	long	tmp,utmp;
	short	regenTime,Half_sec;
	int	i,maxNo;

	sleep(1);

	regenTime = _ONE_SEC*30;
	Half_sec = _ONE_SEC/2;
	for(;;){
		gettimeofday(&start,NULL);
		pthread_mutex_lock(&synclock);
		maxNo = svr_ret_tot();
		for(i=0;i<maxNo;i++)
		{

		}
		pthread_cond_signal(&synccond);
		pthread_mutex_unlock(&synclock);

		gettimeofday(&stop,NULL);
		tmp = stop.tv_sec - start.tv_sec;
		utmp = stop.tv_usec - start.tv_usec;

		if(tmp>1){  // 1������ 0.033�� 33000/

		}else if(tmp==1){
			utmp = 1000000 + utmp;  // �ɸ� �ð�
			if(utmp<AFRAME){
				stop.tv_sec=0;
				stop.tv_usec=AFRAME-utmp;
				select(0, NULL, NULL, NULL, &stop);
			}
		}else{
			if(utmp<AFRAME){
				stop.tv_sec=0;
				stop.tv_usec=AFRAME-utmp;
				select(0, NULL, NULL, NULL, &stop);
			}
		}
	}  // for ���� ��
}
