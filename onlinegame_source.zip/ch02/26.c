extern type_objlist const * const * get_next_node_objlist_const(type_objlist const * objlist)
{
	if (!objlist)
		return NULL;
	return (type_objlist const * const *)&objlist->next;
}