extern type_session * ret_session_first(unsigned int max){

	int i;

	if(max==0) return NULL;

	for(i=0;i<MAXUSERNUM;i++){
		if(sess_array[i].flag==1){
			ar_idx=i;
			ar_cnt=1;
			return &sess_array[i].s;
		}
	}
	return NULL;
}