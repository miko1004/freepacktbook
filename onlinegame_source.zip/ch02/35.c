extern void * voidlist_get_next(type_objlist const * const * * save)
{
	void * conn;

	if (!save)
	return NULL;

	if (!*save || !**save)
	{
		*save = NULL;
		return NULL;
	}
	conn = get_node_objlist(**save);
	*save = get_next_node_objlist_const(**save);
	return conn;
}
