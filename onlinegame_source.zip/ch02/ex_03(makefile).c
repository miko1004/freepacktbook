MYSQLDIR=-L/usr/local/mysql/lib/mysql
MYSQLINC=-I/usr/local/mysql/include/mysql
MYSQLLIB=-lmysqlclient

MYOBJ = ../lib/logs.o ../lib/etc.o session.o que.o packet.o thr_act.o objlist.o cmdtime.o map.o db.o


#for Linux OS########################
SL_LINK= -D_LINUXOS
#####################################

#for solaris#########################
SS_LINK= -lsocket
#####################################

C_ARGS = -Wall -D_DEBUG $(SL_LINK)
S_LINK = $(SS_LINK) -lnsl -lm
T_LINK = -D_REENTRANT -lpthread -lnsl -lm $(SS_LINK)

.SUFFIXES  =  .c .o
CC         =  gcc

all: mi

mi: svr.o
	$(CC) $(MYSQLDIR) $(MYSQLINC) -g -o mi svr.o $(MYOBJ) $(T_LINK) -O3 -W $(MYSQLLIB)
	chmod 775 mi
	mv mi ../bin/casu
	mv cclient ../bin/
	rm *.o

svr.o: svr.c
	$(CC) $(MYSQLDIR) $(MYSQLINC) $(C_ARGS) -g -c svr.c
	$(CC) $(C_ARGS) -g -c map.c
	$(CC) $(C_ARGS) -g -c session.c
	$(CC) $(C_ARGS) -g -c que.c
	$(CC) $(C_ARGS) -g -c packet.c
	$(CC) $(C_ARGS) -g -c objlist.c
	$(CC) $(C_ARGS) -g -c cmdtime.c
	$(CC) $(MYSQLDIR) $(MYSQLINC) $(C_ARGS) -g -c thr_act.c
	$(CC) $(MYSQLDIR) $(MYSQLINC) $(C_ARGS) -g -c db.c
	$(CC) $(C_ARGS) -g -o cclient client.c $(S_LINK)

clean  :
	rm -f *.o