extern type_objlist * pop_data(type_objlist * * objlist)
{
	type_objlist * tmps;
	if (!objlist)
		return NULL;
	tmps = *objlist;
	if (!tmps)
		return NULL;
	*objlist = (*objlist)->next;
	return tmps;
}
