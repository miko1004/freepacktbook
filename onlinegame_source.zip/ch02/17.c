extern void session_clear(type_session * c)
{
	if (!c)
		return;

	if(c->userStat!=0){
		//thr_reset_gameroominfo(c,c->roomNo);
	}
	reset_sessionArray(c->userNo);
	map_char_rm(c);

	shutdown(c->sock,2);
	close(c->sock);
	//free(c);
}