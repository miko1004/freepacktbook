void * Thread_recvpack(void *arg){

	int tcpsock;
	unsigned char msg[MAX_PACKET_SIZE],msgto[32][MAX_PACKET_SIZE];
	int	highest_fd;
	int	csocket,pCnt,mx;
	int	n;
	short	rPsize[8];

	type_sockpair sockPair;
	unsigned short	rEnd;
	unsigned short	nEnd = PEND;
	fd_set	rfds, efds;
	int divsize,sizee;

	int state;
	MYSQL * conn;
//	MYSQL mysql;
	type_session *	c;
	type_session *	nc;

	sockPair =  *((type_sockpair *)arg);
	tcpsock = sockPair.tcpSock;

/*	conn = mysql_real_connect(&mysql, _DBSERV, _DBID, _DBPASS,_DBDB,3306,NULL,0);
	if( conn == NULL ) {
		printf(mysql_error(&mysql));
		//return ;
	}
*/
	for(;;)
	{
		FD_ZERO(&rfds);
		FD_ZERO(&efds);
		highest_fd = tcpsock;
		FD_SET(tcpsock,&rfds);
		for(nc=ret_session_first2(tUsercnt);nc;nc=ret_session_next2(tUsercnt)){

			csocket = nc->sock;
			FD_SET(csocket,&rfds);
			FD_SET(csocket,&efds);  // ������ ����

			if (csocket>highest_fd)
				highest_fd = csocket;
		}

		if (select(highest_fd+1,&rfds,NULL,&efds,(struct timeval *)0)<0)
		{
			if (errno!=EINTR)
			continue;
		}

		/* incoming	connection (if select return new conn)*/
		if (FD_ISSET(tcpsock,&rfds))
		{
			int				    	asock;
			struct sockaddr_in 	caddr;
			unsigned int			caddr_len;

			/* ���� ��� */
			caddr_len =	sizeof(caddr);
			if ((asock = accept(tcpsock,(struct sockaddr *)&caddr,&caddr_len))<0)
			{
	            if (errno == EINTR)
	                continue;              /* ��õ� ��� : while() ������ ���ư� */
	            else
						printf("error with accept\n");
				continue;
			}else{

			}

			if (fcntl(asock,F_SETFL,O_NONBLOCK)<0)
			{
				printf("error with fcntl\n");
				shutdown(asock,2);
				close(asock);
				continue;
			}

			pthread_mutex_lock(&synclock);
			if (!(c	= session_create(asock,ntohl(caddr.sin_addr.s_addr),ntohs(caddr.sin_port))))
			{
				printf("error with session create\n");
				pthread_mutex_unlock(&synclock);  // �߿�
				shutdown(asock,2);
				close(asock);
				continue;
			}
			pthread_mutex_unlock(&synclock);
			tUsercnt++;
		}

		for(c=ret_session_first2(tUsercnt);c;c=ret_session_next2(tUsercnt))
		{
			if (c->state==conn_state_destroy)
			{
				tUsercnt--;
				printf("abrut disconnectss\n");
				pthread_mutex_lock(&synclock);
				session_clear(c);
				pthread_mutex_unlock(&synclock);
				continue;
			}

			csocket = c->sock;
			if (FD_ISSET(csocket,&rfds))
			{
				memset(msg,0,sizeof(msg));
				if((sizee = recv(csocket, msg, sizeof(msg), 0))<=0){  // ���� ������
					printf("abrut disconnect in receive\n");
					tUsercnt--;
					pthread_mutex_lock(&synclock);
					session_clear(c);
					pthread_mutex_unlock(&synclock);
					continue;
				}
				memcpy(&rPsize[0],&msg[0],2);
				pCnt=0;//packet count reset
				// ��Ŷ ��ȿ�� �˻�
				if(rPsize[0]==sizee){
					memcpy(&rEnd,&msg[rPsize[0] -2],2);
					if(rEnd != nEnd){
						printf("��Ŷ�� ���� �߸���..\n");
						continue;
					}
					pCnt+=1;
				}else if(rPsize[0]<sizee){
					divsize=0;
					mx=0;
					for(;;){
						if(divsize>=sizee) break;
						memset(msgto[pCnt],0,MAX_PACKET_SIZE);
						memcpy(&msgto[pCnt][0],&msg[divsize],rPsize[pCnt]);
						memcpy(&rEnd,&msgto[pCnt][rPsize[pCnt] -2],2);
						if(rEnd != nEnd){
							printf("��Ŷ�� ���� �߸���..(�پ����Ŷ�� �ձ��̸�ŭ �߶����� �߸���..)\n");
							break;
						}else{
							divsize = rPsize[pCnt];
							pCnt+=1;mx+=divsize;
							memcpy(&rPsize[pCnt],&msg[divsize],2);
						}
					}
				}else continue;
				if(pCnt==1){
					if (c->state==conn_state_empty){
						state = thr_beforeAuth(msg,c,conn,sockPair.udpSock);
						if(state==0){
							printf("���� ĳ���� �ε� ����\n");
							c->state = conn_state_destroy;
							continue;
						}
					}else if(c->state==conn_state_authed){
						state = main_act(msg,rPsize[0],c,conn,sockPair.udpSock);
						if(state==0){
							printf("���� ����ó�� ����\n");
							//c->state = conn_state_destroy;
							continue;
						}
					}else continue;
				}else{
					for(n=0;n<pCnt;n++){
						if (c->state==conn_state_empty){
							state = thr_beforeAuth(msgto[n],c,conn,sockPair.udpSock);
							if(state==0){
								printf("���� �ɸ��ε� ����\n");
								c->state = conn_state_destroy;
								continue;
							}
						}else if(c->state==conn_state_authed){
							state = main_act(msgto[n],rPsize[n],c,conn,sockPair.udpSock);
							if(state==0){
								printf("���� ����ó�� ����\n");
								//c->state = conn_state_destroy;
								continue;
							}
						}else continue;
					}
				}
			}  // if (FD_ISSET(csocket,&rfds)) end ���� �ʱ�ȭ ���� ��Ŷ ����

			if (FD_ISSET(csocket,&efds))
			{
				printf("abrut disconnect in efds\n");
				tUsercnt--;
				//sizee = db_save_all(c->character,c->userid,conn);
				if(sizee==1) printf("DISCONNECT DATA SAVE OKOKOKOKOKOK\n");
				else  printf("DISCONNECT DATA SAVE FALSEFALSEFALSEFALSE\n");
				//thr_chat_userExit(sockPair.udpSock,c);
				pthread_mutex_lock(&synclock);
				session_clear(c);
				pthread_mutex_unlock(&synclock);
			}
		} // ���� ����Ʈ Ž�� ���� ��
	} // ���� ���� ��
	mysql_close(conn);
}