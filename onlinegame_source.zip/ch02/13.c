extern type_session * ret_session(int idx){
	if(idx>=MAXUSERNUM || idx<=0) return NULL;
	return &sess_array[sockTosess[idx]].s;
}