extern void * get_node_objlist(type_objlist const * objlist)
{
	if (!objlist)
		return NULL;
	return objlist->data;
}
