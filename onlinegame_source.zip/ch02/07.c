typedef struct mapsys{
	type_objlist *	objL;
}type_map;