extern int thr_beforeAuth(char * dat, type_session * c,void * conn,int udpsock){

	int pLen=2,headercd,clen,idx,ulen;
	short res,cnt=1;
	char name[32],pass[32];
	char mesg[MAX_PACKET_SIZE];
	unsigned short	nEnd = PEND;

	memcpy(&res,&dat[0],2);  // ���� ��Ŷ �� ����
	res-=2;
	headercd = dat[pLen];
	if(c->userStat==0){  // �κ� ������ ��Ŷ ó��
		switch(headercd){

			case PK_USER_AUTH:
				idx=3;
				ulen=dat[idx];//name len
				idx+=1;
				if(res<ulen+idx||ulen>31) return 0;//error
				memcpy(&name[0],&dat[idx],ulen);
				name[ulen]='\0';
				idx+=ulen;
				clen=dat[idx];//pass len
				idx+=1;
				if(res<clen+idx||clen>31) return 0;//error
				memcpy(&pass[0],&dat[idx],clen);
				pass[clen]='\0';
				//res = db_user_auth(name, pass,clen,conn);
				printf("�������� ��� :%d %s \n",res,name);
				res=1;
				if(res==1){
					conn_set_userid(c,name,ulen);
					mapinit(c);
					c->state=conn_state_authed;
					//map_sec_test();//test
					mesg[pLen]=PK_USER_AUTH;
					pLen+=1;
					mesg[pLen]=svr_ret_tot();
					pLen+=1;
					mesg[pLen]=c->uLen;
					pLen+=1;
					memcpy(&mesg[pLen],&c->userid[0],c->uLen);
					pLen+=c->uLen;
					memcpy(&mesg[pLen],&c->userNo,2);
					pLen+=2;
					memcpy(&mesg[pLen],&nEnd,2);
					pLen+=2;
					memcpy(&mesg[0],&pLen,2);
					map_pData_snd(c,mesg,pLen);
					map_get_sectorinfo_All(c);
					pLen=2;
					mesg[pLen]=PK_USER_INFO;
					pLen+=1;
					memcpy(&mesg[pLen],&cnt,2);
					pLen+=2;
					memcpy(&mesg[pLen],&c->userNo,2);
					pLen+=2;
					mesg[pLen] = c->uLen;
					pLen+=1;
					memcpy(&mesg[pLen],&c->userid[0],c->uLen);
					pLen+=c->uLen;
					mesg[pLen] = c->Ax;
					pLen+=1;
					mesg[pLen] = c->Az;
					pLen+=1;
					memcpy(&mesg[pLen],&nEnd,2);
					pLen+=2;
					memcpy(&mesg[0],&pLen,2);
					map_usersend_All(c->Ax,c->Az,mesg,pLen,NULL);
				}else{
					return 0;
				}

			break;
		}
	}
	return 1;
}
