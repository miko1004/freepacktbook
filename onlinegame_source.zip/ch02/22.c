extern int add_node_objlist(type_objlist * * objlist, void * data)
{
	type_objlist * node;
	if (!objlist)
		return -1;
	if (!(node = malloc(sizeof(type_objlist))))
		return -1;
	node->data = data;
	node->next = *objlist;
	*objlist = node;
	return 0;
}