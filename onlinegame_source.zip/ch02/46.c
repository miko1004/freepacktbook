extern int db_user_auth(char * userid, char *passwd, int passlen, void * conn)
{
	int	state,len;
	MYSQL_RES *result;
	MYSQL_ROW row;
	char query[256];

	memset(query,0,256);
	sprintf(query,"select passwd from userinfo where userid='%s'",userid);

	state = mysql_query((MYSQL *)conn, query);
	if( state == -1 ) {
		printf("testXX%s\n",mysql_error((MYSQL *)conn));
		return 0;
	}
	result = mysql_store_result((MYSQL *)conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("mysql fail return value 0 \n");
		mysql_free_result(result);
		return 0;
	}
	row = mysql_fetch_row(result);
	mysql_free_result(result);

	len = strlen(row[0]);
	if(passlen==len){
		if(!strncmp(row[0],passwd,len)){
			return 1;
		}else{
			return 0;
		}
	}else{
		return 0;
	}
}
