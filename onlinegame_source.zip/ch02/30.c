extern void packet_destroy(type_packet const * packet)
{
	if (packet)
		free((void *)packet);
}
