void * Thread_sendpack(void *arg)
{
	int i,j,ERRkey;
	int rets,tmp_sock;
	type_packet *	 packet;
	type_session * c;
	type_session * ERRmap[16];
	type_session * tmp;
	int que_len;

	for(i=0;i<16;i++)
		ERRmap[i]=NULL;

	for(;;){
		ERRkey=0;
		pthread_mutex_lock(&sendQuelock);
		que_len = queue_get_length((type_queue const  * const  *)&send_que);
		while(que_len==0){
			pthread_cond_wait(&sendQuecond,&sendQuelock);
			que_len = queue_get_length((type_queue const  * const  *)&send_que);
		}
		packet = queue_pull_packet(&send_que);
		i=0;
		while(i<que_len){
			i+=1;

			c = (type_session *)packet->session;
			tmp_sock = c->sock;

			if(!packet->session){
				printf("������ ���̴�.........................\n");
				packet_destroy(packet);
				if(i<que_len) packet = queue_pull_packet(&send_que);

			}else if(tmp_sock==-2){
				printf("svr.c 649���� �ɸ� sigpipe �߻�.........................\n");
				packet_destroy(packet);
				if(i<que_len) packet = queue_pull_packet(&send_que);
			}else{
					if(packet->size<5){
						printf("Send error ��Ŷ���̰� 5���� �۴�...%d\n",packet->data[2]);
					}else{
						rets = send(packet->cli_sock, packet->data, packet->size,0);
						if(rets<=0){
							printf("send errorsss\n");
							ERRmap[ERRkey]=c;
							ERRkey+=1;
						}
					}
					packet_destroy(packet);
					if(i<que_len) packet = queue_pull_packet(&send_que);
			}
		}// while �� ��
		pthread_mutex_unlock(&sendQuelock);

		if(ERRkey!=0){
			pthread_mutex_lock(&synclock);
			for(j=0;j<ERRkey;j++){
				ERRmap[j]->sock= signal_sock_no;
				ERRmap[j]->state = conn_state_destroy;
				tmp=ERRmap[j];
				ERRmap[j]=NULL;
			}
			pthread_mutex_unlock(&synclock);
		}
	}
}