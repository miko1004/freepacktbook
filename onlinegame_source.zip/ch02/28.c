extern int insert_node_objlist(type_objlist * * target_objlist, type_objlist * source_objlist)
{

	if (!target_objlist)
		return -1;
	if (!source_objlist)
		return -1;
	source_objlist->next = *target_objlist;
	*target_objlist = source_objlist;
	return 0;
}
