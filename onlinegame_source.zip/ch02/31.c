extern type_packet * queue_pull_packet(type_queue * * queue)
{
	type_queue *  temp;
	type_packet * packet;

	if (!queue)
		return NULL;
	if (!*queue)
		return NULL;
	temp = *queue;
	*queue = (*queue)->next;
	packet = temp->packet;
	free(temp);

	if (!packet)
		return NULL;
	return packet;
}
