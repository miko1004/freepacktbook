extern type_objlist * * find_node_objlist(type_objlist * * objlist, void * data)
{
	type_objlist * * tmps;
	if (!objlist)
		return NULL;
	if (!*objlist)
		return NULL;
	tmps = objlist;
	if ((*tmps)->data==data)
		return tmps;
	while ((*tmps)->next && (*tmps)->next->data!=data)
		tmps = &(*tmps)->next;
	if ((*tmps)->next)
		return &(*tmps)->next;
	return NULL;
}
