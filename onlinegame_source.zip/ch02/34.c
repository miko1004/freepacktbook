extern void * voidlist_get_first(type_objlist const * const * * save,unsigned short i, unsigned short j)
{
	void * conn;

	if (!save)
		return NULL;
	*save = (type_objlist const * const *)&(mapArray[i][j].objL); /* ��� ���� */
	if (!**save)
	{
		*save = NULL;
		return NULL;
	}
	conn = get_node_objlist(**save);
	*save = get_next_node_objlist_const(**save);
	return conn;
}