extern int conn_set_userid(type_session * c, char * msg,int len)
{
	if(len>20) return 0;
	memcpy(&c->userid[0],&msg[0],len);
	c->userid[len] = '\0';
	c->uLen = len;
	return 1;
}
