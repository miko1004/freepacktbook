extern void map_usersend_All(unsigned short mapSizeX, unsigned short mapSizeZ,char * retdata,int len,type_session * c){  // ��ǥ x, y�� �迭 �ּҸ� �޴´�. chr�� ���̸� ��ο���, �ƴϸ� chr�� ���� ������.

	int	i,j,x,z;
	type_objlist	const * const * tmp_objlist;
	void	* tmp_char;
	void	* ntmp_char;
	type_session *	tc;
	type_packet	* relaypacket;
	pthread_mutex_lock(&sendQuelock);
	for (i=3;i>0;i--) {
		x = mapSizeX -i+2;
		if(x<0 || x>S_WIDTH-1) continue;

		for(j=3;j>0;j--){
			z = mapSizeZ -j+2;
			if(z<0||z>S_WIDTH-1) continue;

			for(tmp_char=voidlist_get_first(&tmp_objlist,x,z); tmp_char; tmp_char=ntmp_char)
			{
				ntmp_char = voidlist_get_next(&tmp_objlist);
				tc = (type_session *)tmp_char;
				if(tc->state==conn_state_destroy) continue;

				if(c==NULL){
					if (!(relaypacket = packet_create())){
				 		pthread_mutex_unlock(&sendQuelock);
				 		return;
					}
					memset(relaypacket->data,0,MAX_PACKET_SIZE);
					relaypacket->size = len;
					relaypacket->cli_sock = tc->sock;
					relaypacket->session = tc;
					memcpy(&relaypacket->data[0],&retdata[0],len);
					queue_push_packet_raw(&send_que,relaypacket);  // ��Ŷ�� ���̰� ��� �ִ�.
				}else{
					if(c!=tc){
						if (!(relaypacket = packet_create())){
					 		pthread_mutex_unlock(&sendQuelock);
					 		return;
						}
						memset(relaypacket->data,0,MAX_PACKET_SIZE);
						relaypacket->size = len;
						relaypacket->cli_sock = tc->sock;
						relaypacket->session = tc;
						memcpy(&relaypacket->data[0],&retdata[0],len);
						queue_push_packet_raw(&send_que,relaypacket);  // ��Ŷ�� ���̰� ��� �ִ�.
					}
				} // if(chr==NULL) �� ��
			}
		}  // �ȱ� for ���� ��
	} // �� ó�� for ���� ��
	pthread_cond_signal(&sendQuecond);
	pthread_mutex_unlock(&sendQuelock);
}