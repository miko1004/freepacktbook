extern void db_load_skillList(void * con)
{
	int	sktype,coin,skidx,state;
	MYSQL	*	conn;
	MYSQL_RES *result;
	MYSQL_ROW row;
	char query[256];

	conn =(MYSQL *)con;
	item_init();
	memset(query,0,256);
	sprintf(query,"select * from skilldef");

	state = mysql_query(conn, query);
	if( state == -1 ) {
		printf("db_load_expList:%s\n",mysql_error(conn));
		return ;
	}
	result = mysql_store_result(conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("skill def\n");
		mysql_free_result(result);
		return ;
	}
	while((row = mysql_fetch_row(result))!= NULL){
		sktype=atoi(row[0]);
		skidx=atoi(row[1]);
		coin=atoi(row[2]);
		skill_defset(sktype,skidx,row[3],row[4],coin);
	}
	mysql_free_result(result);

}