extern void db_load_expList(void * con)  // Thread_recvpack in svr.c
{
	int	state,lv;
	MYSQL	* conn;
	MYSQL_RES *result;
	MYSQL_ROW row;
	char query[256];

	conn =(MYSQL *)con;
	item_init();
	memset(query,0,256);
	sprintf(query,"select * from expp order by lv asc");

	state = mysql_query(conn, query);
	if( state == -1 ) {
		printf("db_load_expList:%s\n",mysql_error(conn));
		return ;
	}
	result = mysql_store_result(conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("db no exp list found0 \n");
		mysql_free_result(result);
		return ;
	}
	while((row = mysql_fetch_row(result))!= NULL){
		lv=atoi(row[0]);
		exp_list[lv]=atoi(row[1]);
		printf("����%d�� �� %d�� ����ġ�� �־�� %d�� ������ ��\n",lv,exp_list[lv],lv+1);
	}
	mysql_free_result(result);

}