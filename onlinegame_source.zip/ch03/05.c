extern void db_load_npcList(void * con)
{
	int	state,i;
	MYSQL	* conn;
	MYSQL_RES * result;
	MYSQL_ROW row;
	char query[256];
	char div,level,gtype,speed;
	char no;
	short item[12];
	char rate[12];

	conn =(MYSQL *)con;
	item_init();
	memset(query,0,256);
	sprintf(query,"select * from npc");

	state = mysql_query(conn, query);
	if( state == -1 ) {
		printf("db_load_npcList:%s\n",mysql_error(conn));
		return ;
	}
	result = mysql_store_result(conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("db no npc list found0 \n");
		mysql_free_result(result);
		return ;
	}
	while((row = mysql_fetch_row(result))!= NULL){
		div=atoi(row[0]);
		no=atoi(row[1]);
		gtype=atoi(row[2]);
		level=atoi(row[3]);
		speed=atoi(row[4]);
		for(i=0;i<12;i++){
			item[i]=atoi(row[5+i]);
			rate[i]=atoi(row[17+i]);
		}

		npc_set_def(div,no,gtype,level,speed,item,rate);
		if(div==0) printf("NPC load no:%d	gtype:%d	level:%d	speed:%d\n",no,gtype,level,speed);
		else printf("MONSTER load no:%d	gtype:%d	level:%d	speed:%d\n",no,gtype,level,speed);
	}
	mysql_free_result(result);
}