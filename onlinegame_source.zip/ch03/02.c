extern void db_load_itemList(void * con)
{
	int	state,cnt=0;
	MYSQL	* conn;
	MYSQL_RES *result;
	MYSQL_ROW row;
	char query[256];

	conn =(MYSQL *)con;
	item_init();
	memset(query,0,256);
	sprintf(query,"select * from ITEM");

	state = mysql_query(conn, query);
	if( state == -1 ) {
		printf("db_load_itemList:%s\n",mysql_error(conn));
		return ;
	}
	result = mysql_store_result(conn);
	state = mysql_num_rows(result);
	if( state == 0 ) {
		printf("db no item list found0 \n");
		mysql_free_result(result);
		return ;
	}

	while((row = mysql_fetch_row(result))!= NULL){
		cnt++;
		item_load(row);  // �� ������ ����Ʈ�� �߰�
	}
	printf("������ �� %d �� �ε��\n",cnt);
	mysql_free_result(result);

}