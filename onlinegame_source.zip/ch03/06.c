extern void npc_set_def(char div, short no, char gtype, char level, char speed, short * item, char * rate){

	if(div==0){// NPC
		def_npc[no].no=no;
		def_npc[no].gtype=gtype;
		def_npc[no].level=level;
		def_npc[no].speed=speed;
		memcpy(&def_npc[no].item,&item,24);  // short 2  2*12
		memcpy(&def_npc[no].rate,&rate,12);
	}else{  // ����
		def_mon[no].no=no;
		def_mon[no].gtype=gtype;
		def_mon[no].level=level;
		def_mon[no].speed=speed;
		memcpy(&def_mon[no].item,&item,24);  // short 2  2*12
		memcpy(&def_mon[no].rate,&rate,12);
	}
}