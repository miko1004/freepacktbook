extern void npc_attack_chr(void * chrr, unsigned short idx){

	short	DaMaGe,DIRx,DIRz,HP;
	char mesg[64];
	unsigned short rLen = 2;
	unsigned short	nEnd = PEND;
	type_session * chr;

	if(idx>=_MAX_MONSTER_NO) return;
	if(chrr==NULL){
		npcArray[idx]->status=S_STAND;
		npcArray[idx]->dx = npcArray[idx]->Gx;
		npcArray[idx]->dz = npcArray[idx]->Gz;
		npcArray[idx]->targetChr=NULL;
		npcArray[idx]->tgFlag= 0;
		return;
	}

	if(npcArray[idx]->status==S_DIE) return;
	chr = (type_session *)chrr;
	if(chr->userStat == S_DIE){
		npcArray[idx]->status=S_STAND;
		npcArray[idx]->dx = npcArray[idx]->Gx;
		npcArray[idx]->dz = npcArray[idx]->Gz;
		npcArray[idx]->targetChr=NULL;
		npcArray[idx]->tgFlag= 0;
		return;
	}
	DIRx = npcArray[idx]->x - chr->Cx;
	DIRz = npcArray[idx]->z - chr->Cz;

	if(DIRx==0 && DIRz<0) npcArray[idx]->DirLoc= 4;		// 12�� ����
	else if(DIRx<0  && DIRz<0) npcArray[idx]->DirLoc= 3;	// 1�� ����
	else if(DIRx<0 && DIRz==0) npcArray[idx]->DirLoc= 2;	// 3�� ����
	else if(DIRx<0  && DIRz>0) npcArray[idx]->DirLoc= 1;	// 5�� ����
	else if(DIRx==0 && DIRz>0) npcArray[idx]->DirLoc= 0;	// 6�� ����
	else if(DIRx>0  && DIRz>0) npcArray[idx]->DirLoc= 7;	// 7�� ����
	else if(DIRx>0  && DIRz==0) npcArray[idx]->DirLoc= 6;	// 9�� ����
	else if(DIRx>0  && DIRz<0) npcArray[idx]->DirLoc= 5;	// 11�� ����
	pthread_mutex_unlock(&npclock);

	DaMaGe=npcArray[idx]->AP - chr->defence;
	if(DaMaGe<0) DaMaGe=0;
	HP = chr->hp_c - DaMaGe;
	if(HP<0) HP=0;

	mesg[rLen] = PK_OBJ_UPDATE_ACT;  // 2
	rLen+=1;
	mesg[rLen] = T_NPC;  // ��ü ����:0 - ����
	rLen+=1;
	mesg[rLen] = 1;  // ī��Ʈ
	rLen+=1;
	mesg[rLen] = npcArray[idx]->div;  // ī��Ʈ
	rLen+=1;
	memcpy(&mesg[rLen],&npcArray[idx]->npc_id,2);  // 8
	rLen+=2;
	mesg[rLen]=S_FIGHT;
	rLen+=1;
	mesg[rLen]=npcArray[idx]->DirLoc;
	rLen+=1;
	mesg[rLen]=T_USER;  // Ÿ�� Ÿ��
	rLen+=1;
	memcpy(&mesg[rLen],&chr->userNo,2);  // Ÿ�� ���̵� ��ȣ
	rLen+=2;
	memcpy(&mesg[rLen],&HP,2);  // Ÿ�� HP
	rLen+=2;
	memcpy(&mesg[rLen],&nEnd,2);
	rLen+=2;
	memcpy(&mesg[0],&rLen,2);
	map_usersend_All(chr->Ax, chr->Az, mesg, rLen,NULL);

	pthread_mutex_lock(&synclock);//#########################################
	if(HP==0){//chr die
		chr->userStat = S_DIE;
		chr->hp_c  = chr->hp_m/10;
		pthread_mutex_unlock(&synclock);
//		MonsterChrDie(idx,chr);  // ������ �˸�
		pthread_mutex_lock(&npclock);

		npcArray[idx]->status=S_STAND;
		npcArray[idx]->targetChr=NULL;
		npcArray[idx]->tgFlag= 0;

		return;
	}else chr->hp_c=HP;
	pthread_mutex_unlock(&synclock);
	pthread_mutex_lock(&npclock);
	npcArray[idx]->tgFlag= 1;
}