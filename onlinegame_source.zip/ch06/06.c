extern int db_chk_lvup(void * cc,void * con)
{
	type_session * c;
	MYSQL	*	conn;
//	char query[256];
//	int state;

	c=(type_session *)cc;
	conn =(MYSQL *)con;
	if(c->level>MAXUSERLEVEL||c->level==0) return 0;
	if(exp_list[c->level]<=c->exp){
		c->level+=1;
		c->lvpoint+=1;
/*		sprintf(query,"update characters set LV='%d',PT='%d' where userid='%s'",c->level,c->lvpoint,c->userid);

		state = mysql_query(conn, query);
		if( state == -1 ) {
			printf("update lv & lvpoint error:%s\n",mysql_error(conn));
			return 0;
		}
*/
		return 1;
	}else return 0;

}