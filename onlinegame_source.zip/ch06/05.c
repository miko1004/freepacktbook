extern short npc_drop_item(type_npc * npc, unsigned short userNo){

	type_itemLst_field * temp;
	unsigned int ItmNo;
	int tmp=0,cnt=0,loopCnt=0,i;
	short dLen=2;
	char data[128];
	unsigned short	nEnd = PEND;

	tmp = (((unsigned int)rand())^((unsigned int)time(NULL)))%100;  // 10% Ȯ���� ������ 2�� ȹ��
	if(tmp<10) loopCnt=2;
	else loopCnt=1;

	data[dLen] = PK_OBJ_ADD;
	dLen+=1;
	data[dLen] = T_ITEM;
	dLen+=1;
//	data[dLen]= 1;//cnt
	dLen+=1;

	for(i=0;i<12;i++){
		tmp = (((unsigned int)rand())^((unsigned int)time(NULL)))%100;
		if(npc->div==1){  // NPC
			if(def_npc[npc->npc_id].rate[i]<=tmp){
				if(def_npc[npc->npc_id].item[i]==0) continue;
				cnt+=1;
				if (!(temp = malloc(sizeof(type_itemLst_field)))) return 0;

				temp->rmFcnt	=0;
				temp->rmHcnt	=0;

				pthread_mutex_lock(&itemlock);
				temp->item_idx_cnt=item_ret_default_cnt(temp->item_idx);
				if(temp->item_idx_cnt==0){
					free(temp);
					pthread_mutex_unlock(&itemlock);
					continue;
				}
				ItmNo =  retNullitemIdx();  // �ε��� ����
				setitemIdx(ItmNo); 
				temp->idx		=ItmNo;
				item_add_sect(npc->ARx,npc->ARz,temp);
				temp->x=npc->x;
				temp->z=npc->z;
				temp->item_idx=def_npc[npc->npc_id].item[i];
				pthread_mutex_unlock(&itemlock);

				memcpy(&data[dLen],&temp->idx,2);
				dLen+=2;
				memcpy(&data[dLen],&temp->x,2);
				dLen+=2;
				memcpy(&data[dLen],&temp->z,2);
				dLen+=2;
				memcpy(&data[dLen],&temp->item_idx,2);
				dLen+=2;
				memcpy(&data[dLen],&temp->item_idx_cnt,2);
				dLen+=2;
			}
		}else{  // ����
			if(def_mon[npc->npc_id].rate[i]<=tmp){
				if(def_mon[npc->npc_id].item[i]==0) continue;
				cnt+=1;

				if (!(temp = malloc(sizeof(type_itemLst_field)))) return 0;

				temp->rmFcnt=0;
				temp->rmHcnt=0;

				pthread_mutex_lock(&itemlock);
				temp->item_idx_cnt=item_ret_default_cnt(temp->item_idx);
				if(temp->item_idx_cnt==0){
					free(temp);
					pthread_mutex_unlock(&itemlock);
					continue;
				}
				ItmNo =  retNullitemIdx();  // �ε��� ����
				setitemIdx(ItmNo);
				temp->idx=ItmNo;
				item_add_sect(npc->ARx,npc->ARz,temp);
				temp->x=npc->x;
				temp->z=npc->z;
				temp->item_idx=def_mon[npc->npc_id].item[i];
				pthread_mutex_unlock(&itemlock);

				memcpy(&data[dLen],&temp->idx,2);
				dLen+=2;
				memcpy(&data[dLen],&temp->x,2);
				dLen+=2;
				memcpy(&data[dLen],&temp->z,2);
				dLen+=2;
				memcpy(&data[dLen],&temp->item_idx,2);
				dLen+=2;
				memcpy(&data[dLen],&temp->item_idx_cnt,2);
				dLen+=2;
			}
		}
		if(cnt==loopCnt) break;
	}
		data[4]= cnt;  // ī��Ʈ
		memcpy(&data[dLen],&nEnd,2);
		dLen+=2;
		memcpy(&data[0],&dLen,2);
		map_usersend_All(npc->ARx,npc->ARz,data,dLen,NULL);
	return 1;
}