			if(c->attack_F_cnt>-1){
				c->attack_F_cnt+=1;
				if(c->attack_F_cnt>Half_sec) c->attack_F_cnt=-1;
			}