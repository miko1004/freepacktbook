extern void skill_get(void * chr, char * dat){

	unsigned char skidx;
	int i,res=0,invidx=0,chk=0;
	type_session * c;
	unsigned short	nEnd = PEND;
	char  msg[32];
	unsigned short Len=2;

	c=(type_session *)chr;
	skidx = dat[3];
	if(skidx>3) res=1;  // ��ų Ȯ��
	else if(skill_def[skidx].getcoin>c->coin) res=2;
	for(i=0;i<4;i++){
		if(c->skill[i]==0&&chk==0){
			invidx=i;
			chk=1;
		}
		if(c->skill[i]==skidx){
			res=3;
			break;
		}
	}

	if(res==0&&chk==1){
		pthread_mutex_lock(&synclock);
		c->skill[invidx]=skidx;
		c->skill_lv[invidx]=1;
		c->coin-=skill_def[skidx].getcoin>c->coin;
		pthread_mutex_unlock(&synclock);
	}else res=4;

	msg[Len]=PK_SKILL_GET;
	Len+=1;
	msg[Len]=res;
	Len+=1;
	msg[Len]=invidx;
	Len+=1;
	memcpy(&msg[Len],&nEnd,2);
	Len+=2;
	memcpy(&msg[0],&Len,2);
	map_pData_snd(c,msg,Len);
}