extern void skill_defset(unsigned char type,unsigned char skillidx,char * lvpwr, char * lvupcost,unsigned int getcoin){
	int i;

	if(skillidx>3) return;
	skill_def[skillidx].type=type;
	skill_def[skillidx].skillidx=skillidx;
	skill_def[skillidx].getcoin=getcoin;

	for(i=1;i<11;i++){
		if(i==1) skill_def[skillidx].lvpwr[i]=atoi(strtok(lvpwr,"|"));
		else skill_def[skillidx].lvpwr[i]= atoi(strtok(NULL,"|"));
	}
	for(i=1;i<11;i++){
		if(i==1) skill_def[skillidx].lvupcost[i]=atoi(strtok(lvupcost,"|"));
		else skill_def[skillidx].lvupcost[i]= atoi(strtok(NULL,"|"));
	}
}