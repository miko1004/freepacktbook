extern void skill_lvup(void * chr, char * dat){

	unsigned char invidx,skidx=0,lv;
	int res=0;
	type_session * c;
	unsigned short	nEnd = PEND;
	char  msg[32];
	unsigned short Len=2;

	c=(type_session *)chr;
	invidx = dat[3];
	if(skidx>3) res=1;  // ��ų Ȯ��
	else if((skidx=c->skill[invidx])==0) res=2;
	else if((lv=c->skill_lv[invidx])>=10) res=3;
	else if(skill_def[skidx].lvupcost[lv]>c->coin) res=4;
	else{
		pthread_mutex_lock(&synclock);
		c->coin-=skill_def[skidx].lvupcost[lv]>c->coin;
		c->skill_lv[invidx]+=1;
		pthread_mutex_unlock(&synclock);
	}

	msg[Len]=PK_SKILL_LVUP;
	Len+=1;
	msg[Len]=res;
	Len+=1;
	msg[Len]=skidx;
	Len+=1;
	msg[Len]=invidx;
	Len+=1;
	msg[Len]=c->skill_lv[invidx];
	Len+=1;
	memcpy(&msg[Len],&nEnd,2);
	Len+=2;
	memcpy(&msg[0],&Len,2);
	map_pData_snd(c,msg,Len);
}