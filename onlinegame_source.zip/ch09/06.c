	if(result==1){//npc die item make
	//item drop
		npc_drop_item(npcArray[Index], c->userNo);

		if(c->party.flag==1){// ��Ƽ �� ����ġ ����
			if(c->party.ison1==2){  // �ڽ��� ��Ƽ���� ��
				coin = coin/c->party.cnt;
				exp = exp/c->party.cnt;
				mc=c;
			}else{
				mc=(type_session *)c->party.master;
				if(mc==NULL) return 0;
				coin = coin/mc->party.cnt;
				exp = exp/mc->party.cnt;
			}
			pthread_mutex_lock(&synclock);
			mc->coin+= coin;
			mc->exp +=exp;
			pt0=db_chk_lvup(mc,conn);

			if(mc->party.ison2==1){
				pc=(type_session *)mc->party.mem2;
				if(pc==NULL){
					pthread_mutex_unlock(&synclock);
					return 0;
				}
				pc->coin+= coin;
				pc->exp +=exp;
				pt1=db_chk_lvup(pc,conn);;
			}
			if(mc->party.ison3==1){
				pc=(type_session *)mc->party.mem3;
				if(pc==NULL){
					pthread_mutex_unlock(&synclock);
					return 0;
				}
				pc->coin+= coin;
				pc->exp +=exp;
				pt2=db_chk_lvup(pc,conn);  // ������ Ȯ��
			}
			pthread_mutex_unlock(&synclock);

			if(pt0==1){
				rLen=2;
				mesg[rLen] = PK_LEVELUP;   // 2
				rLen+=1;
				mesg[rLen] = mc->level;  // 4
				rLen+=1;
				memcpy(&mesg[rLen],&nEnd,2);
				rLen+=2;
				memcpy(&mesg[0],&rLen,2);
				map_pData_snd(mc,mesg,rLen);
			}
			if(pt1==1){
				pc=(type_session *)mc->party.mem2;
				if(pc==NULL) return 0;
				rLen=2;
				mesg[rLen] = PK_LEVELUP;  // 2
				rLen+=1;
				mesg[rLen] = pc->level;  // 4
				rLen+=1;
				memcpy(&mesg[rLen],&nEnd,2);
				rLen+=2;
				memcpy(&mesg[0],&rLen,2);
				map_pData_snd(pc,mesg,rLen);
			}
			if(pt2==1){
				pc=(type_session *)mc->party.mem3;
				if(pc==NULL) return 0;
				rLen=2;
				mesg[rLen] = PK_LEVELUP;  // 2
				rLen+=1;
				mesg[rLen] = pc->level;  // 4
				rLen+=1;
				memcpy(&mesg[rLen],&nEnd,2);
				rLen+=2;
				memcpy(&mesg[0],&rLen,2);
				map_pData_snd(pc,mesg,rLen);
			}
		}
	}