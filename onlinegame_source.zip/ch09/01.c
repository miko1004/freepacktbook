static void thr_party_request(type_session * c, unsigned short tgidx){

	type_session *	tc;
	unsigned short	nEnd = PEND;
	short	pLen=2,lvpt;
	char	msg[128];

	msg[pLen] = PK_PT_REQ;
	pLen+=1;

	if(c->level<4){  // 4���� ������ ��Ƽ�� �� ��
		msg[pLen] = 1;//error 1
		pLen += 1;
		memcpy(&msg[pLen], &nEnd, 2);
		pLen += 2;
		memcpy(&msg[0], &pLen, 2);
		map_pData_snd(c, msg, pLen);
		return;
	}

	if(c->party.flag==1){
		if(c->party.cnt==3||c->party.ison1!=2){  // �޸𸮸� �ʰ��ϰų� ��Ƽ�� ����
			msg[pLen] = 2;  // ���� 2 
			pLen += 1; 
			memcpy(&msg[pLen], &nEnd, 2);
			pLen += 2;
			memcpy(&msg[0], &pLen, 2);
			map_pData_snd(c, msg, pLen);
			return;
		}
	}

	tc=map_ret_chr(c->Ax,c->Az,tgidx);  // �Ÿ� üũ ����
	if(tc==NULL){
		msg[pLen] = 3;  // ���� 3
		pLen += 1;
		memcpy(&msg[pLen], &nEnd, 2);
		pLen += 2;
		memcpy(&msg[0], &pLen, 2);
		map_pData_snd(c, msg, pLen);
		return;
	}
	if(tc->party.flag==1){  // �̹� ��Ƽ ��
		msg[pLen] = 4;  //���� 4
		pLen += 1;
		memcpy(&msg[pLen], &nEnd, 2);
		pLen += 2;
		memcpy(&msg[0], &pLen, 2);
		map_pData_snd(c, msg, pLen);
		return;
	}
	if(tc->level>=c->level)
		lvpt = tc->level-c->level;
	else
		lvpt = c->level-tc->level;
	if(lvpt>5){  // level���̷� ��Ƽ �� ��
		msg[pLen] = 5;  // ���� 5
		pLen += 1;
		memcpy(&msg[pLen], &nEnd, 2);
		pLen += 2;
		memcpy(&msg[0], &pLen, 2);
		map_pData_snd(c, msg, pLen);
		return;
	}

	msg[pLen] = RET_TRUE;
	pLen += 1;
	memcpy(&msg[pLen],&c->userNo,2);
	pLen += 2;
	memcpy(&msg[pLen], &nEnd, 2);
	pLen += 2;
	memcpy(&msg[0], &pLen, 2);

	pthread_mutex_lock(&synclock);
	c->party.waitfor=tc;
	tc->party.waitfor=c;
	pthread_mutex_unlock(&synclock);

	map_pData_snd(tc, msg, pLen);

}