extern void item_sell(char * data,void * se){

	unsigned char amount,tot,idx=0;
	unsigned short itemNo;
	int res=0,i,j;
	type_session *c;
	short Len=2;
	char msg[32];
	unsigned short	nEnd = PEND;

	c=(type_session *)se;

	tot = data[5];
	for(i=0,j=4;i<tot;i++){  // Ŭ���̾�Ʈ ��Ŷ Ȯ��
		idx=data[j]; 
		if(idx>4){
			res=1;
			break;
		}
		j+=1;
		amount=data[j];
		j+=1;
		if(c->inven[idx]>=_MAX_DEFAULT_ITEM||c->inven[idx]==0||c->inven_cnt[idx]<amount||amount==0){
			res=2;
			break;
		}
	}

	msg[Len]=PK_ITEM_SELL;
	Len+=1;
	msg[Len]=res;
	Len+=1;
	msg[Len]=tot;
	Len+=1;

	if(res==0){
		pthread_mutex_lock(&synclock);
		for(i=0,j=4;i<tot;i++){  // Ŭ���̾�Ʈ ��Ŷ Ȯ��
			idx=data[j];
			j+=1;
			amount=data[j];
			j+=1;
			itemNo=c->inven[idx];
			c->coin+=item0[itemNo].coin * amount;
			c->inven_cnt[idx]-=amount;
			if(c->inven_cnt[idx]==0) c->inven[idx]=0;

			msg[Len]=idx;  // �κ��丮 �ε���
			Len+=1;
			msg[Len]=c->inven_cnt[idx];
			Len+=1;
		}
		pthread_mutex_unlock(&synclock);
	}

	memcpy(&msg[Len],&c->coin,4);
	Len+=4;
	memcpy(&msg[Len],&nEnd,2);
	Len+=2;
	memcpy(&msg[0],&Len,2);
	map_pData_snd(c,msg,Len);
}