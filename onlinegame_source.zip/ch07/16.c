extern short item_trade_cancel(void * chr,char * msg){

	type_session * c;
	type_session * tc;
	int res=0;
	short dLen=2;
	char data[32];
	unsigned short	nEnd = PEND;

	c=(type_session *)chr;
	tc=(type_session *)c->trade.tg;
	if(tc==NULL) res=1;
	else if(tc->trade.tg!=c) res=1;

	if(res==0){
		pthread_mutex_lock(&synclock);
		c->trade.flag=0;
		tc->trade.flag=0;
		pthread_mutex_unlock(&synclock);
		data[dLen]=PK_TRADE_CANCEL;
		dLen+=1;
		data[dLen]=0;
		dLen+=1;
		memcpy(&data[dLen],&c->userNo,2);
		dLen+=2;
		memcpy(&data[dLen],&nEnd,2);
		dLen+=2;
		memcpy(&data[0],&dLen,2);
		map_pData_snd(c,data,dLen);
		map_pData_snd(tc,data,dLen);
		return 1;
	}

	data[dLen]=PK_TRADE_CANCEL;
	dLen+=1;
	data[dLen]=res;
	dLen+=1;
	memcpy(&data[dLen],&c->userNo,2);
	dLen+=2;
	memcpy(&data[dLen],&nEnd,2);
	dLen+=2;
	memcpy(&data[0],&dLen,2);
	map_pData_snd(c,data,dLen);
	return 1;
}