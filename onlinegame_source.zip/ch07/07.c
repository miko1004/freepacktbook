extern short item_wear(void * chr,char * msg){

	type_session * c;
	int res=0,tmp;
	short dLen=2;
	char data[32];
	unsigned char invidx,equip;
	unsigned short	nEnd = PEND;

	c=(type_session *)chr;

	invidx=msg[3];
	equip=msg[4];

	if(invidx>4||equip>6) res=1;
	else if(c->inven[invidx]==0&&c->eq[equip]==0) res=2;
	else if(c->inven[invidx]!=0&&c->eq[equip]!=0){  // ����
		tmp = c->inven[invidx];
		if(item0[tmp].equip==equip){
			pthread_mutex_lock(&synclock);
				c->inven[invidx]=c->eq[equip];
				c->eq[equip]=tmp;
				item_recal_stat(c);
			pthread_mutex_unlock(&synclock);

		}else res=3;
	}else{
		pthread_mutex_lock(&synclock);
		if(c->inven[invidx]==0){  // ���� ��
			c->inven[invidx]=c->eq[equip];
			c->inven_cnt[invidx]=1;
			c->eq[equip]=0;
			item_recal_stat(c);
		}else{  // ���� ��
			tmp = c->inven[invidx];
			if(item0[tmp].equip==equip){
				c->eq[equip]=c->inven[invidx];
				c->inven_cnt[invidx]=0;
				c->inven[invidx]=0;
				item_recal_stat(c);  // ���� ����
			}else res=3;
		}
		pthread_mutex_unlock(&synclock);
	}
	data[dLen] = PK_ITEM_WEAR;
	dLen+=1;
	data[dLen] = res;
	dLen+=1;
	data[dLen] = invidx;
	dLen+=1;
	memcpy(&data[dLen],&c->inven[invidx],2);
	dLen+=2;
	data[dLen] = equip;
	dLen+=1;
	memcpy(&data[dLen],&c->eq[equip],2);
	dLen+=2;

	memcpy(&data[dLen],&c->attack,2);
	dLen+=2;
	memcpy(&data[dLen],&c->defence,2);
	dLen+=2;
	memcpy(&data[dLen],&c->hp_m,2);
	dLen+=2;
	memcpy(&data[dLen],&c->mana_m,2);
	dLen+=2;

	memcpy(&data[dLen],&nEnd,2);
	dLen+=2;
	memcpy(&data[0],&dLen,2);
	map_pData_snd(c,data,dLen);

	if(res==0){
		dLen=2;
		data[dLen] = PK_OBJ_UPDATE_EQUI;
		dLen+=1;
		memcpy(&data[dLen],&c->userNo,2);
		dLen+=2;
		data[dLen] = equip;
		dLen+=1;
		memcpy(&data[dLen],&c->eq[equip],2);
		dLen+=2;

		memcpy(&data[dLen],&c->attack,2);
		dLen+=2;
		memcpy(&data[dLen],&c->defence,2);
		dLen+=2;
		memcpy(&data[dLen],&c->hp_m,2);
		dLen+=2;
		memcpy(&data[dLen],&c->mana_m,2);
		dLen+=2;

		memcpy(&data[dLen],&nEnd,2);
		dLen+=2;
		memcpy(&data[0],&dLen,2);
		map_usersend_All(c->Ax,c->Az,data,dLen,c);
	}
	return 1;
}