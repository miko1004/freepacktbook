extern void item_buy(char * data,void * se){

	unsigned char amount;
	unsigned short itemNo,tmp;
	int res=0,i,ckk;
	type_session *c;
	short Len=2;
	char msg[32];
	unsigned short	nEnd = PEND;

	c=(type_session *)se;

	memcpy(&itemNo,&data[3],2);
	amount=data[5];

	if(amount==0||itemNo==0||itemNo>=_MAX_DEFAULT_ITEM){
		res=1;
	}else if(amount>_MAX_ITEM_DUP){  // �ִ� �ߺ� ��ȣ
		res=2;
	}else if(amount>1){  // �ߺ� üũ
		if(itemNo>_ITEM_DUP_NO_RANGE) res=3;  // �ߺ� ���� üũ
	}
	if(res==0&&item0[itemNo].isbuy==0) res=4;

	tmp = item0[itemNo].coin * amount;
	if(res==0&&c->coin<tmp) res=5;

	for(i=0,ckk=0;i<4;i++){  // �� ���� ã��
		if(c->inven[i]==0){
			ckk=1;
			break;
		}
	}
	if(res==0&&ckk==0) res=6;
	if(res==0){
		pthread_mutex_lock(&synclock);
		c->inven[i]=itemNo;
		c->inven_cnt[i]=amount;
		c->coin-=tmp;
		pthread_mutex_unlock(&synclock);
	}
	msg[Len]=PK_ITEM_BUY;
	Len+=1;
	msg[Len]=res;
	Len+=1;
	memcpy(&msg[Len],&itemNo,2);
	Len+=2;
	msg[Len]=amount;
	Len+=1;
	msg[Len]=i;//inven index
	Len+=1;
	memcpy(&msg[Len],&nEnd,2);
	Len+=2;
	memcpy(&msg[0],&Len,2);
	map_pData_snd(c,msg,Len);
}