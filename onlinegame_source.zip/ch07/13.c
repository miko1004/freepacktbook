extern short item_trade_req_ok(void * chr,char * msg){

	type_session * c;
	type_session * tc;
	int res=0,i;
	short dLen=2,dist=0;
	char data[32];
	unsigned short	nEnd = PEND;
	unsigned short userNo;

	c=(type_session *)chr;
	memcpy(&userNo,&msg[4],2);
	tc=session_ret_session(userNo);
	if(tc==NULL) res=1;
	else{
		dist=map_ret_dist(c->Cx,c->Cz,tc->Cx,tc->Cz);
		if(dist>15) res=2;
	}
	if(res==0&&msg[3]==0){
		if(c->trade.flag==0&&c==tc->trade.tg){
			pthread_mutex_lock(&synclock);
			c->trade.flag=1;
			c->trade.confirm=0;
			c->trade.tg=tc;
			c->trade.coin=0;
			for(i=0;i<2;i++){
				c->trade.itemidx[i]=0;
				c->trade.itemidx[i]=0;
				c->trade.itemidx[i]=0;
			}
			pthread_mutex_unlock(&synclock);
		}else res=4;
	}

	data[dLen]=PK_TRADE_REQ_OK;  // ���濡�Ը� ����
	dLen+=1;
	data[dLen]=msg[3];
	dLen+=1;
	memcpy(&data[dLen],&c->userNo,2);
	dLen+=2;
	memcpy(&data[dLen],&nEnd,2);
	dLen+=2;
	memcpy(&data[0],&dLen,2);
	map_pData_snd(tc,data,dLen);
	return 1;
}