extern short item_pos(void * chr,char * msg){

	type_session * c;
	int res=0;
	short dLen=2;
	char data[32];
	unsigned char Tidx,Tcnt=0,Didx,Dcnt=0;
	unsigned short	nEnd = PEND;

	c=(type_session *)chr;

	Tidx=msg[3];
	Tcnt=msg[4];
	Didx=msg[5];
	Dcnt=msg[6];
	Dcnt+=Tcnt;

	if(Tidx>4||Didx>4) res=1;
	else if(c->inven_cnt[Tidx]<Tcnt||Tcnt==0) res=2;
	else if(c->inven[Didx]!=0){  // �������� �̹� ���� ��
		if(c->inven[Didx]!=c->inven[Tidx]) res=3;
		else if(c->inven[Didx]>_ITEM_DUP_NO_RANGE) res=4;
		else if(Dcnt>_MAX_ITEM_DUP) res=5;
	}

	if(res==0){
		pthread_mutex_lock(&synclock);
		if(c->inven_cnt[Tidx]==Tcnt){  // ���
			c->inven[Didx]=c->inven[Tidx];
			c->inven_cnt[Didx]=Dcnt;
			c->inven[Tidx]=0;
			c->inven_cnt[Tidx]=0;
		}else{
			c->inven_cnt[Didx]=Dcnt;
			c->inven_cnt[Tidx]-=Tcnt;
		}
		pthread_mutex_unlock(&synclock);
	}
	dLen=2;
	data[dLen] = PK_ITEM_POS;
	dLen+=1;
	data[dLen] = res;
	dLen+=1;
	data[dLen] = Tidx;
	dLen+=1;
	memcpy(&data[dLen],&c->inven[Tidx],2);
	dLen+=2;
	data[dLen] = c->inven_cnt[Tidx];
	dLen+=1;
	data[dLen] = Didx;
	dLen+=1;
	memcpy(&data[dLen],&c->inven[Didx],2);
	dLen+=2;
	data[dLen] = c->inven_cnt[Didx];
	dLen+=1;
	memcpy(&data[dLen],&nEnd,2);
	dLen+=2;
	memcpy(&data[0],&dLen,2);
	map_pData_snd(c,data,dLen);
	return 1;
}