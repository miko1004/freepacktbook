void * Thread_item_sync(void *arg){

	int i,j,itm_cnt;
	type_objlist  const * const * tmp_objlist;
	void * ntmp_itm;
	type_itemLst_field * tmp_itm;
	struct timeval stop;

	while(1){
		itm_cnt=0;
		pthread_mutex_lock(&itemlock);
		for(i=0;i<S_WIDTH;i++){
			for(j=0;j<S_WIDTH;j++){
				for(tmp_itm=voiditemlist_get_first(&tmp_objlist,i,j); tmp_itm; tmp_itm=ntmp_itm)
				{
					itm_cnt++;
					tmp_itm = (type_itemLst_field *)tmp_itm;
					ntmp_itm = voiditemlist_get_next(&tmp_objlist);

					if(tmp_itm->rmFcnt>30) item_rm_sect(tmp_itm);
					else tmp_itm->rmFcnt+=1;

				}
			}
		}
		pthread_mutex_unlock(&itemlock);
		stop.tv_sec=1;
		stop.tv_usec=0;
		select(0, NULL, NULL, NULL, &stop);
	}// while �� ��
}
