extern void item_ware_depos(void * chr,char * dat){

	type_session * c;
	char msg[128];
	short Len=2;
	int res=0;
	unsigned short	nEnd = PEND,tmp,tmpcnt;
	unsigned char invidx=0,wareidx=0;

	c=(type_session *)chr;
	if(c==NULL) return;

	invidx=dat[3];
	wareidx=dat[4];

	if(c->inven[invidx]==0&&c->ware[wareidx]==0) res=1;
	else{
		pthread_mutex_lock(&synclock);
		tmp=c->ware[wareidx];
		tmpcnt=c->ware_cnt[wareidx];
		c->ware[wareidx]=c->inven[invidx];
		c->ware_cnt[wareidx]=c->inven_cnt[invidx];
		c->inven[invidx]=tmp;
		c->inven_cnt[invidx]=tmpcnt;
		pthread_mutex_unlock(&synclock);
	}

	msg[Len]=PK_WARE_DEPOS;
	Len+=1;
	msg[Len]=res;
	Len+=1;
	msg[Len]=invidx;
	Len+=1;
	memcpy(&msg[Len],&c->inven[invidx],2);
	Len+=2;
	msg[Len]=c->inven_cnt[invidx];
	Len+=1;
	msg[Len]=wareidx;
	Len+=1;
	memcpy(&msg[Len],&c->ware[wareidx],2);
	Len+=2;
	msg[Len]=c->ware_cnt[wareidx];
	Len+=1;
	memcpy(&msg[Len],&nEnd,2);
	Len+=2;
	memcpy(&msg[0],&Len,2);
	map_pData_snd(c,msg,Len);
}