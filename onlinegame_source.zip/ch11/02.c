extern short db_item_sell(void * chrr, char * data)
{
	int	state;
	char query[1024];
	int tot,invenidx,i,j;
	type_session * c;

	c=(type_session *)chrr;

	memset(query,0,1024);
	tot = data[5];
	sprintf(query,"update useritem set");
	for(i=0,j=4;i<tot;i++){
		invenidx=data[j];
		j+=2;
		if(i==0){
			 sprintf(query,"%s IDX_%d=%d,Q_%d=%d", 
					query,invenidx,c->inven[invenidx],invenidx,c->inven_cnt[invenidx]);
		}else{
			sprintf(query,"%s ,IDX_%d=%d,Q_%d=%d",
					query,invenidx,c->inven[invenidx],invenidx,c->inven_cnt[invenidx]);  // �޸� �߰�
		}

	}

	sprintf(query,"%s where USERID='%s' and NAME='%s'",query,c->userid,c->char_name);
#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_sell 1ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}

	memset(query,0,1024);
	sprintf(query,"update characters set coin=%d where USERID='%s' and NAME='%s'",
						c->coin,c->userid,c->char_name);
#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_sell 2ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}

	return 1;
}