void * Thread_db(void *arg)
{
	int que_len;
	int state,i;
	t_cir_queue * tg;
	MYSQL * conn;
	MYSQL mysql;

	for(i=0;i<CIRQUE_SIZE;i++){  // ���� ť �ʱ�ȭ
		if(CIRQUE_SIZE==i+1){
			DBcircQue[i].next=&DBcircQue[0];
		}else DBcircQue[i].next=&DBcircQue[i+1];
		DBcircQue[i].index=i;
	}

	conn = mysql_connect(&mysql, _DBSERV, _DBID, _DBPASS);
	if( conn == NULL ) {
		printf("mysql error in connection\n");
		return 0;
	}

	state = mysql_select_db(conn,_DBDB);
	if( state == -1 ) {
		printf("a %s\n",mysql_error(conn));
		mysql_close(conn);
		return 0;
	}

	for(;;){
		pthread_mutex_lock(&dbQuelock);
		que_len = cirQueLen;
		while(que_len==0){
			pthread_cond_wait(&dbQuecond,&dbQuelock);
			que_len = cirQueLen;
		}
		cirQueLen=0;
		overPos=DBcircQue[getPos].index;  // �����÷ο� üũ�� ���� �ε����� �������� ù��°�� �Է��� ��
		pthread_mutex_unlock(&dbQuelock);

		i=0;
		tg=&DBcircQue[getPos];
		while(i<que_len){
			i+=1;
			state = mysql_query(conn,tg->query);
			if( state == -1 ) {
				printf("db_thread ERROR: %s\n",mysql_error(conn));
			}
			tg = tg->next;
			getPos = tg->index;
		}  // while ��
	}
}                                                                                                   