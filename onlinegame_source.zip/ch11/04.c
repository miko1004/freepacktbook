extern short db_item_wear(void * chr,unsigned char invidx,unsigned char eqidx)
{
	int	state;
	char query[1024];
	type_session * c;

	c=(type_session *)chr;

	memset(query,0,1024);
 	 sprintf(query,"update useritem set IDX_%d=%d,Q_%d=%d where USERID='%s' and NAME='%s'",
 				invidx,c->inven[invidx],invidx,c->inven_cnt[invidx],c->userid,c->char_name);

#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_sell 1ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}

	memset(query,0,1024);
	switch(eqidx){
		case 0:
			sprintf(query,"update characters set I_HEAD=%d where USERID='%s' and NAME='%s'",
						c->eq[eqidx],c->userid,c->char_name);
		break;
		case 1:
			sprintf(query,"update characters set I_L_HAND=%d where USERID='%s' and NAME='%s'",
						c->eq[eqidx],c->userid,c->char_name);
		break;
		case 2:
			sprintf(query,"update characters set I_R_HAND=%d where USERID='%s' and NAME='%s'",
						c->eq[eqidx],c->userid,c->char_name);
		break;
		case 3:
			sprintf(query,"update characters set I_BODY=%d where USERID='%s' and NAME='%s'",
						c->eq[eqidx],c->userid,c->char_name);
		break;
		case 4:
			sprintf(query,"update characters set I_LEG=%d where USERID='%s' and NAME='%s'",
						c->eq[eqidx],c->userid,c->char_name);
		break;
		case 5:
			sprintf(query,"update characters set I_NECKLACE=%d where USERID='%s' and NAME='%s'",
						c->eq[eqidx],c->userid,c->char_name);
		break;
		case 6:
			sprintf(query,"update characters set I_RING=%d where USERID='%s' and NAME='%s'",
						c->eq[eqidx],c->userid,c->char_name);
		break;
		default: return 0;
	}

#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_wear ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	return 1;
}
