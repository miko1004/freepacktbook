extern short db_levelup(void * chr)
{ // â��
	int	state;
	char query[1024];
	type_session * c;

	c=(type_session *)chr;

	memset(query,0,1024);
	 sprintf(query,"update characters set LV=%d,PT=%d where USERID='%s' and HERO_NAME='%s'",
				c->level,c->lvpoint,c->userid,c->char_name);

#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif
	if( state == -1 ) {
		printf("db_add_skill ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	return 1;
}
