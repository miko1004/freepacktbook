extern short db_save_all(void * chrr,void * conns)
{
	int	state;

	char query[1024];
	type_session * c;
	MYSQL *st_conn;

	st_conn = (MYSQL *)conns;
	c = (type_session *)chrr;
	if(!c) return 0;
	if(c->dbLoaded==0) return 0;
	memset(query,0,1024);
	sprintf(query,"update characters set MANA='%d',HP='%d',EXP='%d',SKEXP='%d',CLASSLV='%d',LOC_SVR='%d',LOCX='%d',LOCY='%d',I_HEAD='%d',I_L_HAND='%d',I_R_HAND='%d',I_BODY='%d',I_LEG='%d',I_NECKLACE='%d',I_RING='%d',COIN='%d' where userid='%s'",
						c->mana_c,c->hp_c,c->exp,c->skexp,c->classlevel,c->worldmap,c->Cx,c->Cy,c->eq[0],c->eq[1],c->eq[2],c->eq[3],c->eq[4],c->eq[5],c->eq[6],c->coin,c->userid);

#ifdef _DB_QUERY_ENQUEUE
 	state = db_enque_qry(query);
#else
 	state = mysql_query(st_conn, query);
#endif
	if( state == -1 ) {
		printf("db_char_SAVE ALL1%s\n",mysql_error(st_conn));
		return 0;
	}
	printf("save query:%s\n",query);

	memset(query,0,1024);
	sprintf(query,"update skill set IDX0='%d',LV0='%d',IDX1='%d',LV1='%d',IDX2='%d',LV2='%d',IDX3='%d',LV3='%d' where USERID='%s'",
		c->skill[0],c->skill_lv[0],c->skill[1],c->skill_lv[1],c->skill[2],c->skill_lv[2],c->skill[3],c->skill_lv[3],c->userid);

#ifdef _DB_QUERY_ENQUEUE
 	state = db_enque_qry(query);
#else
 	state = mysql_query(st_conn, query);
#endif

	if( state == -1 ) {
		printf("db_char_SAVE ALL2%s\n",mysql_error(st_conn));
		return 0;
	}
	printf("save query:%s\n",query);

	memset(query,0,1024);
	sprintf(query,"update useritem set IDX_0='%d',Q_0='%d',IDX_1='%d',Q_1='%d',IDX_2='%d',Q_2='%d',IDX_3='%d',Q_3='%d' where USERID='%s'",
		c->inven[0],c->inven_cnt[0],c->inven[1],c->inven_cnt[1],c->inven[2],c->inven_cnt[2],c->inven[3],c->inven_cnt[3],c->userid);
#ifdef _DB_QUERY_ENQUEUE
 	state = db_enque_qry(query);
#else
 	state = mysql_query(st_conn, query);
#endif

	if( state == -1 ) {
		printf("db_useritem %s\n",mysql_error(st_conn));
		return -1;
	}

	memset(query,0,1024);
	sprintf(query,"update warehouse set IDX_0=%d,Q_0=%d,IDX_1=%d,Q_1=%d,IDX_2=%d,Q_2=%d,IDX_3=%d,Q_3=%d,IDX_4=%d,Q_4=%d,IDX_5=%d,Q_5=%d,IDX_6=%d,Q_6=%d,IDX_7=%d,Q_7=%d where USERID ='%s'",
		c->ware[0],c->ware_cnt[0],c->ware[1],c->ware_cnt[1],c->ware[2],c->ware_cnt[2],c->ware[3],c->ware_cnt[3],c->ware[4],c->ware_cnt[4],c->ware[5],c->ware_cnt[5],c->ware[6],c->ware_cnt[6],c->ware[7],c->ware_cnt[7],c->userid);
#ifdef _DB_QUERY_ENQUEUE
 	state = db_enque_qry(query);
#else
 	state = mysql_query(st_conn, query);
#endif

	if( state == -1 ) {
		printf("db_TB_HOSE %s\n",mysql_error(st_conn));
		return -1;
	}

	printf("save query:%s\n",query);
	return 1;
}
