extern short db_item_pick(void * chr, unsigned short invidx)
{  // �ݱ�, ������, ��� ��� ����
	int	state;
	char query[1024];
	type_session * c;

	c = (type_session *)chr;

	memset(query,0,1024);

	sprintf(query,"update useritem set IDX_%d=%d,Q_%d=%d where USERID='%s' and NAME='%s'",
			invidx,c->inven[invidx],invidx,c->inven_cnt[invidx],c->userid,c->char_name);

#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_pick ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}

	return 1;
}