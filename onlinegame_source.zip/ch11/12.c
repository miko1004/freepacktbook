 typedef struct cqueues{

  	struct cqueues * 	next;
  	unsigned int		index;
  	char			query[1024];

 }t_cir_queue;
 static int cirQueLen=0,getPos=0,putPos=0,overPos=-1;
 static t_cir_queue DBcircQue[CIRQUE_SIZE];
