extern short db_item_trade(void * schr, void * tchr, char * sChange, char * tChange)
{
	int	state;
	char squery[1024],tquery[1024];
	int i,schk=0,tchk=0;
	type_session * c, * tc;

	c=(type_session *)schr;
	tc=(type_session *)tchr;

	memset(squery,0,1024);
	memset(tquery,0,1024);

	sprintf(squery,"update useritem set");
	sprintf(tquery,"update useritem set");

	for(i=0;i<4;i++){
		if(sChange[i]==1){
			if(schk==0){
				sprintf(squery,"%s IDX_%d=%d,Q_%d=%d",
							squery,i,c->inven[i],i,c->inven_cnt[i]);
			}else{
				sprintf(squery,"%s ,IDX_%d=%d,Q_%d=%d",
							squery,i,c->inven[i],i,c->inven_cnt[i]); // �޸� �߰�
			}
			schk=1;
		}
		if(tChange[i]==1){
			if(tchk==0){
				sprintf(tquery,"%s IDX_%d=%d,Q_%d=%d",
							tquery,i,tc->inven[i],i,tc->inven_cnt[i]);
			}else{
				sprintf(tquery,"%s IDX_%d=%d,Q_%d=%d",
							tquery,i,tc->inven[i],i,tc->inven_cnt[i]); // �޸� �߰�
			}
			tchk=1;
		}
	}

	sprintf(squery,"%s where USERID='%s' and NAME='%s'",squery,c->userid,c->char_name);
#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(squery);
#else
	state = mysql_query(connCHR, squery);
#endif

	if( state == -1 ) {
		printf("db_item_trade 1sERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	sprintf(tquery,"%s where USERID='%s' and NAME='%s'",tquery,c->userid,c->char_name);
#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(tquery);
#else
	state = mysql_query(connCHR, tquery);
#endif

	if( state == -1 ) {
		printf("db_item_trade 1tERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	memset(squery,0,1024);
	memset(tquery,0,1024);
	sprintf(squery,"update characters set coin=%d where USERID='%s' and NAME='%s'",
				c->coin,c->userid,c->char_name);
#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(squery);
#else
	state = mysql_query(connCHR, squery);
#endif

	if( state == -1 ) {
		printf("db_item_trade 2sERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	sprintf(tquery,"update characters set coin=%d where USERID='%s' and NAME='%s'",
				tc->coin,tc->userid,c->char_name);
#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(tquery);
#else
	state = mysql_query(connCHR, tquery);
#endif

	if( state == -1 ) {
		printf("db_item_trade 2tERROR: %s\n",mysql_error(connCHR));
		return 0;
	}

	return 1;
}
