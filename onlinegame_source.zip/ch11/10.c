extern short db_set_skill(void * chr, unsigned char skidx)
{ // â��
	int	state;
	char query[1024];
	type_session * c;

	c=(type_session *)chr;

	memset(query,0,1024);
	 sprintf(query,"update skill set IDX%d=%d,LV%d=%d where USERID='%s' and HERO_NAME='%s'",
				skidx,c->skill[skidx],skidx,c->skill_lv[skidx],c->userid,c->char_name);

#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_add_skill ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	return 1;
}
