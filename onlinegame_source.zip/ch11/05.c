extern short db_item_pos(void * chr,unsigned char sidx,unsigned char didx)
{
	int	state;
	char query[1024];
	type_session * c;

	c=(type_session *)chr;

	memset(query,0,1024);
	sprintf(query,"update useritem set IDX_%d=%d,Q_%d=%d,IDX_%d=%d,Q_%d=%d where USERID='%s' and NAME='%s'",
				sidx,c->inven[sidx],sidx,c->inven_cnt[sidx],didx,c->inven[didx],didx,c->inven_cnt[didx],
				c->userid,c->char_name);

#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_pos ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	return 1;
}
