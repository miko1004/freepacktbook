extern short db_save_exp_money(void * chr)
{ // â��
	int	state;
	char query[1024];
	type_session * c;

	c=(type_session *)chr;

	memset(query,0,1024);
	 sprintf(query,"update characters set EXP=%d,COIN=%d where USERID='%s' and NAME='%s'",
				c->exp,c->coin,c->userid,c->char_name);

#ifdef _DB_QUERY_ENQUEUE
	state = db_enque_qry(query);
#else
	state = mysql_query(connCHR, query);
#endif

	if( state == -1 ) {
		printf("db_item_pos ERROR: %s\n",mysql_error(connCHR));
		return 0;
	}
	return 1;
}
